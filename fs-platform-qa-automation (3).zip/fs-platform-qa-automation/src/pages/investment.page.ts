import { Locator, Page, expect } from '@playwright/test';
import { BasePage } from './base.page';

export type InvestmentType = 'Lumpsum' | 'SIP';
export type PaymentMethod = 'UPI' | 'Net Banking' | 'Debit Card' | 'Wallet';

export interface InvestmentInput {
  type?: InvestmentType;
  amount?: number;
  paymentMethod?: PaymentMethod;
  /** Tick the simulation declaration. Defaults to true in invest(). */
  acceptDeclaration?: boolean;
}

/**
 * Investment order form (GET/POST /invest/{fundId}).
 *
 * Real DOM hooks (captured 2026-09): wrapper `investment-page`; a fund
 * summary card with .details-row label/value pairs (Fund Code, Category,
 * Current NAV, 1 Year Return, Minimum SIP, Minimum Lumpsum); form
 * `investment-form` with radios `investment-type-lumpsum` (default) /
 * `investment-type-sip`, `investment-amount-input` (number),
 * `payment-method-select` (UPI / Net Banking / Debit Card / Wallet),
 * `investment-declaration-checkbox`, `confirm-investment-button`, and a
 * Cancel link back to /mutual-funds/{id}.
 */
export class InvestmentPage extends BasePage {
  readonly container: Locator;
  readonly form: Locator;
  readonly lumpsumRadio: Locator;
  readonly sipRadio: Locator;
  readonly amountInput: Locator;
  readonly paymentMethodSelect: Locator;
  readonly declarationCheckbox: Locator;
  readonly confirmButton: Locator;
  readonly cancelLink: Locator;

  constructor(page: Page) {
    super(page);
    this.container = page.getByTestId('investment-page');
    this.form = page.getByTestId('investment-form');
    this.lumpsumRadio = page.getByTestId('investment-type-lumpsum');
    this.sipRadio = page.getByTestId('investment-type-sip');
    this.amountInput = page.getByTestId('investment-amount-input');
    this.paymentMethodSelect = page.getByTestId('payment-method-select');
    this.declarationCheckbox = page.getByTestId('investment-declaration-checkbox');
    this.confirmButton = page.getByTestId('confirm-investment-button');
    this.cancelLink = this.form.getByRole('link', { name: 'Cancel' });
  }

  async goto(fundId: number | string): Promise<void> {
    await this.page.goto(`/invest/${fundId}`);
    await this.expectLoaded();
  }

  async expectLoaded(): Promise<void> {
    await expect(this.page).toHaveURL(/\/invest\/\d+/);
    await expect(this.container).toBeVisible();
    await expect(this.confirmButton).toBeVisible();
  }

  /** Value of a fund-summary row by its label, e.g. 'Minimum Lumpsum'. */
  summaryDetail(label: string | RegExp): Locator {
    return this.container
      .locator('.details-row')
      .filter({ has: this.page.locator('.subtle', { hasText: label }) })
      .locator('strong');
  }

  /** Reads a ₹-formatted summary value as a number. */
  async summaryAmount(label: string | RegExp): Promise<number> {
    return Number((await this.summaryDetail(label).innerText()).replace(/[₹,\s]/g, ''));
  }

  /** Fill only the provided fields (Lumpsum is the form's default type). */
  async fillForm(input: InvestmentInput): Promise<void> {
    if (input.type === 'Lumpsum') await this.lumpsumRadio.check();
    if (input.type === 'SIP') await this.sipRadio.check();
    if (input.amount !== undefined) await this.amountInput.fill(String(input.amount));
    if (input.paymentMethod !== undefined) {
      await this.paymentMethodSelect.selectOption(input.paymentMethod);
    }
    if (input.acceptDeclaration) await this.declarationCheckbox.check();
  }

  async submit(): Promise<void> {
    await this.confirmButton.click();
  }

  /** Fill and submit in one step (declaration ticked by default). */
  async invest(input: InvestmentInput): Promise<void> {
    await this.fillForm({ acceptDeclaration: true, paymentMethod: 'UPI', ...input });
    await this.submit();
  }

  /** After a rejected submit the user stays on the investment form. */
  async expectStillOnForm(): Promise<void> {
    await expect(this.page).toHaveURL(/\/invest\/\d+/);
    await expect(this.confirmButton).toBeVisible();
  }

  async cancel(): Promise<void> {
    await this.cancelLink.click();
    await expect(this.page).toHaveURL(/\/mutual-funds\/\d+/);
  }
}
