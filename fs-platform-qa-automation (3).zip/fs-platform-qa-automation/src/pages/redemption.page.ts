import { Locator, Page, expect } from '@playwright/test';
import { BasePage } from './base.page';

export interface RedemptionInput {
  mode?: 'units' | 'amount';
  units?: number;
  amount?: number;
  /** Tick the indicative-value declaration. Defaults to true in redeem(). */
  acceptDeclaration?: boolean;
}

/**
 * Redemption request (GET/POST /redeem/{holdingId}).
 *
 * Real DOM hooks (captured 2026-09): wrapper `redemption-page`; holding
 * summary with `redemption-fund-name`, `available-units`, `available-value`
 * (Current NAV and Folio are label/value pairs without test-ids); form
 * `redemption-form` with radios `redeem-mode-units` (default) /
 * `redeem-mode-amount`, inputs `redeem-units-input` / `redeem-amount-input`,
 * `redemption-declaration-checkbox`, and `confirm-redemption-button`.
 * A "← Back to Portfolio" link returns to /portfolio.
 */
export class RedemptionPage extends BasePage {
  readonly container: Locator;
  readonly fundName: Locator;
  readonly availableUnits: Locator;
  readonly availableValue: Locator;
  readonly form: Locator;
  readonly unitsModeRadio: Locator;
  readonly amountModeRadio: Locator;
  readonly unitsInput: Locator;
  readonly amountInput: Locator;
  readonly declarationCheckbox: Locator;
  readonly confirmButton: Locator;
  readonly backToPortfolioLink: Locator;

  constructor(page: Page) {
    super(page);
    this.container = page.getByTestId('redemption-page');
    this.fundName = page.getByTestId('redemption-fund-name');
    this.availableUnits = page.getByTestId('available-units');
    this.availableValue = page.getByTestId('available-value');
    this.form = page.getByTestId('redemption-form');
    this.unitsModeRadio = page.getByTestId('redeem-mode-units');
    this.amountModeRadio = page.getByTestId('redeem-mode-amount');
    this.unitsInput = page.getByTestId('redeem-units-input');
    this.amountInput = page.getByTestId('redeem-amount-input');
    this.declarationCheckbox = page.getByTestId('redemption-declaration-checkbox');
    this.confirmButton = page.getByTestId('confirm-redemption-button');
    this.backToPortfolioLink = this.container.getByRole('link', { name: /back to portfolio/i });
  }

  async goto(holdingId: number | string): Promise<void> {
    await this.page.goto(`/redeem/${holdingId}`);
    await this.expectLoaded();
  }

  async expectLoaded(): Promise<void> {
    await expect(this.page).toHaveURL(/\/redeem\/\d+/);
    await expect(this.container).toBeVisible();
    await expect(this.confirmButton).toBeVisible();
  }

  /** Summary value by label for the pairs without test-ids (Current NAV, Folio). */
  summaryValue(label: string | RegExp): Locator {
    return this.container
      .locator('.card-body .col-6, .card-body .mb-3')
      .filter({ has: this.page.locator('.text-muted', { hasText: label }) })
      .locator('.fw-semibold');
  }

  async availableUnitsCount(): Promise<number> {
    return Number((await this.availableUnits.innerText()).replace(/[,\s]/g, ''));
  }

  async availableValueAmount(): Promise<number> {
    return Number((await this.availableValue.innerText()).replace(/[₹,\s]/g, ''));
  }

  async currentNav(): Promise<number> {
    return Number((await this.summaryValue('Current NAV').innerText()).replace(/[₹,\s]/g, ''));
  }

  async fillForm(input: RedemptionInput): Promise<void> {
    if (input.mode === 'units') await this.unitsModeRadio.check();
    if (input.mode === 'amount') await this.amountModeRadio.check();
    if (input.units !== undefined) await this.unitsInput.fill(String(input.units));
    if (input.amount !== undefined) await this.amountInput.fill(String(input.amount));
    if (input.acceptDeclaration) await this.declarationCheckbox.check();
  }

  async submit(): Promise<void> {
    await this.confirmButton.click();
  }

  /** Fill and submit in one step (declaration ticked by default). */
  async redeem(input: RedemptionInput): Promise<void> {
    await this.fillForm({ acceptDeclaration: true, ...input });
    await this.submit();
  }

  /** After a rejected submit the user stays on the redemption form. */
  async expectStillOnForm(): Promise<void> {
    await expect(this.page).toHaveURL(/\/redeem\/\d+/);
    await expect(this.confirmButton).toBeVisible();
  }
}
