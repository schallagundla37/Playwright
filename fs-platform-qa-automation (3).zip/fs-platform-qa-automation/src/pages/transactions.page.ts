import { Locator, Page, expect } from '@playwright/test';
import { BasePage } from './base.page';

/** Allowed transaction type values (feature guide, section 5). */
export type TransactionType =
  | 'Investment'
  | 'Redemption'
  | 'Premium Payment'
  | 'Refund'
  | 'Failed Payment';

/** Allowed transaction status values (feature guide, section 5). */
export type TransactionStatus = 'SUCCESS' | 'PENDING' | 'FAILED' | 'CANCELLED';

/**
 * Transaction history (GET /transactions).
 *
 * Real DOM hooks (captured 2026-09): header `transactions-page`; GET filter
 * form in `transaction-filters-card` with `transaction-search-input`,
 * `transaction-type-filter`, `transaction-status-filter`,
 * `transaction-date-from` / `transaction-date-to` (native date),
 * `transaction-filter-submit`, `transaction-filter-reset`; table
 * `transactions-table` with rows keyed by reference:
 * `transaction-row-{ref}`, `transaction-reference-{ref}`,
 * `transaction-type-{ref}`, `transaction-status-{ref}` and a
 * `transaction-details-link-{ref}` → /transactions/{id}. Paginated 12/page
 * (`transactions-pagination`, Laravel paginator with rel="next").
 */
export class TransactionsPage extends BasePage {
  readonly container: Locator;
  readonly searchInput: Locator;
  readonly typeFilter: Locator;
  readonly statusFilter: Locator;
  readonly dateFromInput: Locator;
  readonly dateToInput: Locator;
  readonly applyButton: Locator;
  readonly resetLink: Locator;
  readonly table: Locator;
  readonly pagination: Locator;

  constructor(page: Page) {
    super(page);
    this.container = page.getByTestId('transactions-page');
    this.searchInput = page.getByTestId('transaction-search-input');
    this.typeFilter = page.getByTestId('transaction-type-filter');
    this.statusFilter = page.getByTestId('transaction-status-filter');
    this.dateFromInput = page.getByTestId('transaction-date-from');
    this.dateToInput = page.getByTestId('transaction-date-to');
    this.applyButton = page.getByTestId('transaction-filter-submit');
    this.resetLink = page.getByTestId('transaction-filter-reset');
    this.table = page.getByTestId('transactions-table');
    this.pagination = page.getByTestId('transactions-pagination');
  }

  async goto(): Promise<void> {
    await this.page.goto('/transactions');
    await this.expectLoaded();
  }

  async expectLoaded(): Promise<void> {
    await expect(this.page).toHaveURL(/\/transactions/);
    await expect(this.container).toBeVisible();
    await expect(this.searchInput).toBeVisible();
  }

  /** All transaction rows on the current page. */
  get rows(): Locator {
    return this.page.locator('[data-testid^="transaction-row-"]');
  }

  row(reference: string): Locator {
    return this.page.getByTestId(`transaction-row-${reference}`);
  }

  /** All type cells / status pills on the current page. */
  get typeCells(): Locator {
    return this.page.locator('[data-testid^="transaction-type-"]');
  }

  get statusPills(): Locator {
    return this.page.locator('[data-testid^="transaction-status-"]');
  }

  /** The paginator's "Showing X to Y of Z results" summary. */
  get resultsSummary(): Locator {
    return this.pagination.locator('p', { hasText: 'results' });
  }

  /** rel="next" link; hidden variant excluded via the visible page-number nav. */
  get nextPageLink(): Locator {
    return this.pagination.locator('a[rel="next"]').last();
  }

  /**
   * Apply filters via the GET form. Dates in ISO yyyy-mm-dd. Only the
   * provided fields are touched.
   */
  async filter(options: {
    search?: string;
    type?: TransactionType;
    status?: TransactionStatus;
    dateFrom?: string;
    dateTo?: string;
  }): Promise<void> {
    if (options.search !== undefined) await this.searchInput.fill(options.search);
    if (options.type !== undefined) await this.typeFilter.selectOption(options.type);
    if (options.status !== undefined) await this.statusFilter.selectOption(options.status);
    if (options.dateFrom !== undefined) await this.dateFromInput.fill(options.dateFrom);
    if (options.dateTo !== undefined) await this.dateToInput.fill(options.dateTo);
    await this.applyButton.click();
    await this.expectLoaded();
  }

  async resetFilters(): Promise<void> {
    await this.resetLink.click();
    await this.expectLoaded();
  }

  async openDetails(reference: string): Promise<void> {
    await this.page.getByTestId(`transaction-details-link-${reference}`).click();
    await expect(this.page).toHaveURL(/\/transactions\/\d+/);
  }

  /** Reference of the first (most recent) row on the page. */
  async firstReference(): Promise<string> {
    const testId = (await this.rows.first().getAttribute('data-testid'))!;
    return testId.replace('transaction-row-', '');
  }
}
