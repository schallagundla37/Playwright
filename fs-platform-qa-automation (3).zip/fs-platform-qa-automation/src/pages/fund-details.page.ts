import { Locator, Page, expect } from '@playwright/test';
import { BasePage } from './base.page';

/**
 * Mutual fund detail (GET /mutual-funds/{id}).
 *
 * Real DOM hooks (captured 2026-09): wrapper `fund-details-page` with
 * `fund-detail-name` (h1), a subtitle "CODE · Category · Risk", an
 * `invest-now-button` → /invest/{id}, metric cards `fund-detail-nav` and
 * `fund-detail-one-year-return` (3-Year Return and Expense Ratio have no
 * test-ids — use `metric(label)`), and a details list with
 * `fund-detail-minimum-sip` / `fund-detail-minimum-lumpsum`.
 */
export class FundDetailsPage extends BasePage {
  readonly container: Locator;
  readonly fundName: Locator;
  readonly subtitle: Locator;
  readonly nav: Locator;
  readonly oneYearReturn: Locator;
  readonly minimumSip: Locator;
  readonly minimumLumpsum: Locator;
  readonly investNowButton: Locator;

  constructor(page: Page) {
    super(page);
    this.container = page.getByTestId('fund-details-page');
    this.fundName = page.getByTestId('fund-detail-name');
    this.subtitle = this.container.locator('.muted');
    this.nav = page.getByTestId('fund-detail-nav');
    this.oneYearReturn = page.getByTestId('fund-detail-one-year-return');
    this.minimumSip = page.getByTestId('fund-detail-minimum-sip');
    this.minimumLumpsum = page.getByTestId('fund-detail-minimum-lumpsum');
    this.investNowButton = page.getByTestId('invest-now-button');
  }

  async goto(fundId: number | string): Promise<void> {
    await this.page.goto(`/mutual-funds/${fundId}`);
    await this.expectLoaded();
  }

  async expectLoaded(): Promise<void> {
    await expect(this.page).toHaveURL(/\/mutual-funds\/\d+/);
    await expect(this.container).toBeVisible();
    await expect(this.investNowButton).toBeVisible();
  }

  /** Metric card value by its visible label, e.g. metric('Expense Ratio'). */
  metric(label: string | RegExp): Locator {
    return this.page
      .locator('.metric-card')
      .filter({ has: this.page.locator('.metric-label', { hasText: label }) })
      .locator('strong');
  }

  /** Minimum lumpsum as a number, for boundary-value derivation. */
  async minimumLumpsumAmount(): Promise<number> {
    return Number((await this.minimumLumpsum.innerText()).replace(/[₹,\s]/g, ''));
  }

  /** Minimum SIP as a number, for boundary-value derivation. */
  async minimumSipAmount(): Promise<number> {
    return Number((await this.minimumSip.innerText()).replace(/[₹,\s]/g, ''));
  }

  async investNow(): Promise<void> {
    await this.investNowButton.click();
    await expect(this.page).toHaveURL(/\/invest\/\d+/);
  }
}
