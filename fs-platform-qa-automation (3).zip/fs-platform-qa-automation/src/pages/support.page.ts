import { Locator, Page, expect } from '@playwright/test';
import { BasePage } from './base.page';

export type SupportCategory =
  | 'Investment Issue'
  | 'Redemption Issue'
  | 'Insurance Issue'
  | 'Transaction Issue'
  | 'Profile Issue'
  | 'Other';

/**
 * Support request (GET/POST /support).
 *
 * Real DOM hooks (captured 2026-09): wrapper `support-page`; form
 * `support-form` with `support-category-select` (6 categories, required),
 * `support-message-input` (textarea, required, min 10 characters per its
 * placeholder), `support-submit-button`, and `support-cancel-link`
 * → /dashboard.
 */
export class SupportPage extends BasePage {
  readonly container: Locator;
  readonly form: Locator;
  readonly categorySelect: Locator;
  readonly messageInput: Locator;
  readonly submitButton: Locator;
  readonly cancelLink: Locator;
  /** Success feedback after submission (flash alert). */
  readonly successFlash: Locator;

  constructor(page: Page) {
    super(page);
    this.container = page.getByTestId('support-page');
    this.form = page.getByTestId('support-form');
    this.categorySelect = page.getByTestId('support-category-select');
    this.messageInput = page.getByTestId('support-message-input');
    this.submitButton = page.getByTestId('support-submit-button');
    this.cancelLink = page.getByTestId('support-cancel-link');
    this.successFlash = page
      .locator('[data-testid="flash-status"], .alert-success')
      .first();
  }

  async goto(): Promise<void> {
    await this.page.goto('/support');
    await this.expectLoaded();
  }

  async expectLoaded(): Promise<void> {
    await expect(this.page).toHaveURL(/\/support/);
    await expect(this.container).toBeVisible();
    await expect(this.submitButton).toBeVisible();
  }

  async submitRequest(category: SupportCategory | '', message: string): Promise<void> {
    if (category !== '') await this.categorySelect.selectOption(category);
    await this.messageInput.fill(message);
    await this.submitButton.click();
  }
}
