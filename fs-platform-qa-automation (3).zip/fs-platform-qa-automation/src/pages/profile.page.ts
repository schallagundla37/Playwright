import { Locator, Page, expect } from '@playwright/test';
import { BasePage } from './base.page';

/**
 * Customer profile (GET /profile).
 *
 * Real DOM hooks (captured 2026-09): wrapper `profile-page` and a detail grid
 * with `profile-name`, `profile-email`, `profile-mobile`, `profile-pan`
 * (masked, e.g. ABCDE****F), `profile-kyc-status`, `profile-account-status`,
 * `profile-learner-code`.
 */
export class ProfilePage extends BasePage {
  readonly container: Locator;
  readonly name: Locator;
  readonly email: Locator;
  readonly mobile: Locator;
  readonly pan: Locator;
  readonly kycStatus: Locator;
  readonly accountStatus: Locator;
  readonly learnerCode: Locator;

  constructor(page: Page) {
    super(page);
    this.container = page.getByTestId('profile-page');
    this.name = page.getByTestId('profile-name');
    this.email = page.getByTestId('profile-email');
    this.mobile = page.getByTestId('profile-mobile');
    this.pan = page.getByTestId('profile-pan');
    this.kycStatus = page.getByTestId('profile-kyc-status');
    this.accountStatus = page.getByTestId('profile-account-status');
    this.learnerCode = page.getByTestId('profile-learner-code');
  }

  async goto(): Promise<void> {
    await this.page.goto('/profile');
    await this.expectLoaded();
  }

  async expectLoaded(): Promise<void> {
    await expect(this.page).toHaveURL(/\/profile/);
    await expect(this.container).toBeVisible();
    await expect(this.name).toBeVisible();
  }
}
