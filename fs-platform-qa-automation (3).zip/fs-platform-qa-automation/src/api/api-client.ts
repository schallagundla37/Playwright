import { APIRequestContext, APIResponse } from '@playwright/test';
import { env } from '../config/env';

/**
 * Thin wrapper around Playwright's request context so every API test uses a
 * consistent base URL, the X-API-Key header, and JSON parsing.
 *
 * The FinServe API (feature guide, section 7) authenticates with a static
 * key; `key: null` sends the request without the header (negative tests) and
 * any string overrides it (invalid-key tests).
 */
export class ApiClient {
  constructor(private readonly request: APIRequestContext) {}

  private url(path: string): string {
    return path.startsWith('http') ? path : `${env.api.baseUrl}${path}`;
  }

  private headers(key: string | null | undefined): Record<string, string> {
    const headers: Record<string, string> = { Accept: 'application/json' };
    const resolved = key === undefined ? env.api.key : key;
    if (resolved !== null) headers['X-API-Key'] = resolved;
    return headers;
  }

  async get(path: string, options: { key?: string | null } = {}): Promise<APIResponse> {
    return this.request.get(this.url(path), { headers: this.headers(options.key) });
  }

  async post(
    path: string,
    data: unknown,
    options: { key?: string | null } = {},
  ): Promise<APIResponse> {
    return this.request.post(this.url(path), {
      headers: { ...this.headers(options.key), 'Content-Type': 'application/json' },
      data,
    });
  }

  /** GET and parse JSON in one step. */
  async getJson(
    path: string,
    options: { key?: string | null } = {},
  ): Promise<{ response: APIResponse; body: unknown }> {
    const response = await this.get(path, options);
    let body: unknown = null;
    try {
      body = await response.json();
    } catch {
      body = null;
    }
    return { response, body };
  }
}

/**
 * Finds the list payload in a response body without assuming the exact
 * envelope shape: accepts a bare array, `{ data: [...] }`, or
 * `{ data: { items: [...] } }`.
 */
export function listFrom(body: unknown): unknown[] | null {
  if (Array.isArray(body)) return body;
  if (body && typeof body === 'object') {
    const data = (body as Record<string, unknown>).data;
    if (Array.isArray(data)) return data;
    if (data && typeof data === 'object') {
      const items = (data as Record<string, unknown>).items;
      if (Array.isArray(items)) return items;
    }
  }
  return null;
}
