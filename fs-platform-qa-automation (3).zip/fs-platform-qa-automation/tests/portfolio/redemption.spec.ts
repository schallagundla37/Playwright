import { test, expect } from '../../src/fixtures/test-fixtures';
import { env } from '../../src/config/env';
import { PortfolioPage } from '../../src/pages/portfolio.page';
import { seededDefects } from '../../src/data/seeded-defects';
import { trace } from '../../src/utils/traceability';

/**
 * Module: Redemption (GET/POST /redeem/{holdingId})
 * Coverage: over-redemption boundaries (units and amount), mandatory
 *           declaration, successful redemption reflected in the portfolio,
 *           holding value consistency.
 * The target holding is discovered at runtime (first holding with units > 0)
 * so the specs stay independent of accumulated test data.
 */

/** Finds the first holding with redeemable units and returns its id + units. */
async function firstRedeemableHolding(
  portfolioPage: PortfolioPage,
): Promise<{ holdingId: string; units: number }> {
  await portfolioPage.goto();
  const rowCount = await portfolioPage.holdingRows.count();
  for (let i = 0; i < rowCount; i++) {
    const row = portfolioPage.holdingRows.nth(i);
    const unitsText = await row.locator('[data-testid^="holding-units-"]').innerText();
    const units = PortfolioPage.parseAmount(unitsText);
    if (units > 0) {
      const testId = (await row.getAttribute('data-testid'))!;
      return { holdingId: testId.replace('holding-row-', ''), units };
    }
  }
  throw new Error('No holding with redeemable units found for this user.');
}

test.describe('Redemption', { tag: ['@redemption', '@regression'] }, () => {
  test.beforeEach(async ({ loggedInDashboard }) => {
    void loggedInDashboard;
  });

  test('TC-RED-001: redeeming more units than available is rejected', async ({
    portfolioPage,
    redemptionPage,
  }) => {
    trace(test.info(), { testCaseId: 'TC-RED-001', risk: 'RED-R1 over-redemption guard' });

    const { holdingId } = await firstRedeemableHolding(portfolioPage);
    await redemptionPage.goto(holdingId);
    const available = await redemptionPage.availableUnitsCount();

    await redemptionPage.redeem({ mode: 'units', units: available + 10 });
    await redemptionPage.expectStillOnForm();
  });

  test('TC-RED-002: redeeming more than the holding value is rejected', async ({
    portfolioPage,
    redemptionPage,
  }) => {
    trace(test.info(), { testCaseId: 'TC-RED-002', risk: 'RED-R1 over-redemption guard' });

    const { holdingId } = await firstRedeemableHolding(portfolioPage);
    await redemptionPage.goto(holdingId);
    const availableValue = await redemptionPage.availableValueAmount();

    await redemptionPage.redeem({ mode: 'amount', amount: availableValue + 10_000 });
    await redemptionPage.expectStillOnForm();
  });

  test('TC-RED-003: redemption without the declaration is rejected', async ({
    portfolioPage,
    redemptionPage,
  }) => {
    trace(test.info(), { testCaseId: 'TC-RED-003', risk: 'RED-R2 mandatory declaration' });

    const { holdingId } = await firstRedeemableHolding(portfolioPage);
    await redemptionPage.goto(holdingId);
    await redemptionPage.fillForm({ mode: 'units', units: 1, acceptDeclaration: false });
    await redemptionPage.submit();
    await redemptionPage.expectStillOnForm();
  });

  test(
    'TC-RED-004: partial redemption by units reduces the holding',
    { tag: '@smoke' },
    async ({ portfolioPage, redemptionPage, page }) => {
      trace(test.info(), { testCaseId: 'TC-RED-004', risk: 'RED-R3 redemption flow' });

      const { holdingId, units: unitsBefore } = await firstRedeemableHolding(portfolioPage);
      const redeemUnits = 1.5;
      expect(unitsBefore).toBeGreaterThan(redeemUnits);

      await redemptionPage.goto(holdingId);
      await redemptionPage.redeem({ mode: 'units', units: redeemUnits });

      // A successful request leaves the form (confirmation / redirect).
      await expect(page).not.toHaveURL(new RegExp(`/redeem/${holdingId}$`));

      await portfolioPage.goto();
      const unitsAfter = PortfolioPage.parseAmount(
        await portfolioPage.units(holdingId).innerText(),
      );
      expect(unitsBefore - unitsAfter).toBeCloseTo(redeemUnits, 3);
    },
  );

  test(
    'TC-RED-005: holding value equals units × current NAV',
    { tag: '@seeded-defect' },
    async ({ portfolioPage, redemptionPage }) => {
      trace(test.info(), {
        testCaseId: 'TC-RED-005',
        risk: 'RED-R4 value integrity',
        defect: seededDefects.SD_VALUE_01,
      });
      test.fail(env.seededDefectBuild, seededDefects.SD_VALUE_01.id);

      const { holdingId } = await firstRedeemableHolding(portfolioPage);
      await redemptionPage.goto(holdingId);

      const units = await redemptionPage.availableUnitsCount();
      const nav = await redemptionPage.currentNav();
      const shownValue = await redemptionPage.availableValueAmount();

      // Allow a paisa of rounding; anything more is a calculation defect.
      expect(Math.abs(shownValue - units * nav)).toBeLessThanOrEqual(0.02);
    },
  );
});
