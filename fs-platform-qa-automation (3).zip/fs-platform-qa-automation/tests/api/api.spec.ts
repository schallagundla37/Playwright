import { test, expect } from '@playwright/test';
import { ApiClient, listFrom } from '../../src/api/api-client';
import { env } from '../../src/config/env';
import { funds, insuranceProducts } from '../../src/data/test-data';
import { trace } from '../../src/utils/traceability';

/**
 * Module: API layer (feature guide, section 7)
 * Coverage: health, X-API-Key authorization, catalog consistency with the
 *           seeded data (and therefore with the UI listings, which assert the
 *           same catalog), login validation, unknown-resource handling.
 * Runs in the browserless `api` project.
 */
test.describe('API', { tag: ['@api', '@regression'] }, () => {
  test(
    'TC-API-001: health endpoint responds with the valid key',
    { tag: '@smoke' },
    async ({ request }) => {
      trace(test.info(), { testCaseId: 'TC-API-001', risk: 'API-R1 availability' });

      const client = new ApiClient(request);
      const response = await client.get('/health');
      expect(response.status()).toBe(200);
    },
  );

  test(
    'TC-API-002: requests without or with an invalid key are unauthorized',
    { tag: '@smoke' },
    async ({ request }) => {
      trace(test.info(), { testCaseId: 'TC-API-002', risk: 'API-R2 authorization' });

      const client = new ApiClient(request);
      for (const endpoint of ['/mutual-funds', '/insurance-products', '/dashboard']) {
        const withoutKey = await client.get(endpoint, { key: null });
        expect(withoutKey.status(), `${endpoint} without key`).toBe(401);

        const wrongKey = await client.get(endpoint, { key: 'not-the-real-key' });
        expect(wrongKey.status(), `${endpoint} with invalid key`).toBe(401);
      }
    },
  );

  test('TC-API-003: mutual fund list matches the seeded catalog', async ({ request }) => {
    trace(test.info(), { testCaseId: 'TC-API-003', risk: 'API-R3 UI/API consistency' });

    const client = new ApiClient(request);
    const { response, body } = await client.getJson('/mutual-funds');
    expect(response.status()).toBe(200);

    const list = listFrom(body);
    expect(list, 'response should contain a fund list').not.toBeNull();
    expect(list!).toHaveLength(funds.length);

    // Every seeded fund code appears in the API payload — the same catalog
    // the UI listing specs assert, giving UI/API reconciliation.
    const payload = JSON.stringify(list);
    for (const fund of funds) {
      expect(payload, `fund ${fund.code} present`).toContain(fund.code);
    }
  });

  test('TC-API-004: insurance product list matches the seeded catalog', async ({ request }) => {
    trace(test.info(), { testCaseId: 'TC-API-004', risk: 'API-R3 UI/API consistency' });

    const client = new ApiClient(request);
    const { response, body } = await client.getJson('/insurance-products');
    expect(response.status()).toBe(200);

    const list = listFrom(body);
    expect(list, 'response should contain a product list').not.toBeNull();
    expect(list!).toHaveLength(insuranceProducts.length);

    const payload = JSON.stringify(list);
    for (const product of insuranceProducts) {
      expect(payload, `product ${product.code} present`).toContain(product.code);
    }
  });

  test('TC-API-005: fund detail returns the requested fund; unknown id is 404', async ({
    request,
  }) => {
    trace(test.info(), { testCaseId: 'TC-API-005', risk: 'API-R4 resource handling' });

    const client = new ApiClient(request);

    const detail = await client.getJson('/mutual-funds/1');
    expect(detail.response.status()).toBe(200);
    expect(JSON.stringify(detail.body)).toContain('FSBLU001');

    const missing = await client.get('/mutual-funds/999999');
    expect(missing.status()).toBe(404);
  });

  test('TC-API-006: login endpoint validates credentials', async ({ request }) => {
    trace(test.info(), { testCaseId: 'TC-API-006', risk: 'API-R5 login validation' });

    const client = new ApiClient(request);

    const valid = await client.post('/login', {
      email: env.users.valid.email,
      password: env.users.valid.password,
    });
    expect(valid.ok(), `valid login responded ${valid.status()}`).toBe(true);

    const invalid = await client.post('/login', {
      email: env.users.valid.email,
      password: env.invalidPassword,
    });
    expect([401, 422]).toContain(invalid.status());
  });
});
