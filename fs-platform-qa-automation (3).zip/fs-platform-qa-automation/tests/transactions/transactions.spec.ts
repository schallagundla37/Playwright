import { test, expect } from '../../src/fixtures/test-fixtures';
import { trace } from '../../src/utils/traceability';

const ALLOWED_TYPES = ['Investment', 'Redemption', 'Premium Payment', 'Refund', 'Failed Payment'];
const ALLOWED_STATUSES = ['SUCCESS', 'PENDING', 'FAILED', 'CANCELLED'];

/**
 * Module: Transactions (GET /transactions)
 * Coverage: row integrity against the allowed type/status sets, search by
 *           reference, type/status/date filters, detail navigation,
 *           pagination.
 */
test.describe('Transactions', { tag: ['@transactions', '@regression'] }, () => {
  test.beforeEach(async ({ loggedInDashboard, transactionsPage }) => {
    void loggedInDashboard;
    await transactionsPage.goto();
  });

  test(
    'TC-TRN-001: listing shows well-formed rows with allowed types and statuses',
    { tag: '@smoke' },
    async ({ transactionsPage }) => {
      trace(test.info(), { testCaseId: 'TC-TRN-001', risk: 'TRN-R1 data integrity' });

      await expect(transactionsPage.rows.first()).toBeVisible();
      await expect(transactionsPage.resultsSummary).toContainText(/Showing .* of .* results/);

      for (const reference of await transactionsPage.rows.evaluateAll((rows) =>
        rows.map((r) => r.getAttribute('data-testid')!.replace('transaction-row-', '')),
      )) {
        expect(reference).toMatch(/^TXN-\d+-[A-Z0-9]+$/);
      }
      for (const type of await transactionsPage.typeCells.allInnerTexts()) {
        expect(ALLOWED_TYPES).toContain(type.trim());
      }
      for (const status of await transactionsPage.statusPills.allInnerTexts()) {
        expect(ALLOWED_STATUSES).toContain(status.trim());
      }
    },
  );

  test('TC-TRN-002: type filter shows only transactions of that type', async ({
    transactionsPage,
  }) => {
    trace(test.info(), { testCaseId: 'TC-TRN-002', risk: 'TRN-R2 filters' });

    await transactionsPage.filter({ type: 'Investment' });
    const types = await transactionsPage.typeCells.allInnerTexts();
    expect(types.length).toBeGreaterThan(0);
    for (const type of types) {
      expect(type.trim()).toBe('Investment');
    }
  });

  test('TC-TRN-003: status filter shows only transactions in that status', async ({
    transactionsPage,
  }) => {
    trace(test.info(), { testCaseId: 'TC-TRN-003', risk: 'TRN-R2 filters' });

    await transactionsPage.filter({ status: 'SUCCESS' });
    const statuses = await transactionsPage.statusPills.allInnerTexts();
    expect(statuses.length).toBeGreaterThan(0);
    for (const status of statuses) {
      expect(status.trim()).toBe('SUCCESS');
    }
  });

  test('TC-TRN-004: search by reference returns exactly that transaction', async ({
    transactionsPage,
  }) => {
    trace(test.info(), { testCaseId: 'TC-TRN-004', risk: 'TRN-R3 search' });

    const reference = await transactionsPage.firstReference();
    await transactionsPage.filter({ search: reference });
    await expect(transactionsPage.rows).toHaveCount(1);
    await expect(transactionsPage.row(reference)).toBeVisible();
  });

  test('TC-TRN-005: date range filter excludes transactions outside the range', async ({
    transactionsPage,
  }) => {
    trace(test.info(), { testCaseId: 'TC-TRN-005', risk: 'TRN-R2 filters' });

    const dateTo = '2026-08-31';
    await transactionsPage.filter({ dateFrom: '2020-01-01', dateTo });

    // Every remaining row must be dated on or before the range end.
    const rowCount = await transactionsPage.rows.count();
    for (let i = 0; i < rowCount; i++) {
      const dateText = (
        await transactionsPage.rows.nth(i).locator('td').nth(1).innerText()
      ).trim();
      const rowDate = new Date(dateText);
      expect(rowDate.getTime(), `row date "${dateText}" within range`).toBeLessThanOrEqual(
        new Date(`${dateTo}T23:59:59`).getTime(),
      );
    }
  });

  test('TC-TRN-006: View opens the transaction detail route', async ({ transactionsPage, page }) => {
    trace(test.info(), { testCaseId: 'TC-TRN-006', risk: 'TRN-R4 detail navigation' });

    const reference = await transactionsPage.firstReference();
    await transactionsPage.openDetails(reference);
    await expect(page).toHaveURL(/\/transactions\/\d+$/);
  });

  test('TC-TRN-007: pagination navigates to the next page of results', async ({
    transactionsPage,
    page,
  }) => {
    trace(test.info(), { testCaseId: 'TC-TRN-007', risk: 'TRN-R5 pagination' });

    const hasNext = (await transactionsPage.nextPageLink.count()) > 0;
    test.skip(!hasNext, 'Only one page of transactions for this user right now.');

    const firstPageReference = await transactionsPage.firstReference();
    await transactionsPage.nextPageLink.click();
    await expect(page).toHaveURL(/page=2/);
    await expect(transactionsPage.rows.first()).toBeVisible();
    expect(await transactionsPage.firstReference()).not.toBe(firstPageReference);
  });
});
