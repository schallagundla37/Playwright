import { test, expect } from '../../src/fixtures/test-fixtures';
import { env } from '../../src/config/env';
import { trace } from '../../src/utils/traceability';

/**
 * Module: Profile (GET /profile)
 * Coverage: identity of the logged-in user, PAN masking, allowed KYC/account
 *           status values, field completeness.
 */
test.describe('Profile', { tag: ['@profile', '@regression'] }, () => {
  test.beforeEach(async ({ loggedInDashboard, profilePage }) => {
    void loggedInDashboard;
    await profilePage.goto();
  });

  test(
    'TC-PROF-001: profile shows the logged-in customer identity',
    { tag: '@smoke' },
    async ({ profilePage }) => {
      trace(test.info(), { testCaseId: 'TC-PROF-001', risk: 'PROF-R1 identity scoping' });

      await expect(profilePage.email).toHaveText(env.users.valid.email);
      await expect(profilePage.name).not.toBeEmpty();
      await expect(profilePage.mobile).toHaveText(/^\d{10}$/);
    },
  );

  test('TC-PROF-002: PAN is masked and never shown in full', async ({ profilePage }) => {
    trace(test.info(), { testCaseId: 'TC-PROF-002', risk: 'PROF-R2 PII masking' });

    const pan = (await profilePage.pan.innerText()).trim();
    // Masked form like ABCDE****F: contains asterisks…
    expect(pan).toMatch(/\*{3,}/);
    // …and is never a complete unmasked PAN (5 letters + 4 digits + 1 letter).
    expect(pan).not.toMatch(/^[A-Z]{5}\d{4}[A-Z]$/);
  });

  test('TC-PROF-003: KYC and account status show allowed values only', async ({
    profilePage,
  }) => {
    trace(test.info(), { testCaseId: 'TC-PROF-003', risk: 'PROF-R3 status integrity' });

    await expect(profilePage.kycStatus).toHaveText(/^(VERIFIED|PENDING|REJECTED)$/);
    await expect(profilePage.accountStatus).toHaveText(/^(ACTIVE|LOCKED)$/);
    await expect(profilePage.learnerCode).not.toBeEmpty();
  });
});
