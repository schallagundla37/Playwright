import { test, expect } from '../../src/fixtures/test-fixtures';
import { trace } from '../../src/utils/traceability';

/**
 * Module: Support (GET/POST /support)
 * Coverage: successful ticket submission, message length validation,
 *           mandatory category, cancel path.
 */
test.describe('Support', { tag: ['@support', '@regression'] }, () => {
  test.beforeEach(async ({ loggedInDashboard, supportPage }) => {
    void loggedInDashboard;
    await supportPage.goto();
  });

  test(
    'TC-SUP-001: support request submits and confirms',
    { tag: '@smoke' },
    async ({ supportPage }) => {
      trace(test.info(), { testCaseId: 'TC-SUP-001', risk: 'SUP-R1 ticket submission' });

      const message = `QA automation test ticket ${Date.now()} — please ignore.`;
      await supportPage.submitRequest('Other', message);
      await expect(supportPage.successFlash).toBeVisible();
    },
  );

  test('TC-SUP-002: message shorter than 10 characters is rejected', async ({
    supportPage,
    page,
  }) => {
    trace(test.info(), { testCaseId: 'TC-SUP-002', risk: 'SUP-R2 input validation' });

    await supportPage.submitRequest('Other', 'too short');
    // 9 characters: the request must not be accepted.
    await expect(page).toHaveURL(/\/support/);
    await expect(supportPage.successFlash).not.toBeVisible();
  });

  test('TC-SUP-003: category is mandatory', async ({ supportPage, page }) => {
    trace(test.info(), { testCaseId: 'TC-SUP-003', risk: 'SUP-R2 input validation' });

    await supportPage.submitRequest('', 'A sufficiently long test message.');
    await expect(page).toHaveURL(/\/support/);
    await expect(supportPage.successFlash).not.toBeVisible();
  });

  test('TC-SUP-004: cancel returns to the dashboard', async ({
    supportPage,
    dashboardPage,
  }) => {
    trace(test.info(), { testCaseId: 'TC-SUP-004', risk: 'SUP-R3 cancel path' });

    await supportPage.cancelLink.click();
    await dashboardPage.expectLoaded();
  });
});
