import { test, expect } from '../../src/fixtures/test-fixtures';
import { bluechipFundDetail } from '../../src/data/test-data';
import { PortfolioPage } from '../../src/pages/portfolio.page';
import { trace } from '../../src/utils/traceability';

/**
 * Module: Investment (GET/POST /invest/{fundId})
 * Coverage: minimum-amount boundaries for lumpsum and SIP, mandatory
 *           declaration/payment method, successful investment reflected in
 *           the portfolio, cancel path.
 * Boundary values derive from the fund's own summary card at runtime and are
 * cross-checked against the seeded catalog (FSBLU001: lumpsum ₹5,000, SIP ₹500).
 */
test.describe('Investment', { tag: ['@investment', '@regression'] }, () => {
  test.beforeEach(async ({ loggedInDashboard, investmentPage }) => {
    void loggedInDashboard;
    await investmentPage.goto(bluechipFundDetail.id);
  });

  test('TC-INV-001: lumpsum below the fund minimum is rejected', async ({ investmentPage }) => {
    trace(test.info(), { testCaseId: 'TC-INV-001', risk: 'INV-R1 amount validation' });

    const minLumpsum = await investmentPage.summaryAmount('Minimum Lumpsum');
    expect(minLumpsum).toBe(bluechipFundDetail.minimumLumpsum);

    await investmentPage.invest({ type: 'Lumpsum', amount: minLumpsum - 1 });
    await investmentPage.expectStillOnForm();
  });

  test('TC-INV-002: SIP below the fund minimum is rejected', async ({ investmentPage }) => {
    trace(test.info(), { testCaseId: 'TC-INV-002', risk: 'INV-R1 amount validation' });

    const minSip = await investmentPage.summaryAmount('Minimum SIP');
    expect(minSip).toBe(bluechipFundDetail.minimumSip);

    await investmentPage.invest({ type: 'SIP', amount: minSip - 1 });
    await investmentPage.expectStillOnForm();
  });

  test('TC-INV-003: investment without the declaration is rejected', async ({
    investmentPage,
  }) => {
    trace(test.info(), { testCaseId: 'TC-INV-003', risk: 'INV-R2 mandatory declaration' });

    await investmentPage.fillForm({
      type: 'Lumpsum',
      amount: bluechipFundDetail.minimumLumpsum,
      paymentMethod: 'UPI',
      acceptDeclaration: false,
    });
    await investmentPage.submit();
    await investmentPage.expectStillOnForm();
  });

  test('TC-INV-004: investment without a payment method is rejected', async ({
    investmentPage,
  }) => {
    trace(test.info(), { testCaseId: 'TC-INV-004', risk: 'INV-R3 mandatory payment method' });

    await investmentPage.fillForm({
      type: 'Lumpsum',
      amount: bluechipFundDetail.minimumLumpsum,
      acceptDeclaration: true,
    });
    await investmentPage.submit();
    await investmentPage.expectStillOnForm();
  });

  test(
    'TC-INV-005: lumpsum at the fund minimum invests and updates the portfolio',
    { tag: '@smoke' },
    async ({ investmentPage, portfolioPage, page }) => {
      trace(test.info(), { testCaseId: 'TC-INV-005', risk: 'INV-R4 investment flow' });

      // Baseline: invested total before the order.
      await portfolioPage.goto();
      const investedBefore = PortfolioPage.parseAmount(
        await portfolioPage.investedTotal.innerText(),
      );

      await investmentPage.goto(bluechipFundDetail.id);
      await investmentPage.invest({
        type: 'Lumpsum',
        amount: bluechipFundDetail.minimumLumpsum,
      });

      // A successful order leaves the form (confirmation / redirect).
      await expect(page).not.toHaveURL(/\/invest\/\d+$/);

      // The portfolio's invested total grows by exactly the order amount.
      await portfolioPage.goto();
      const investedAfter = PortfolioPage.parseAmount(
        await portfolioPage.investedTotal.innerText(),
      );
      expect(investedAfter - investedBefore).toBeCloseTo(
        bluechipFundDetail.minimumLumpsum,
        1,
      );

      // And the fund appears as an active holding with non-zero units.
      const holding = portfolioPage.holdingRowByFund(bluechipFundDetail.code).first();
      await expect(holding).toBeVisible();
    },
  );

  test('TC-INV-006: cancel returns to the fund detail without investing', async ({
    investmentPage,
    page,
  }) => {
    trace(test.info(), { testCaseId: 'TC-INV-006', risk: 'INV-R5 cancel path' });

    await investmentPage.cancel();
    await expect(page).toHaveURL(new RegExp(`/mutual-funds/${bluechipFundDetail.id}$`));
  });
});
