import { test, expect } from '../../src/fixtures/test-fixtures';
import {
  funds,
  topReturnFundCode,
  lowestNavFundCode,
  bluechipFundDetail,
} from '../../src/data/test-data';
import { trace } from '../../src/utils/traceability';

/**
 * Module: Mutual Funds listing (GET /mutual-funds)
 * Coverage: seeded listing, search, category/risk filters, sorting, reset.
 */
test.describe('Mutual Funds', { tag: ['@mutual-funds', '@regression'] }, () => {
  test.beforeEach(async ({ loggedInDashboard, mutualFundsPage }) => {
    void loggedInDashboard;
    await mutualFundsPage.goto();
  });

  test(
    'TC-FUND-001: listing shows all seeded funds',
    { tag: '@smoke' },
    async ({ mutualFundsPage }) => {
      trace(test.info(), { testCaseId: 'TC-FUND-001', risk: 'FUND-R1 catalog visibility' });

      await expect(mutualFundsPage.fundCards).toHaveCount(funds.length);
      for (const fund of funds) {
        await expect(mutualFundsPage.fundCard(fund.code)).toBeVisible();
      }
    },
  );

  test('TC-FUND-002: search narrows the listing to matching funds', async ({
    mutualFundsPage,
  }) => {
    trace(test.info(), { testCaseId: 'TC-FUND-002', risk: 'FUND-R2 search' });

    await mutualFundsPage.filter({ search: 'Bluechip' });
    await expect(mutualFundsPage.fundCards).toHaveCount(1);
    await expect(mutualFundsPage.fundCard('FSBLU001')).toBeVisible();
  });

  test('TC-FUND-003: category filter returns exactly the seeded members', async ({
    mutualFundsPage,
  }) => {
    trace(test.info(), { testCaseId: 'TC-FUND-003', risk: 'FUND-R3 filters' });

    for (const category of ['ELSS', 'Index Fund', 'Debt Fund'] as const) {
      const expected = funds.filter((f) => f.category === category);
      await mutualFundsPage.filter({ category });
      await expect(mutualFundsPage.fundCards).toHaveCount(expected.length);
      for (const fund of expected) {
        await expect(mutualFundsPage.fundCard(fund.code)).toBeVisible();
      }
      await mutualFundsPage.resetFilters();
    }
  });

  test('TC-FUND-004: risk filter returns exactly the seeded members', async ({
    mutualFundsPage,
  }) => {
    trace(test.info(), { testCaseId: 'TC-FUND-004', risk: 'FUND-R3 filters' });

    const lowRisk = funds.filter((f) => f.risk === 'Low');
    await mutualFundsPage.filter({ riskLevel: 'Low' });
    await expect(mutualFundsPage.fundCards).toHaveCount(lowRisk.length);
    for (const fund of lowRisk) {
      await expect(mutualFundsPage.fundCard(fund.code)).toBeVisible();
    }
  });

  test('TC-FUND-005: sorting by 1-year return puts the top performer first', async ({
    mutualFundsPage,
  }) => {
    trace(test.info(), { testCaseId: 'TC-FUND-005', risk: 'FUND-R4 sorting' });

    await mutualFundsPage.filter({ sort: 'one_year_return_desc' });
    const topFund = funds.find((f) => f.code === topReturnFundCode)!;
    await expect(mutualFundsPage.fundNames.first()).toHaveText(topFund.name);
  });

  test('TC-FUND-006: sorting by NAV ascending puts the cheapest NAV first', async ({
    mutualFundsPage,
  }) => {
    trace(test.info(), { testCaseId: 'TC-FUND-006', risk: 'FUND-R4 sorting' });

    await mutualFundsPage.filter({ sort: 'nav_asc' });
    const lowestNav = funds.find((f) => f.code === lowestNavFundCode)!;
    await expect(mutualFundsPage.fundNames.first()).toHaveText(lowestNav.name);
  });

  test('TC-FUND-007: reset restores the unfiltered listing', async ({ mutualFundsPage }) => {
    trace(test.info(), { testCaseId: 'TC-FUND-007', risk: 'FUND-R3 filters' });

    await mutualFundsPage.filter({ search: 'Bluechip' });
    await expect(mutualFundsPage.fundCards).toHaveCount(1);
    await mutualFundsPage.resetFilters();
    await expect(mutualFundsPage.fundCards).toHaveCount(funds.length);
  });

  test('TC-FUND-008: fund detail shows the seeded record consistent with the listing', async ({
    mutualFundsPage,
    fundDetailsPage,
    page,
  }) => {
    trace(test.info(), { testCaseId: 'TC-FUND-008', risk: 'FUND-R5 detail accuracy' });

    // Capture what the listing card shows, then verify the detail page agrees.
    const listedReturn = (
      await mutualFundsPage.fundReturn(bluechipFundDetail.code).innerText()
    ).trim();
    await mutualFundsPage.openFundDetails(bluechipFundDetail.code);
    await expect(page).toHaveURL(new RegExp(`/mutual-funds/${bluechipFundDetail.id}$`));

    await fundDetailsPage.expectLoaded();
    await expect(fundDetailsPage.fundName).toHaveText(bluechipFundDetail.name);
    await expect(fundDetailsPage.subtitle).toContainText(bluechipFundDetail.code);
    await expect(fundDetailsPage.nav).toHaveText(bluechipFundDetail.navText);
    await expect(fundDetailsPage.oneYearReturn).toHaveText(listedReturn);
    await expect(fundDetailsPage.minimumSip).toHaveText(/₹\s?500/);
    await expect(fundDetailsPage.minimumLumpsum).toHaveText(/₹\s?5,000/);
    for (const label of ['3-Year Return', 'Expense Ratio']) {
      await expect(fundDetailsPage.metric(label)).toHaveText(/[\d.]+%/);
    }
  });

  test('TC-FUND-009: Invest Now leads to the investment form for that fund', async ({
    fundDetailsPage,
    page,
  }) => {
    trace(test.info(), { testCaseId: 'TC-FUND-009', risk: 'FUND-R6 invest navigation' });

    await fundDetailsPage.goto(bluechipFundDetail.id);
    await fundDetailsPage.investNow();
    await expect(page).toHaveURL(new RegExp(`/invest/${bluechipFundDetail.id}$`));
  });
});
