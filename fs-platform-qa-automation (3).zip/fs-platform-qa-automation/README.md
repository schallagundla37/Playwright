# FinServe Retail Platform — Playwright QA Automation

Black-box UI + API automation for the **FinServe Retail Demo Platform**
(Playwright lab, port 8082), covering authentication, dashboard, mutual fund
discovery, insurance discovery and purchase, policies, and portfolio — plus a
browserless API project against the platform's REST layer.

All locators and seeded-data assertions are derived from the **live
application's captured DOM**, not guessed from documentation.

## Prerequisites

- Node.js 18+ and npm
- The FinServe app reachable (inside the lab VM: `http://127.0.0.1:8082`)

## Setup

```bash
npm install
npx playwright install
copy .env.example .env    # then adjust if your environment differs
```

`.env` ships with the lab defaults (base URL, the five seed users from the
feature guide section 9, and the static API key). Never commit `.env`.

## Running tests

| Command | What it runs |
|---|---|
| `npm test` | Full suite (UI projects per `BROWSERS` + API project) |
| `npm run test:smoke` | `@smoke` — login, listings, purchase e2e, API health/auth |
| `npm run test:regression` | Full `@regression` coverage |
| `npm run test:auth` / `test:dashboard` / `test:funds` / `test:investment` / `test:insurance` / `test:purchase` / `test:policies` / `test:portfolio` / `test:redemption` / `test:transactions` / `test:profile` / `test:support` | One module |
| `npm run test:api` | API project only (browserless) |
| `npm run test:defects` | `@seeded-defect` — the defect-detection specs |
| `npm run test:headed` / `test:debug` | Headed / inspector mode |
| `npm run report` | Open the HTML report |
| `npm run typecheck` | `tsc --noEmit` |

Cross-browser: set `BROWSERS=chromium,firefox,webkit` in `.env`.

## Structure

```
src/
  config/env.ts        typed access to all environment values
  pages/               page objects (real DOM hooks documented per file)
  fixtures/            Playwright fixtures incl. loginAs / loggedInDashboard
  api/api-client.ts    X-API-Key request wrapper for the API project
  data/test-data.ts    seeded catalog facts observed on the live app
  data/seeded-defects.ts  provisional seeded-defect catalog
  utils/               traceability annotations, date helpers
tests/
  auth/ dashboard/ mutual-funds/ insurance/ policies/ portfolio/
  transactions/ profile/ support/ smoke/ api/
```

## Test design

- **Traceability**: every test carries a `TC-…` id and risk annotation
  (`trace()`), visible in the HTML report.
- **Locator strategy**: user-facing role/label locators first, `data-testid`
  where the DOM offers no stable accessible handle.
- **Deterministic assertions**: filters/sorts assert exact seeded membership
  (12 funds, 8 insurance products); portfolio summary is recomputed from the
  holdings rows; the e2e purchase verifies policy number, transaction
  reference, policy detail, list membership, and the dashboard count delta.

### Seeded-defect strategy

Specs tagged `@seeded-defect` assert **correct** behavior for suspected
seeded defects (locked login, premium consistency on `/buy-insurance`,
zero-unit redemption guards, eligibility DOB). With
`SEEDED_DEFECT_BUILD=false` a failure of one of these specs — with its trace,
screenshot, and video — is the detection evidence for the defect. Set
`SEEDED_DEFECT_BUILD=true` to mark them as expected failures
(`test.fail`) on a build known to contain the defects.

## Evidence

Failures retain trace (`npx playwright show-trace`), screenshot, and video
under `test-results/`; the HTML report lands in `playwright-report/`; JUnit
XML at `test-results/junit-results.xml`.

## CI

`.github/workflows/playwright.yml`:

- **Pull request / manual**: typecheck + `@smoke` on Chromium
- **Push to main / nightly (02:00 UTC)**: typecheck + full suite on
  Chromium/Firefox/WebKit + API project
- Reports and failure evidence are uploaded as artifacts (14-day retention)
- Credentials come from repository **secrets** (same names as `.env`)

GitHub-hosted runners must be able to reach the app: point `BASE_URL` /
`API_BASE_URL` secrets at the VM's public IP, or use a self-hosted runner
inside the lab VM.

## Known limitations / roadmap

- The failed-login error locator and the post-submit confirmation pages for
  investments/redemptions cover plausible markup variants; they will be
  tightened once DOM captures of those states are available.
- Transaction *detail* (`/transactions/{id}`) assertions stop at the URL —
  that page's markup has not been captured yet.
- The seeded-defect catalog is provisional (no answer key is distributed);
  IDs live in one map (`src/data/seeded-defects.ts`) for easy renaming.
  Current suspects: SD-AUTH-01 (locked login), SD-PREMIUM-01 (buy-insurance
  premium consistency), SD-REDEEM-01 (zero-unit redeem action),
  SD-VALUE-01 (holding value ≠ units × NAV on /redeem), SD-ELIG-01
  (eligibility DOB).
