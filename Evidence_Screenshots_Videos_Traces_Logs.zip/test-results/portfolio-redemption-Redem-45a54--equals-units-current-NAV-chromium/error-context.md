# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: portfolio\redemption.spec.ts >> Redemption >> TC-RED-005: holding value equals units × current NAV
- Location: tests\portfolio\redemption.spec.ts:104:7

# Error details

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 0.02
Received:    1.6860500000184402
```

# Page snapshot

```yaml
- generic [ref=f3e2]:
  - banner [ref=f3e3]:
    - link "FS FinServe Retail" [ref=f3e4] [cursor=pointer]:
      - /url: http://127.0.0.1:8082/dashboard
      - generic [ref=f3e5]: FS
      - generic [ref=f3e6]: FinServe Retail
    - navigation "Main navigation" [ref=f3e7]:
      - link "Dashboard" [ref=f3e8] [cursor=pointer]:
        - /url: http://127.0.0.1:8082/dashboard
      - link "Mutual Funds" [ref=f3e9] [cursor=pointer]:
        - /url: http://127.0.0.1:8082/mutual-funds
      - link "Portfolio" [ref=f3e10] [cursor=pointer]:
        - /url: http://127.0.0.1:8082/portfolio
      - link "Insurance" [ref=f3e11] [cursor=pointer]:
        - /url: http://127.0.0.1:8082/insurance
      - link "Policies" [ref=f3e12] [cursor=pointer]:
        - /url: http://127.0.0.1:8082/policies
      - link "Transactions" [ref=f3e13] [cursor=pointer]:
        - /url: http://127.0.0.1:8082/transactions
      - link "Support" [ref=f3e14] [cursor=pointer]:
        - /url: http://127.0.0.1:8082/support
      - link "Profile" [ref=f3e15] [cursor=pointer]:
        - /url: http://127.0.0.1:8082/profile
    - generic [ref=f3e16]:
      - generic [ref=f3e17]: Arjun Mehta
      - button "Logout" [ref=f3e19] [cursor=pointer]
  - main [ref=f3e20]:
    - generic [ref=f3e21]:
      - generic [ref=f3e22]:
        - link "← Back to Portfolio" [ref=f3e23] [cursor=pointer]:
          - /url: http://127.0.0.1:8082/portfolio
        - heading "Redeem Mutual Fund Holding" [level=1] [ref=f3e24]
        - paragraph [ref=f3e25]: Submit a simulated redemption request for your selected holding.
      - generic [ref=f3e26]:
        - generic [ref=f3e28]:
          - heading "Holding Summary" [level=2] [ref=f3e30]
          - generic [ref=f3e31]:
            - generic [ref=f3e32]:
              - generic [ref=f3e33]: Fund
              - generic [ref=f3e34]: FinServe Bluechip Equity Fund
            - generic [ref=f3e35]:
              - generic [ref=f3e36]:
                - generic [ref=f3e37]: Available Units
                - generic [ref=f3e38]: "767.1710"
              - generic [ref=f3e39]:
                - generic [ref=f3e40]: Current Value
                - generic [ref=f3e41]: ₹109,358.54
              - generic [ref=f3e42]:
                - generic [ref=f3e43]: Current NAV
                - generic [ref=f3e44]: ₹142.55
              - generic [ref=f3e45]:
                - generic [ref=f3e46]: Folio
                - generic [ref=f3e47]: FOL-ARJ-001
        - generic [ref=f3e49]:
          - heading "Redemption Request" [level=2] [ref=f3e51]
          - generic [ref=f3e53]:
            - generic [ref=f3e54]:
              - generic [ref=f3e55]: Redemption Mode
              - generic [ref=f3e56]:
                - generic [ref=f3e57]:
                  - radio "By Units" [checked] [ref=f3e58]
                  - text: By Units
                - generic [ref=f3e59]:
                  - radio "By Amount" [ref=f3e60]
                  - text: By Amount
            - generic [ref=f3e61]:
              - generic [ref=f3e62]:
                - generic [ref=f3e63]: Units
                - spinbutton "Units" [ref=f3e64]
              - generic [ref=f3e65]:
                - generic [ref=f3e66]: Amount
                - spinbutton "Amount" [ref=f3e67]
            - generic [ref=f3e68]:
              - checkbox "I understand that redemption value is indicative and subject to applicable market and processing rules." [ref=f3e69]
              - generic [ref=f3e70]: I understand that redemption value is indicative and subject to applicable market and processing rules.
            - button "Confirm Redemption" [ref=f3e72] [cursor=pointer]
  - contentinfo [ref=f3e73]: FinServe Retail Demo Platform · Built for Playwright QA Automation Practice
```