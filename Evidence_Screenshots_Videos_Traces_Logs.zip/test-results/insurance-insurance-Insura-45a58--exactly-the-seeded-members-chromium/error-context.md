# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: insurance\insurance.spec.ts >> Insurance Products >> TC-INS-002: type filter returns exactly the seeded members
- Location: tests\insurance\insurance.spec.ts:29:7

# Error details

```
Error: expect(page).toHaveURL(expected) failed

Expected pattern: /\/insurance/
Received string:  "http://127.0.0.1:8082/dashboard"
Timeout: 10000ms

Call log:
  - Expect "toHaveURL" with timeout 10000ms
    22 × locator resolved to <html lang="en">…</html>
       - unexpected value "http://127.0.0.1:8082/dashboard"

```

```yaml
- banner:
  - link "FS FinServe Retail":
    - /url: http://127.0.0.1:8082/dashboard
  - navigation "Main navigation":
    - link "Dashboard":
      - /url: http://127.0.0.1:8082/dashboard
    - link "Mutual Funds":
      - /url: http://127.0.0.1:8082/mutual-funds
    - link "Portfolio":
      - /url: http://127.0.0.1:8082/portfolio
    - link "Insurance":
      - /url: http://127.0.0.1:8082/insurance
    - link "Policies":
      - /url: http://127.0.0.1:8082/policies
    - link "Transactions":
      - /url: http://127.0.0.1:8082/transactions
    - link "Support":
      - /url: http://127.0.0.1:8082/support
    - link "Profile":
      - /url: http://127.0.0.1:8082/profile
  - text: Arjun Mehta
  - button "Logout"
- main:
  - text: Customer Dashboard
  - heading "Welcome, Arjun Mehta" [level=1]
  - paragraph: Track your portfolio, policies, transactions, and recommended products.
  - text: Portfolio Value ₹197,482.95 Invested Amount ₹189,832.35 Gain / Loss ₹7,650.60 Active Policies 12
  - heading "Recent Transactions" [level=2]
  - paragraph: Latest account activity across investments, redemptions, and policies.
  - link "View all":
    - /url: http://127.0.0.1:8082/transactions
  - table:
    - rowgroup:
      - row "Reference Type Amount Status":
        - columnheader "Reference"
        - columnheader "Type"
        - columnheader "Amount"
        - columnheader "Status"
    - rowgroup:
      - row "TXN-20260904035458-FICEZ Premium Payment ₹14,500.00 SUCCESS":
        - cell "TXN-20260904035458-FICEZ"
        - cell "Premium Payment"
        - cell "₹14,500.00"
        - cell "SUCCESS"
      - row "TXN-20260904035440-VMHDO Premium Payment ₹14,500.00 SUCCESS":
        - cell "TXN-20260904035440-VMHDO"
        - cell "Premium Payment"
        - cell "₹14,500.00"
        - cell "SUCCESS"
      - row "TXN-20260904035255-D2YKK Redemption ₹213.82 SUCCESS":
        - cell "TXN-20260904035255-D2YKK"
        - cell "Redemption"
        - cell "₹213.82"
        - cell "SUCCESS"
      - row "TXN-20260904035229-AGWHZ Premium Payment ₹14,500.00 SUCCESS":
        - cell "TXN-20260904035229-AGWHZ"
        - cell "Premium Payment"
        - cell "₹14,500.00"
        - cell "SUCCESS"
      - row "TXN-20260904035142-JQEIG Premium Payment ₹14,500.00 SUCCESS":
        - cell "TXN-20260904035142-JQEIG"
        - cell "Premium Payment"
        - cell "₹14,500.00"
        - cell "SUCCESS"
  - heading "Recommended Mutual Funds" [level=2]
  - paragraph: Explore funds suitable for portfolio building.
  - link "Explore":
    - /url: http://127.0.0.1:8082/mutual-funds
  - heading "FinServe Midcap Opportunities Fund" [level=3]
  - paragraph: Equity Fund
  - text: Very High Risk 22.30% 1Y NAV ₹91.77
  - link "View details":
    - /url: http://127.0.0.1:8082/mutual-funds/3
  - heading "FinServe FastStart SIP Fund" [level=3]
  - paragraph: Equity Fund
  - text: High Risk 19.20% 1Y NAV ₹27.35
  - link "View details":
    - /url: http://127.0.0.1:8082/mutual-funds/11
  - heading "FinServe Bluechip Equity Fund" [level=3]
  - paragraph: Equity Fund
  - text: High Risk 18.60% 1Y NAV ₹142.55
  - link "View details":
    - /url: http://127.0.0.1:8082/mutual-funds/1
  - heading "Recommended Insurance Products" [level=2]
  - paragraph: Review insurance options based on seeded demo data.
  - link "Explore":
    - /url: http://127.0.0.1:8082/insurance
  - heading "FinServe Life Protect Term Plan" [level=3]
  - paragraph: Term Insurance
  - text: Cover ₹10,000,000 Premium ₹14,500 25 years
  - link "View details":
    - /url: http://127.0.0.1:8082/insurance/1
  - heading "FinServe Secure Future Term Plan" [level=3]
  - paragraph: Term Insurance
  - text: Cover ₹5,000,000 Premium ₹9,200 20 years
  - link "View details":
    - /url: http://127.0.0.1:8082/insurance/2
  - heading "FinServe Health Secure Plan" [level=3]
  - paragraph: Health Insurance
  - text: Cover ₹1,000,000 Premium ₹18,500 1 years
  - link "View details":
    - /url: http://127.0.0.1:8082/insurance/3
- contentinfo: FinServe Retail Demo Platform · Built for Playwright QA Automation Practice
```

# Test source

```ts
  1   | import { Locator, Page, expect } from '@playwright/test';
  2   | import { BasePage } from './base.page';
  3   | 
  4   | /** Premium range buckets offered by the listing filter (option values). */
  5   | export type PremiumRange = 'under_5000' | '5000_15000' | 'above_15000';
  6   | 
  7   | /**
  8   |  * Insurance product listing (GET /insurance).
  9   |  *
  10  |  * Real DOM hooks (captured 2026-09): wrapper `insurance-page`; GET filter form
  11  |  * `insurance-filter-form` with `insurance-search-input`,
  12  |  * `insurance-type-filter`, `premium-range-filter`, `insurance-filter-submit`
  13  |  * and an `insurance-filter-reset` link; product cards `insurance-card-{code}`
  14  |  * each carrying the name (h2), type badge, coverage
  15  |  * (`insurance-coverage-{code}`), premium (`insurance-premium-{code}`), term,
  16  |  * plus `insurance-details-link-{code}` → /insurance/{id} and
  17  |  * `buy-insurance-link-{code}` → /buy-insurance/{id}.
  18  |  */
  19  | export class InsurancePage extends BasePage {
  20  |   readonly container: Locator;
  21  |   readonly filterForm: Locator;
  22  |   readonly searchInput: Locator;
  23  |   readonly typeFilter: Locator;
  24  |   readonly premiumRangeFilter: Locator;
  25  |   readonly applyButton: Locator;
  26  |   readonly resetLink: Locator;
  27  | 
  28  |   constructor(page: Page) {
  29  |     super(page);
  30  |     this.container = page.getByTestId('insurance-page');
  31  |     this.filterForm = page.getByTestId('insurance-filter-form');
  32  |     this.searchInput = page.getByTestId('insurance-search-input');
  33  |     this.typeFilter = page.getByTestId('insurance-type-filter');
  34  |     this.premiumRangeFilter = page.getByTestId('premium-range-filter');
  35  |     this.applyButton = page.getByTestId('insurance-filter-submit');
  36  |     this.resetLink = page.getByTestId('insurance-filter-reset');
  37  |   }
  38  | 
  39  |   async goto(): Promise<void> {
  40  |     await this.page.goto('/insurance');
  41  |     await this.expectLoaded();
  42  |   }
  43  | 
  44  |   async expectLoaded(): Promise<void> {
> 45  |     await expect(this.page).toHaveURL(/\/insurance/);
      |                             ^ Error: expect(page).toHaveURL(expected) failed
  46  |     await expect(this.container).toBeVisible();
  47  |     await expect(this.searchInput).toBeVisible();
  48  |   }
  49  | 
  50  |   /** All product cards currently rendered by the listing. */
  51  |   get productCards(): Locator {
  52  |     return this.page.locator('[data-testid^="insurance-card-"]');
  53  |   }
  54  | 
  55  |   /** A specific product card by product code, e.g. FSLIFE001. */
  56  |   productCard(productCode: string): Locator {
  57  |     return this.page.getByTestId(`insurance-card-${productCode}`);
  58  |   }
  59  | 
  60  |   /** Coverage amount shown on a product card, e.g. "₹10,000,000". */
  61  |   coverage(productCode: string): Locator {
  62  |     return this.page.getByTestId(`insurance-coverage-${productCode}`);
  63  |   }
  64  | 
  65  |   /** Premium amount shown on a product card, e.g. "₹14,500". */
  66  |   premium(productCode: string): Locator {
  67  |     return this.page.getByTestId(`insurance-premium-${productCode}`);
  68  |   }
  69  | 
  70  |   /** Visible product names, in render order. */
  71  |   get productNames(): Locator {
  72  |     return this.productCards.getByRole('heading', { level: 2 });
  73  |   }
  74  | 
  75  |   /**
  76  |    * Apply filters via the GET form. Only the provided fields are touched;
  77  |    * the form submits and the page reloads with query parameters.
  78  |    */
  79  |   async filter(options: {
  80  |     search?: string;
  81  |     insuranceType?: string;
  82  |     premiumRange?: PremiumRange;
  83  |   }): Promise<void> {
  84  |     if (options.search !== undefined) await this.searchInput.fill(options.search);
  85  |     if (options.insuranceType !== undefined) {
  86  |       await this.typeFilter.selectOption(options.insuranceType);
  87  |     }
  88  |     if (options.premiumRange !== undefined) {
  89  |       await this.premiumRangeFilter.selectOption(options.premiumRange);
  90  |     }
  91  |     await this.applyButton.click();
  92  |     await this.expectLoaded();
  93  |   }
  94  | 
  95  |   async resetFilters(): Promise<void> {
  96  |     await this.resetLink.click();
  97  |     await this.expectLoaded();
  98  |   }
  99  | 
  100 |   /** Open a product's detail page via its View Details link. */
  101 |   async openProductDetails(productCode: string): Promise<void> {
  102 |     await this.page.getByTestId(`insurance-details-link-${productCode}`).click();
  103 |     await expect(this.page).toHaveURL(/\/insurance\/\d+/);
  104 |   }
  105 | 
  106 |   /** Jump straight into the purchase flow via the card's Buy link. */
  107 |   async buyProduct(productCode: string): Promise<void> {
  108 |     await this.page.getByTestId(`buy-insurance-link-${productCode}`).click();
  109 |     await expect(this.page).toHaveURL(/\/buy-insurance\/\d+/);
  110 |   }
  111 | }
  112 | 
```