# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: transactions\transactions.spec.ts >> Transactions >> TC-TRN-001: listing shows well-formed rows with allowed types and statuses
- Location: tests\transactions\transactions.spec.ts:19:7

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByTestId('transactions-pagination').locator('p').filter({ hasText: 'results' })
Timeout: 10000ms
Expected pattern: /Showing .* of .* results/
Received string:  "
                    Showing
                                            1
                        to
                        12
                                        of
                    28
                    results
                "

Call log:
  - Expect "toContainText" with timeout 10000ms
  - waiting for getByTestId('transactions-pagination').locator('p').filter({ hasText: 'results' })
    23 × locator resolved to <p class="text-sm text-gray-700 leading-5 dark:text-gray-600">…</p>
       - unexpected value "
                    Showing
                                            1
                        to
                        12
                                        of
                    28
                    results
                "

```

```yaml
- paragraph: Showing 1 to 12 of 28 results
```