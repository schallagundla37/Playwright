# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: policies\policies.spec.ts >> Policies >> TC-POL-001: policy list shows the customer policies
- Location: tests\policies\policies.spec.ts:16:7

# Error details

```
Error: expect(received).toMatch(expected)

Expected pattern: /^POL-\d{8}-[A-Z0-9]+$/
Received string:  "POL-KAV-001"
```

# Page snapshot

```yaml
- generic [ref=f2e2]:
  - banner [ref=f2e3]:
    - link "FS FinServe Retail" [ref=f2e4] [cursor=pointer]:
      - /url: http://127.0.0.1:8082/dashboard
      - generic [ref=f2e5]: FS
      - generic [ref=f2e6]: FinServe Retail
    - navigation "Main navigation" [ref=f2e7]:
      - link "Dashboard" [ref=f2e8] [cursor=pointer]:
        - /url: http://127.0.0.1:8082/dashboard
      - link "Mutual Funds" [ref=f2e9] [cursor=pointer]:
        - /url: http://127.0.0.1:8082/mutual-funds
      - link "Portfolio" [ref=f2e10] [cursor=pointer]:
        - /url: http://127.0.0.1:8082/portfolio
      - link "Insurance" [ref=f2e11] [cursor=pointer]:
        - /url: http://127.0.0.1:8082/insurance
      - link "Policies" [ref=f2e12] [cursor=pointer]:
        - /url: http://127.0.0.1:8082/policies
      - link "Transactions" [ref=f2e13] [cursor=pointer]:
        - /url: http://127.0.0.1:8082/transactions
      - link "Support" [ref=f2e14] [cursor=pointer]:
        - /url: http://127.0.0.1:8082/support
      - link "Profile" [ref=f2e15] [cursor=pointer]:
        - /url: http://127.0.0.1:8082/profile
    - generic [ref=f2e16]:
      - generic [ref=f2e17]: Kavita Rao
      - button "Logout" [ref=f2e19] [cursor=pointer]
  - main [ref=f2e20]:
    - generic [ref=f2e22]:
      - heading "My Policies" [level=1] [ref=f2e23]
      - paragraph [ref=f2e24]: Review policy status, coverage, premium, and policy documents.
    - generic [ref=f2e26]:
      - generic [ref=f2e27]:
        - generic [ref=f2e28]: Policy Status
        - combobox "Policy Status" [ref=f2e29]:
          - option "All Statuses" [selected]
          - option "Active"
          - option "Pending Issuance"
          - option "Expired"
          - option "Renewal Due"
          - option "Cancelled"
      - generic [ref=f2e30]:
        - button "Apply" [ref=f2e31] [cursor=pointer]
        - link "Reset" [ref=f2e32] [cursor=pointer]:
          - /url: http://127.0.0.1:8082/policies
    - table [ref=f2e34]:
      - rowgroup [ref=f2e35]:
        - row [ref=f2e36]:
          - columnheader "Policy Number" [ref=f2e37]
          - columnheader "Product" [ref=f2e38]
          - columnheader "Coverage" [ref=f2e39]
          - columnheader "Premium" [ref=f2e40]
          - columnheader "Status" [ref=f2e41]
          - columnheader "End Date" [ref=f2e42]
          - columnheader [ref=f2e43]
      - rowgroup [ref=f2e44]:
        - row [ref=f2e45]:
          - cell "POL-KAV-001" [ref=f2e46]
          - cell "FinServe Life Protect Term Plan" [ref=f2e47]
          - cell "₹10,000,000" [ref=f2e48]
          - cell "₹14,500" [ref=f2e49]
          - cell "Active" [ref=f2e50]
          - cell "15 Mar 2051" [ref=f2e51]
          - cell [ref=f2e52]:
            - link "View" [ref=f2e53] [cursor=pointer]:
              - /url: http://127.0.0.1:8082/policies/1
        - row [ref=f2e54]:
          - cell "POL-KAV-002" [ref=f2e55]
          - cell "FinServe Health Secure Plan" [ref=f2e56]
          - cell "₹1,000,000" [ref=f2e57]
          - cell "₹18,500" [ref=f2e58]
          - cell "Active" [ref=f2e59]
          - cell "15 Mar 2027" [ref=f2e60]
          - cell [ref=f2e61]:
            - link "View" [ref=f2e62] [cursor=pointer]:
              - /url: http://127.0.0.1:8082/policies/2
  - contentinfo [ref=f2e63]: FinServe Retail Demo Platform · Built for Playwright QA Automation Practice
```