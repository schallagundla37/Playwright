# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: portfolio\portfolio.spec.ts >> Portfolio >> TC-PORT-004: every holding row is complete and actionable
- Location: tests\portfolio\portfolio.spec.ts:57:7

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: locator('[data-testid^="holding-row-"]').first().locator('[data-testid^="holding-fund-name-"]')
Timeout: 10000ms
Expected pattern: /^FinServe/
Received string:  "
                                FinServe Bluechip Equity Fund
                                FSBLU001
                            "

Call log:
  - Expect "toContainText" with timeout 10000ms
  - waiting for locator('[data-testid^="holding-row-"]').first().locator('[data-testid^="holding-fund-name-"]')
    23 × locator resolved to <td data-testid="holding-fund-name-1">…</td>
       - unexpected value "
                                FinServe Bluechip Equity Fund
                                FSBLU001
                            "

```

```yaml
- cell "FinServe Bluechip Equity Fund FSBLU001":
  - strong: FinServe Bluechip Equity Fund
  - text: FSBLU001
```