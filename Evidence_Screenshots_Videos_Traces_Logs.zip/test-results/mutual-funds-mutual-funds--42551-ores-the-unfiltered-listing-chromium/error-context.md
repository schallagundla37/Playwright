# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mutual-funds\mutual-funds.spec.ts >> Mutual Funds >> TC-FUND-007: reset restores the unfiltered listing
- Location: tests\mutual-funds\mutual-funds.spec.ts:92:7

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByTestId('mutual-funds-page')
Expected: visible
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 10000ms
  - waiting for getByTestId('mutual-funds-page')

```

```yaml
- main:
  - heading "500" [level=1]
  - text: Server Error
```

# Test source

```ts
  1  | import { Locator, Page, expect } from '@playwright/test';
  2  | import { BasePage } from './base.page';
  3  | 
  4  | /** Sort options offered by the listing's Sort select (option values). */
  5  | export type FundSortOption = 'fund_name' | 'one_year_return_desc' | 'nav_asc';
  6  | 
  7  | /**
  8  |  * Mutual fund listing (GET /mutual-funds).
  9  |  *
  10 |  * Real DOM hooks (captured 2026-09): wrapper `mutual-funds-page`; a GET filter
  11 |  * form with `fund-search-input`, `fund-category-filter`, `fund-risk-filter`,
  12 |  * `fund-sort-select`, `fund-filter-submit` and a `fund-filter-reset` link;
  13 |  * fund cards `fund-card-{fundCode}` each carrying the fund name (h2), category
  14 |  * badge, risk text, NAV / 1Y return (`fund-return-{fundCode}`) / Min SIP
  15 |  * metrics and a `fund-details-link-{fundCode}` → /mutual-funds/{id}.
  16 |  */
  17 | export class MutualFundsPage extends BasePage {
  18 |   readonly container: Locator;
  19 |   readonly searchInput: Locator;
  20 |   readonly categoryFilter: Locator;
  21 |   readonly riskFilter: Locator;
  22 |   readonly sortSelect: Locator;
  23 |   readonly applyButton: Locator;
  24 |   readonly resetLink: Locator;
  25 | 
  26 |   constructor(page: Page) {
  27 |     super(page);
  28 |     this.container = page.getByTestId('mutual-funds-page');
  29 |     this.searchInput = page.getByTestId('fund-search-input');
  30 |     this.categoryFilter = page.getByTestId('fund-category-filter');
  31 |     this.riskFilter = page.getByTestId('fund-risk-filter');
  32 |     this.sortSelect = page.getByTestId('fund-sort-select');
  33 |     this.applyButton = page.getByTestId('fund-filter-submit');
  34 |     this.resetLink = page.getByTestId('fund-filter-reset');
  35 |   }
  36 | 
  37 |   async goto(): Promise<void> {
  38 |     await this.page.goto('/mutual-funds');
  39 |     await this.expectLoaded();
  40 |   }
  41 | 
  42 |   async expectLoaded(): Promise<void> {
  43 |     await expect(this.page).toHaveURL(/\/mutual-funds/);
> 44 |     await expect(this.container).toBeVisible();
     |                                  ^ Error: expect(locator).toBeVisible() failed
  45 |     await expect(this.searchInput).toBeVisible();
  46 |   }
  47 | 
  48 |   /** All fund cards currently rendered by the listing. */
  49 |   get fundCards(): Locator {
  50 |     return this.page.locator('[data-testid^="fund-card-"]');
  51 |   }
  52 | 
  53 |   /** A specific fund card by fund code, e.g. FSBLU001. */
  54 |   fundCard(fundCode: string): Locator {
  55 |     return this.page.getByTestId(`fund-card-${fundCode}`);
  56 |   }
  57 | 
  58 |   /** The 1-year return figure shown on a fund card, e.g. "18.60%". */
  59 |   fundReturn(fundCode: string): Locator {
  60 |     return this.page.getByTestId(`fund-return-${fundCode}`);
  61 |   }
  62 | 
  63 |   /** Visible fund names, in render order (for sort-order assertions). */
  64 |   get fundNames(): Locator {
  65 |     return this.fundCards.getByRole('heading', { level: 2 });
  66 |   }
  67 | 
  68 |   /**
  69 |    * Apply filters via the GET form. Only the provided fields are touched;
  70 |    * the form submits and the page reloads with query parameters.
  71 |    */
  72 |   async filter(options: {
  73 |     search?: string;
  74 |     category?: string;
  75 |     riskLevel?: string;
  76 |     sort?: FundSortOption;
  77 |   }): Promise<void> {
  78 |     if (options.search !== undefined) await this.searchInput.fill(options.search);
  79 |     if (options.category !== undefined) await this.categoryFilter.selectOption(options.category);
  80 |     if (options.riskLevel !== undefined) await this.riskFilter.selectOption(options.riskLevel);
  81 |     if (options.sort !== undefined) await this.sortSelect.selectOption(options.sort);
  82 |     await this.applyButton.click();
  83 |     await this.expectLoaded();
  84 |   }
  85 | 
  86 |   async resetFilters(): Promise<void> {
  87 |     await this.resetLink.click();
  88 |     await this.expectLoaded();
  89 |   }
  90 | 
  91 |   /** Open a fund's detail page via its View Details link. */
  92 |   async openFundDetails(fundCode: string): Promise<void> {
  93 |     await this.page.getByTestId(`fund-details-link-${fundCode}`).click();
  94 |     await expect(this.page).toHaveURL(/\/mutual-funds\/\d+/);
  95 |   }
  96 | }
  97 | 
```