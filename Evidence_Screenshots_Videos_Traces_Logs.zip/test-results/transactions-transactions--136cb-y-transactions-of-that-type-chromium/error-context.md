# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: transactions\transactions.spec.ts >> Transactions >> TC-TRN-002: type filter shows only transactions of that type
- Location: tests\transactions\transactions.spec.ts:42:7

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

- Expected  - 1
+ Received  + 6

- Investment
+ All Types
+ Investment
+ Redemption
+ Premium Payment
+ Refund
+ Failed Payment
```

# Page snapshot

```yaml
- generic [ref=f3e2]:
  - banner [ref=f3e3]:
    - link "FS FinServe Retail" [ref=f3e4] [cursor=pointer]:
      - /url: http://127.0.0.1:8082/dashboard
      - generic [ref=f3e5]: FS
      - generic [ref=f3e6]: FinServe Retail
    - navigation "Main navigation" [ref=f3e7]:
      - link "Dashboard" [ref=f3e8] [cursor=pointer]:
        - /url: http://127.0.0.1:8082/dashboard
      - link "Mutual Funds" [ref=f3e9] [cursor=pointer]:
        - /url: http://127.0.0.1:8082/mutual-funds
      - link "Portfolio" [ref=f3e10] [cursor=pointer]:
        - /url: http://127.0.0.1:8082/portfolio
      - link "Insurance" [ref=f3e11] [cursor=pointer]:
        - /url: http://127.0.0.1:8082/insurance
      - link "Policies" [ref=f3e12] [cursor=pointer]:
        - /url: http://127.0.0.1:8082/policies
      - link "Transactions" [ref=f3e13] [cursor=pointer]:
        - /url: http://127.0.0.1:8082/transactions
      - link "Support" [ref=f3e14] [cursor=pointer]:
        - /url: http://127.0.0.1:8082/support
      - link "Profile" [ref=f3e15] [cursor=pointer]:
        - /url: http://127.0.0.1:8082/profile
    - generic [ref=f3e16]:
      - generic [ref=f3e17]: Arjun Mehta
      - button "Logout" [ref=f3e19] [cursor=pointer]
  - main [ref=f3e20]:
    - generic [ref=f3e22]:
      - paragraph [ref=f3e23]: Transaction History
      - heading "Transactions" [level=1] [ref=f3e24]
      - paragraph [ref=f3e25]: Search and filter your investment, redemption, premium, refund, and failed payment transactions.
    - generic [ref=f3e27]:
      - generic [ref=f3e28]:
        - generic [ref=f3e29]: Search
        - textbox "Search" [ref=f3e30]:
          - /placeholder: Reference or product name
      - generic [ref=f3e31]:
        - generic [ref=f3e32]: Type
        - combobox "Type" [ref=f3e33]:
          - option "All Types"
          - option "Investment" [selected]
          - option "Redemption"
          - option "Premium Payment"
          - option "Refund"
          - option "Failed Payment"
      - generic [ref=f3e34]:
        - generic [ref=f3e35]: Status
        - combobox "Status" [ref=f3e36]:
          - option "All Statuses" [selected]
          - option "SUCCESS"
          - option "PENDING"
          - option "FAILED"
          - option "CANCELLED"
      - generic [ref=f3e37]:
        - generic [ref=f3e38]: From
        - textbox "From" [ref=f3e39]
      - generic [ref=f3e40]:
        - generic [ref=f3e41]: To
        - textbox "To" [ref=f3e42]
      - generic [ref=f3e43]:
        - button "Apply Filters" [ref=f3e44] [cursor=pointer]
        - link "Reset" [ref=f3e45] [cursor=pointer]:
          - /url: http://127.0.0.1:8082/transactions
    - table [ref=f3e48]:
      - rowgroup [ref=f3e49]:
        - row [ref=f3e50]:
          - columnheader "Reference" [ref=f3e51]
          - columnheader "Date" [ref=f3e52]
          - columnheader "Type" [ref=f3e53]
          - columnheader "Product" [ref=f3e54]
          - columnheader "Amount" [ref=f3e55]
          - columnheader "Status" [ref=f3e56]
          - columnheader "Action" [ref=f3e57]
      - rowgroup [ref=f3e58]:
        - row [ref=f3e59]:
          - cell "TXN-20260904035605-L1DHW" [ref=f3e60]
          - cell "04 Sep 2026" [ref=f3e61]
          - cell "Investment" [ref=f3e62]
          - cell "FinServe Bluechip Equity Fund" [ref=f3e63]
          - cell "₹5,000.00" [ref=f3e64]
          - cell "SUCCESS" [ref=f3e65]
          - cell [ref=f3e66]:
            - link "View" [ref=f3e67] [cursor=pointer]:
              - /url: http://127.0.0.1:8082/transactions/139
        - row [ref=f3e68]:
          - cell "TXN-20260904035113-DXYDJ" [ref=f3e69]
          - cell "04 Sep 2026" [ref=f3e70]
          - cell "Investment" [ref=f3e71]
          - cell "FinServe Bluechip Equity Fund" [ref=f3e72]
          - cell "₹5,000.00" [ref=f3e73]
          - cell "SUCCESS" [ref=f3e74]
          - cell [ref=f3e75]:
            - link "View" [ref=f3e76] [cursor=pointer]:
              - /url: http://127.0.0.1:8082/transactions/132
        - row [ref=f3e77]:
          - cell "TXN-20260904031350-3FV5R" [ref=f3e78]
          - cell "04 Sep 2026" [ref=f3e79]
          - cell "Investment" [ref=f3e80]
          - cell "FinServe Bluechip Equity Fund" [ref=f3e81]
          - cell "₹99,999.99" [ref=f3e82]
          - cell "SUCCESS" [ref=f3e83]
          - cell [ref=f3e84]:
            - link "View" [ref=f3e85] [cursor=pointer]:
              - /url: http://127.0.0.1:8082/transactions/124
        - row [ref=f3e86]:
          - cell "TXN-20260610140658-CFMP5" [ref=f3e87]
          - cell "10 Jun 2026" [ref=f3e88]
          - cell "Investment" [ref=f3e89]
          - cell "FinServe Dividend Yield Fund" [ref=f3e90]
          - cell "₹50,000.00" [ref=f3e91]
          - cell "SUCCESS" [ref=f3e92]
          - cell [ref=f3e93]:
            - link "View" [ref=f3e94] [cursor=pointer]:
              - /url: http://127.0.0.1:8082/transactions/102
        - row [ref=f3e95]:
          - cell "TXN-20260610135750-ROV31" [ref=f3e96]
          - cell "10 Jun 2026" [ref=f3e97]
          - cell "Investment" [ref=f3e98]
          - cell "FinServe Balanced Allocation Fund" [ref=f3e99]
          - cell "₹2,000.00" [ref=f3e100]
          - cell "SUCCESS" [ref=f3e101]
          - cell [ref=f3e102]:
            - link "View" [ref=f3e103] [cursor=pointer]:
              - /url: http://127.0.0.1:8082/transactions/99
        - row [ref=f3e104]:
          - cell "TXN-20260610135547-VBM9K" [ref=f3e105]
          - cell "10 Jun 2026" [ref=f3e106]
          - cell "Investment" [ref=f3e107]
          - cell "FinServe Balanced Allocation Fund" [ref=f3e108]
          - cell "₹1,000.00" [ref=f3e109]
          - cell "SUCCESS" [ref=f3e110]
          - cell [ref=f3e111]:
            - link "View" [ref=f3e112] [cursor=pointer]:
              - /url: http://127.0.0.1:8082/transactions/98
        - row [ref=f3e113]:
          - cell "TXN-ARJ-INV-001" [ref=f3e114]
          - cell "16 May 2026" [ref=f3e115]
          - cell "Investment" [ref=f3e116]
          - cell "FinServe Bluechip Equity Fund" [ref=f3e117]
          - cell "₹25,000.00" [ref=f3e118]
          - cell "SUCCESS" [ref=f3e119]
          - cell [ref=f3e120]:
            - link "View" [ref=f3e121] [cursor=pointer]:
              - /url: http://127.0.0.1:8082/transactions/1
  - contentinfo [ref=f3e122]: FinServe Retail Demo Platform · Built for Playwright QA Automation Practice
```