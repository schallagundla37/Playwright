# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mutual-funds\investment.spec.ts >> Investment >> TC-INV-005: lumpsum at the fund minimum invests and updates the portfolio
- Location: tests\mutual-funds\investment.spec.ts:69:7

# Error details

```
Error: expect(page).not.toHaveURL(expected) failed

Expected pattern: not /\/invest\/\d+$/
Received string: "http://127.0.0.1:8082/invest/1"
Timeout: 10000ms

Call log:
  - Expect "not toHaveURL" with timeout 10000ms
    23 × locator resolved to <html lang="en">…</html>
       - unexpected value "http://127.0.0.1:8082/invest/1"

```

```yaml
- banner:
  - link "FS FinServe Retail":
    - /url: http://127.0.0.1:8082/dashboard
  - navigation "Main navigation":
    - link "Dashboard":
      - /url: http://127.0.0.1:8082/dashboard
    - link "Mutual Funds":
      - /url: http://127.0.0.1:8082/mutual-funds
    - link "Portfolio":
      - /url: http://127.0.0.1:8082/portfolio
    - link "Insurance":
      - /url: http://127.0.0.1:8082/insurance
    - link "Policies":
      - /url: http://127.0.0.1:8082/policies
    - link "Transactions":
      - /url: http://127.0.0.1:8082/transactions
    - link "Support":
      - /url: http://127.0.0.1:8082/support
    - link "Profile":
      - /url: http://127.0.0.1:8082/profile
  - text: Arjun Mehta
  - button "Logout"
- main:
  - text: Investment Order
  - heading "Invest in FinServe Bluechip Equity Fund" [level=1]
  - paragraph: Choose an investment type, enter amount, select a payment method, and confirm your simulated transaction.
  - heading "Investment order placed successfully." [level=2]
  - paragraph:
    - strong: "Order:"
    - text: INV-20260904035605-347UF
  - paragraph:
    - strong: "Transaction:"
    - text: TXN-20260904035605-L1DHW
  - paragraph:
    - strong: "Fund:"
    - text: FinServe Bluechip Equity Fund
  - paragraph:
    - strong: "Amount:"
    - text: ₹5,000.00
  - text: Selected Fund
  - heading "FinServe Bluechip Equity Fund" [level=2]
  - paragraph: FinServe Bluechip Equity Fund is a seeded demo product for Playwright automation practice.
  - text: High Risk Fund Code
  - strong: FSBLU001
  - text: Category
  - strong: Equity Fund
  - text: Current NAV
  - strong: ₹142.55
  - text: 1 Year Return
  - strong: 18.60%
  - text: Minimum SIP
  - strong: ₹500
  - text: Minimum Lumpsum
  - strong: ₹5,000
  - heading "Investment Details" [level=2]
  - paragraph: This is a simulated transaction for QA automation practice.
  - text: Investment Type
  - radio "Lumpsum Invest a one-time amount in this mutual fund." [checked]
  - strong: Lumpsum
  - text: Invest a one-time amount in this mutual fund.
  - radio "SIP Set up a recurring monthly investment."
  - strong: SIP
  - text: Set up a recurring monthly investment. Investment Amount
  - spinbutton "Investment Amount"
  - text: Payment Method
  - combobox "Payment Method":
    - option "Select Payment Method" [selected]
    - option "UPI"
    - option "Net Banking"
    - option "Debit Card"
    - option "Wallet"
  - checkbox "I understand this is a simulated investment transaction for QA training."
  - text: I understand this is a simulated investment transaction for QA training.
  - button "Confirm Investment"
  - link "Cancel":
    - /url: http://127.0.0.1:8082/mutual-funds/1
- contentinfo: FinServe Retail Demo Platform · Built for Playwright QA Automation Practice
```