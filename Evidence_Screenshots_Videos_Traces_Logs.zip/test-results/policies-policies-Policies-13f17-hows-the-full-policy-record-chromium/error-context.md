# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: policies\policies.spec.ts >> Policies >> TC-POL-003: policy detail shows the full policy record
- Location: tests\policies\policies.spec.ts:45:7

# Error details

```
Error: expect(locator).toHaveText(expected) failed

Locator: getByTestId('policy-detail-number')
Expected pattern: /^POL-\d{8}-[A-Z0-9]+$/
Received string:  "POL-KAV-001"
Timeout: 10000ms

Call log:
  - Expect "toHaveText" with timeout 10000ms
  - waiting for getByTestId('policy-detail-number')
    23 × locator resolved to <span class="muted" data-testid="policy-detail-number">POL-KAV-001</span>
       - unexpected value "POL-KAV-001"

```

```yaml
- text: POL-KAV-001
```

# Test source

```ts
  1  | import { Locator, Page, expect } from '@playwright/test';
  2  | import { BasePage } from './base.page';
  3  | 
  4  | /**
  5  |  * Policy detail (GET /policies/{id}).
  6  |  *
  7  |  * Real DOM hooks (captured 2026-09): section `policy-details-page` with a
  8  |  * status badge, `policy-detail-number`, the product name as h1, a
  9  |  * detail-metrics <dl> (Insurance Type, Insured Name, Coverage Amount,
  10 |  * Premium Amount, Nominee, Start Date, End Date, Status), a "Back to
  11 |  * Policies" link and a `download-policy-button`.
  12 |  */
  13 | export class PolicyDetailsPage extends BasePage {
  14 |   readonly container: Locator;
  15 |   readonly policyNumber: Locator;
  16 |   readonly productName: Locator;
  17 |   readonly statusBadge: Locator;
  18 |   readonly backToPoliciesLink: Locator;
  19 |   readonly downloadPolicyButton: Locator;
  20 | 
  21 |   constructor(page: Page) {
  22 |     super(page);
  23 |     this.container = page.getByTestId('policy-details-page');
  24 |     this.policyNumber = page.getByTestId('policy-detail-number');
  25 |     this.productName = this.container.getByRole('heading', { level: 1 });
  26 |     this.statusBadge = this.container.locator('.badge');
  27 |     this.backToPoliciesLink = this.container.getByRole('link', { name: 'Back to Policies' });
  28 |     this.downloadPolicyButton = page.getByTestId('download-policy-button');
  29 |   }
  30 | 
  31 |   async goto(policyId: number | string): Promise<void> {
  32 |     await this.page.goto(`/policies/${policyId}`);
  33 |     await this.expectLoaded();
  34 |   }
  35 | 
  36 |   async expectLoaded(): Promise<void> {
  37 |     await expect(this.page).toHaveURL(/\/policies\/\d+/);
  38 |     await expect(this.container).toBeVisible();
> 39 |     await expect(this.policyNumber).toHaveText(/^POL-\d{8}-[A-Z0-9]+$/);
     |                                     ^ Error: expect(locator).toHaveText(expected) failed
  40 |   }
  41 | 
  42 |   /**
  43 |    * Value cell of a detail metric by its <dt> label, e.g.
  44 |    * metric('Coverage Amount'), metric('Nominee'), metric('Status').
  45 |    */
  46 |   metric(label: string | RegExp): Locator {
  47 |     return this.container
  48 |       .locator('.detail-metrics > div')
  49 |       .filter({ has: this.page.locator('dt', { hasText: label }) })
  50 |       .locator('dd');
  51 |   }
  52 | 
  53 |   async backToPolicies(): Promise<void> {
  54 |     await this.backToPoliciesLink.click();
  55 |     await expect(this.page).toHaveURL(/\/policies/);
  56 |   }
  57 | }
  58 | 
```