# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: portfolio\portfolio.spec.ts >> Portfolio >> TC-PORT-006: holdings with zero units do not offer redemption
- Location: tests\portfolio\portfolio.spec.ts:82:7

# Error details

```
Error: expect(locator).not.toBeVisible() failed

Locator:  locator('[data-testid^="holding-row-"]').nth(1).locator('[data-testid^="redeem-button-"]')
Expected: not visible
Received: visible
Timeout:  10000ms

Call log:
  - Expect "not toBeVisible" with timeout 10000ms
  - waiting for locator('[data-testid^="holding-row-"]').nth(1).locator('[data-testid^="redeem-button-"]')
    23 × locator resolved to <a class="btn btn-secondary" data-testid="redeem-button-2" href="http://127.0.0.1:8082/redeem/2">Redeem</a>
       - unexpected value "visible"

```

```yaml
- link "Redeem":
  - /url: http://127.0.0.1:8082/redeem/2
```