# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: dashboard\dashboard.spec.ts >> Dashboard >> TC-DASH-002: recent transactions list shows references and statuses
- Location: tests\dashboard\dashboard.spec.ts:22:7

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByTestId('dashboard-page').locator('[data-testid^="transaction-row-"]').first()
Timeout: 10000ms
Expected pattern: /^TXN-/
Received string:  "
                        TXN-20260904035255-D2YKK
                        Redemption
                        ₹213.82······················································
                                SUCCESS······················································
                    "

Call log:
  - Expect "toContainText" with timeout 10000ms
  - waiting for getByTestId('dashboard-page').locator('[data-testid^="transaction-row-"]').first()
    23 × locator resolved to <tr data-testid="transaction-row-TXN-20260904035255-D2YKK">…</tr>
       - unexpected value "
                        TXN-20260904035255-D2YKK
                        Redemption
                        ₹213.82
                        
                            
                                SUCCESS
                            
                        
                    "

```

```yaml
- row "TXN-20260904035255-D2YKK Redemption ₹213.82 SUCCESS":
  - cell "TXN-20260904035255-D2YKK"
  - cell "Redemption"
  - cell "₹213.82"
  - cell "SUCCESS"
```