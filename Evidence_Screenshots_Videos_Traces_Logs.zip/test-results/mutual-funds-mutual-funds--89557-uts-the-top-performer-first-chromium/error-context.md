# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mutual-funds\mutual-funds.spec.ts >> Mutual Funds >> TC-FUND-005: sorting by 1-year return puts the top performer first
- Location: tests\mutual-funds\mutual-funds.spec.ts:72:7

# Error details

```
Error: expect(locator).toHaveText(expected) failed

Locator:  locator('[data-testid^="fund-card-"]').getByRole('heading', { level: 2 }).first()
Expected: "FinServe Midcap Opportunities Fund"
Received: "FinServe Balanced Allocation Fund"
Timeout:  10000ms

Call log:
  - Expect "toHaveText" with timeout 10000ms
  - waiting for locator('[data-testid^="fund-card-"]').getByRole('heading', { level: 2 }).first()
    23 × locator resolved to <h2>FinServe Balanced Allocation Fund</h2>
       - unexpected value "FinServe Balanced Allocation Fund"

```

```yaml
- heading "FinServe Balanced Allocation Fund" [level=2]
```