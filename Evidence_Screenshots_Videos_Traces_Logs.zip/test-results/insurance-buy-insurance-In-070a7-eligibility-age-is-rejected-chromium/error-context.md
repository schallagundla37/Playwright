# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: insurance\buy-insurance.spec.ts >> Insurance Purchase >> TC-BUY-005: date of birth outside eligibility age is rejected
- Location: tests\insurance\buy-insurance.spec.ts:92:7

# Error details

```
Error: expect(page).toHaveURL(expected) failed

Expected pattern: /\/buy-insurance\/\d+/
Received string:  "http://127.0.0.1:8082/insurance-purchases/confirmation"
Timeout: 10000ms

Call log:
  - Expect "toHaveURL" with timeout 10000ms
    23 × locator resolved to <html lang="en">…</html>
       - unexpected value "http://127.0.0.1:8082/insurance-purchases/confirmation"

```

```yaml
- banner:
  - link "FS FinServe Retail":
    - /url: http://127.0.0.1:8082/dashboard
  - navigation "Main navigation":
    - link "Dashboard":
      - /url: http://127.0.0.1:8082/dashboard
    - link "Mutual Funds":
      - /url: http://127.0.0.1:8082/mutual-funds
    - link "Portfolio":
      - /url: http://127.0.0.1:8082/portfolio
    - link "Insurance":
      - /url: http://127.0.0.1:8082/insurance
    - link "Policies":
      - /url: http://127.0.0.1:8082/policies
    - link "Transactions":
      - /url: http://127.0.0.1:8082/transactions
    - link "Support":
      - /url: http://127.0.0.1:8082/support
    - link "Profile":
      - /url: http://127.0.0.1:8082/profile
  - text: Arjun Mehta
  - button "Logout"
- main:
  - text: ✓
  - heading "Policy Created Successfully" [level=1]
  - paragraph:
    - text: Your insurance purchase has been completed for
    - strong: FinServe Life Protect Term Plan
    - text: .
  - term: Policy Number
  - definition: POL-20260904-O4H1D3
  - term: Transaction Reference
  - definition: TXN-20260904035458-FICEZ
  - term: Premium Paid
  - definition: ₹14,500
  - term: Coverage
  - definition: ₹10,000,000
  - link "View Policy":
    - /url: http://127.0.0.1:8082/policies/57
  - link "View Transactions":
    - /url: http://127.0.0.1:8082/transactions
- contentinfo: FinServe Retail Demo Platform · Built for Playwright QA Automation Practice
```