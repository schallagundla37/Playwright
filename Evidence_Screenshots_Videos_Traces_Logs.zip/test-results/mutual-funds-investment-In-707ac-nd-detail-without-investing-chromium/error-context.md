# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mutual-funds\investment.spec.ts >> Investment >> TC-INV-006: cancel returns to the fund detail without investing
- Location: tests\mutual-funds\investment.spec.ts:106:7

# Error details

```
Error: expect(page).toHaveURL(expected) failed

Expected pattern: /\/dashboard/
Received string:  "http://127.0.0.1:8082/login"
Timeout: 10000ms

Call log:
  - Expect "toHaveURL" with timeout 10000ms
    23 × locator resolved to <html lang="en">…</html>
       - unexpected value "http://127.0.0.1:8082/login"

```

```yaml
- main:
  - heading "500" [level=1]
  - text: Server Error
```

# Test source

```ts
  1  | import { Locator, Page, expect } from '@playwright/test';
  2  | import { BasePage } from './base.page';
  3  | 
  4  | /**
  5  |  * FinServe customer dashboard (GET /dashboard).
  6  |  *
  7  |  * Real DOM hooks (captured 2026-09): wrapper `data-testid="dashboard-page"`,
  8  |  * stat cards (.stat-card with .stat-label/.stat-value, portfolio value carries
  9  |  * `data-testid="portfolio-total-value"`), a Recent Transactions table with
  10 |  * `transaction-row-{reference}` rows, and recommendation cards
  11 |  * `fund-card-{fundCode}` / `insurance-product-card-{productCode}`.
  12 |  */
  13 | export class DashboardPage extends BasePage {
  14 |   readonly container: Locator;
  15 |   readonly welcomeHeading: Locator;
  16 |   readonly portfolioTotalValue: Locator;
  17 |   readonly recentTransactionsTable: Locator;
  18 | 
  19 |   constructor(page: Page) {
  20 |     super(page);
  21 |     this.container = page.getByTestId('dashboard-page');
  22 |     this.welcomeHeading = page.getByRole('heading', { name: /welcome/i });
  23 |     this.portfolioTotalValue = page.getByTestId('portfolio-total-value');
  24 |     this.recentTransactionsTable = this.container.locator('.table-card table');
  25 |   }
  26 | 
  27 |   async goto(): Promise<void> {
  28 |     await this.page.goto('/dashboard');
  29 |     await this.expectLoaded();
  30 |   }
  31 | 
  32 |   async expectLoaded(): Promise<void> {
> 33 |     await expect(this.page).toHaveURL(/\/dashboard/);
     |                             ^ Error: expect(page).toHaveURL(expected) failed
  34 |     await expect(this.container).toBeVisible();
  35 |     await expect(this.welcomeHeading).toBeVisible();
  36 |   }
  37 | 
  38 |   /**
  39 |    * Value element of a stat card, addressed by its visible label:
  40 |    * "Portfolio Value", "Invested Amount", "Gain / Loss", "Active Policies".
  41 |    */
  42 |   statValue(label: string | RegExp): Locator {
  43 |     return this.container
  44 |       .locator('.stat-card')
  45 |       .filter({ has: this.page.locator('.stat-label', { hasText: label }) })
  46 |       .locator('.stat-value');
  47 |   }
  48 | 
  49 |   /** Recent-transactions row for a specific transaction reference. */
  50 |   transactionRow(reference: string): Locator {
  51 |     return this.page.getByTestId(`transaction-row-${reference}`);
  52 |   }
  53 | 
  54 |   /** Any recent-transaction rows (for "dashboard shows activity" checks). */
  55 |   get transactionRows(): Locator {
  56 |     return this.container.locator('[data-testid^="transaction-row-"]');
  57 |   }
  58 | 
  59 |   /** Recommended insurance product card by product code, e.g. FSLIFE001. */
  60 |   recommendedInsuranceCard(productCode: string): Locator {
  61 |     return this.page.getByTestId(`insurance-product-card-${productCode}`);
  62 |   }
  63 | 
  64 |   /** Recommended mutual fund card by fund code, e.g. FSBLU001. */
  65 |   recommendedFundCard(fundCode: string): Locator {
  66 |     return this.page.getByTestId(`fund-card-${fundCode}`);
  67 |   }
  68 | }
  69 | 
```