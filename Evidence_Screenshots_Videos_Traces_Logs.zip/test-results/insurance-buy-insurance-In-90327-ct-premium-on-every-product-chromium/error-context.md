# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: insurance\buy-insurance.spec.ts >> Insurance Purchase >> TC-BUY-001: review premium matches the product premium on every product
- Location: tests\insurance\buy-insurance.spec.ts:22:7

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByTestId('insurance-purchase-page')
Expected: visible
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 10000ms
  - waiting for getByTestId('insurance-purchase-page')

```

```yaml
- main:
  - heading "500" [level=1]
  - text: Server Error
```

# Test source

```ts
  1   | import { Locator, Page, expect } from '@playwright/test';
  2   | import { BasePage } from './base.page';
  3   | 
  4   | export type NomineeRelationship = 'Spouse' | 'Parent' | 'Child' | 'Sibling' | 'Other';
  5   | 
  6   | export interface InsurancePurchaseInput {
  7   |   insuredName?: string;
  8   |   /** ISO format yyyy-mm-dd (native date input). */
  9   |   dateOfBirth?: string;
  10  |   mobile?: string;
  11  |   email?: string;
  12  |   nomineeName?: string;
  13  |   nomineeRelationship?: NomineeRelationship;
  14  |   /** Tick the accuracy declaration. Defaults to true in purchase(). */
  15  |   acceptDeclaration?: boolean;
  16  | }
  17  | 
  18  | /**
  19  |  * Insurance purchase form (GET/POST /buy-insurance/{productId}).
  20  |  *
  21  |  * Real DOM hooks (captured 2026-09): wrapper `insurance-purchase-page`.
  22  |  * Summary card shows the product with `insurance-product-premium-value` and
  23  |  * `review-premium-value` — the app's own hint says premium consistency from
  24  |  * detail → review → confirmation is a required check (likely seeded defect).
  25  |  * Form `insurance-purchase-form`: `insured-name-input`, `insured-dob-input`
  26  |  * (native date), `insured-mobile-input`, `insured-email-input` (name, mobile,
  27  |  * email arrive prefilled from the profile), `nominee-name-input`,
  28  |  * `nominee-relationship-select` (Spouse/Parent/Child/Sibling/Other),
  29  |  * `insurance-declaration-checkbox`, and `confirm-policy-button`; Cancel links
  30  |  * back to /insurance/{id}.
  31  |  */
  32  | export class BuyInsurancePage extends BasePage {
  33  |   readonly container: Locator;
  34  |   readonly productName: Locator;
  35  |   readonly productPremium: Locator;
  36  |   readonly reviewPremium: Locator;
  37  |   readonly form: Locator;
  38  |   readonly insuredNameInput: Locator;
  39  |   readonly dobInput: Locator;
  40  |   readonly mobileInput: Locator;
  41  |   readonly emailInput: Locator;
  42  |   readonly nomineeNameInput: Locator;
  43  |   readonly nomineeRelationshipSelect: Locator;
  44  |   readonly declarationCheckbox: Locator;
  45  |   readonly confirmButton: Locator;
  46  |   readonly cancelLink: Locator;
  47  | 
  48  |   constructor(page: Page) {
  49  |     super(page);
  50  |     this.container = page.getByTestId('insurance-purchase-page');
  51  |     this.productName = this.container.getByRole('heading', { level: 2 });
  52  |     this.productPremium = page.getByTestId('insurance-product-premium-value');
  53  |     this.reviewPremium = page.getByTestId('review-premium-value');
  54  |     this.form = page.getByTestId('insurance-purchase-form');
  55  |     this.insuredNameInput = page.getByTestId('insured-name-input');
  56  |     this.dobInput = page.getByTestId('insured-dob-input');
  57  |     this.mobileInput = page.getByTestId('insured-mobile-input');
  58  |     this.emailInput = page.getByTestId('insured-email-input');
  59  |     this.nomineeNameInput = page.getByTestId('nominee-name-input');
  60  |     this.nomineeRelationshipSelect = page.getByTestId('nominee-relationship-select');
  61  |     this.declarationCheckbox = page.getByTestId('insurance-declaration-checkbox');
  62  |     this.confirmButton = page.getByTestId('confirm-policy-button');
  63  |     this.cancelLink = this.form.getByRole('link', { name: 'Cancel' });
  64  |   }
  65  | 
  66  |   async goto(productId: number | string): Promise<void> {
  67  |     await this.page.goto(`/buy-insurance/${productId}`);
  68  |     await this.expectLoaded();
  69  |   }
  70  | 
  71  |   async expectLoaded(): Promise<void> {
  72  |     await expect(this.page).toHaveURL(/\/buy-insurance\/\d+/);
> 73  |     await expect(this.container).toBeVisible();
      |                                  ^ Error: expect(locator).toBeVisible() failed
  74  |     await expect(this.confirmButton).toBeVisible();
  75  |   }
  76  | 
  77  |   /**
  78  |    * The check the app itself calls out: premium shown on the review summary
  79  |    * must equal the product premium.
  80  |    */
  81  |   async expectPremiumConsistent(): Promise<void> {
  82  |     const product = (await this.productPremium.innerText()).trim();
  83  |     await expect(this.reviewPremium).toHaveText(product);
  84  |   }
  85  | 
  86  |   /** Fill only the provided fields; leaves prefilled values alone otherwise. */
  87  |   async fillForm(input: InsurancePurchaseInput): Promise<void> {
  88  |     if (input.insuredName !== undefined) await this.insuredNameInput.fill(input.insuredName);
  89  |     if (input.dateOfBirth !== undefined) await this.dobInput.fill(input.dateOfBirth);
  90  |     if (input.mobile !== undefined) await this.mobileInput.fill(input.mobile);
  91  |     if (input.email !== undefined) await this.emailInput.fill(input.email);
  92  |     if (input.nomineeName !== undefined) await this.nomineeNameInput.fill(input.nomineeName);
  93  |     if (input.nomineeRelationship !== undefined) {
  94  |       await this.nomineeRelationshipSelect.selectOption(input.nomineeRelationship);
  95  |     }
  96  |     if (input.acceptDeclaration) await this.declarationCheckbox.check();
  97  |   }
  98  | 
  99  |   async submit(): Promise<void> {
  100 |     await this.confirmButton.click();
  101 |   }
  102 | 
  103 |   /** Fill the form and submit in one step (declaration ticked by default). */
  104 |   async purchase(input: InsurancePurchaseInput): Promise<void> {
  105 |     await this.fillForm({ acceptDeclaration: true, ...input });
  106 |     await this.submit();
  107 |   }
  108 | 
  109 |   async cancel(): Promise<void> {
  110 |     await this.cancelLink.click();
  111 |     await expect(this.page).toHaveURL(/\/insurance\/\d+/);
  112 |   }
  113 | }
  114 | 
```