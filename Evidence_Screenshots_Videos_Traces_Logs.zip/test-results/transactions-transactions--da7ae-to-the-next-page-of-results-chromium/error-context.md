# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: transactions\transactions.spec.ts >> Transactions >> TC-TRN-007: pagination navigates to the next page of results
- Location: tests\transactions\transactions.spec.ts:108:7

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('[data-testid^="transaction-row-"]').first()
Expected: visible
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 10000ms
  - waiting for locator('[data-testid^="transaction-row-"]').first()

```

```yaml
- main:
  - heading "500" [level=1]
  - text: Server Error
```