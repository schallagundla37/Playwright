# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: support\support.spec.ts >> Support >> TC-SUP-001: support request submits and confirms
- Location: tests\support\support.spec.ts:15:7

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('[data-testid="flash-status"], .alert-success').first()
Expected: visible
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 10000ms
  - waiting for locator('[data-testid="flash-status"], .alert-success').first()

```

```yaml
- banner:
  - link "FS FinServe Retail":
    - /url: http://127.0.0.1:8082/dashboard
  - navigation "Main navigation":
    - link "Dashboard":
      - /url: http://127.0.0.1:8082/dashboard
    - link "Mutual Funds":
      - /url: http://127.0.0.1:8082/mutual-funds
    - link "Portfolio":
      - /url: http://127.0.0.1:8082/portfolio
    - link "Insurance":
      - /url: http://127.0.0.1:8082/insurance
    - link "Policies":
      - /url: http://127.0.0.1:8082/policies
    - link "Transactions":
      - /url: http://127.0.0.1:8082/transactions
    - link "Support":
      - /url: http://127.0.0.1:8082/support
    - link "Profile":
      - /url: http://127.0.0.1:8082/profile
  - text: Arjun Mehta
  - button "Logout"
- main:
  - text: ✓
  - heading "Support Request Submitted" [level=1]
  - paragraph: Your support request has been created successfully.
  - text: Ticket Reference
  - strong: SUP-20260904035844-LPDWR
  - text: Category
  - strong: Other
  - text: Status
  - strong: Open
  - link "Raise Another Request":
    - /url: http://127.0.0.1:8082/support
  - link "Back to Dashboard":
    - /url: http://127.0.0.1:8082/dashboard
- contentinfo: FinServe Retail Demo Platform · Built for Playwright QA Automation Practice
```