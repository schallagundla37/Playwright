# FS Platform QA Automation — Submission 2

Playwright + TypeScript automation for the Financial Services Retail Platform
(insurance application journey), built from the Submission 1 Study & QA Plan
and the Assignment 2 guidelines.

## What's in this repository

| Path | Contents |
|---|---|
| `test-design/TestCaseDesignSheet.csv` | 44 test cases with preconditions, steps, data, expected results, severity/priority, evidence, automation status — traceable to Submission 1 risks and seeded defect IDs |
| `playwright.config.ts` | Browsers, evidence capture (trace/screenshot/video/HTML report), timeouts |
| `src/config/env.ts` | Typed access to all environment values; fails fast with a clear message when a required value is missing |
| `src/pages/` | Page objects — one per screen, role/label/`data-testid` locators only |
| `src/fixtures/` | Custom test fixtures (page objects, logged-in session) and the `ApplicationJourney` helper that drives the wizard to any step |
| `src/data/` | Controlled test data builders, boundary values, invalid-input catalog, seeded-defect map |
| `src/utils/` | Age calculation oracle, traceability annotations |
| `tests/` | Specs grouped by module, tagged for selective execution |
| `test-assets/` | Sample PDF used by document-upload tests |

## Setup

```bash
# 1. Install dependencies
npm install

# 2. Install browsers (first time only)
npx playwright install

# 3. Configure the environment
copy .env.example .env      # then fill in BASE_URL and seed credentials
```

Never commit `.env` — it is gitignored. All URLs, credentials, the OTP code,
and the seeded-defect toggle live there; nothing is hard-coded in test logic.

## Running tests

```bash
npm test                 # full suite
npm run test:smoke       # login -> wizard -> submit smoke path
npm run test:regression  # all module regression tests
npm run test:defects     # only the seeded-defect detection tests
npm run test:auth        # single module (also: test:client, test:address,
                         #   test:product, test:riders, test:review)
npm run test:headed      # watch the browser
npm run test:debug       # Playwright inspector
npm run report           # open the HTML report from the last run
```

Cross-browser: set `BROWSERS=chromium,firefox,webkit` in `.env`, or pass
`--project=firefox` on the command line.

## Evidence capture

- **Trace** (`retain-on-failure`) — open with `npx playwright show-trace <zip>`
- **Screenshot** on failure, **video** retained on failure
- **HTML report** in `playwright-report/`, **JUnit XML** in `test-results/`
  for CI ingestion
- Each test is annotated with its **test case ID**, the **Submission 1 risk**
  it covers, and the **seeded defect** it can expose — visible in the HTML
  report's annotation section.

## Seeded-defect strategy

Every defect-detection test asserts the **correct** behavior and carries the
`@seeded-defect` tag plus a `test.fail(env.seededDefectBuild, <defect id>)`
guard:

- `SEEDED_DEFECT_BUILD=true` (build with seeded defects deployed): the test is
  *expected to fail* — the failure trace/screenshot is the detection evidence,
  and the run stays green so real regressions still stand out.
- `SEEDED_DEFECT_BUILD=false` (fixed build): the same test must pass, so the
  suite doubles as post-fix regression with zero code changes.

Defect IDs live in one place — `src/data/seeded-defects.ts`.

## Known assumptions and limitations

1. **Seed data & credentials sheet, Tech Handover, and the official Seeded
   Defect Catalog were not yet available** when this was built. Defect IDs in
   `seeded-defects.ts` are provisional (derived from the problem statement's
   known defect areas) and are referenced from a single file so re-mapping is
   a one-file change.
2. **Locators are role/label-first with assumed `data-testid` values** (e.g.
   `calculated-age`, `beneficiary-row`, `error-<field>`). They follow the
   naming pattern recommended in the guidelines and must be confirmed against
   the live application in the manual-exploration pass planned in Submission 1
   §8.1. Each locator is defined exactly once, in its page object.
3. **Product limits** (`sumAssuredMin`/`Max`) and the inactive product name in
   `application-data.ts` are placeholders pending the reference-data sheet.
4. **OTP** is assumed to be a static sandbox code (`RESET_OTP_CODE`). If the
   environment delivers OTP another way (mail-trap API, DB), swap the
   implementation inside `ForgotPasswordPage.submitOtp` only.
5. **API reconciliation** (UI vs. backend values) is planned for the next
   submission once the API scope/spec is confirmed, per Submission 1 §8.3.

## Troubleshooting

- `Missing required environment variable "..."` — copy `.env.example` to
  `.env` and fill the value; the error names the exact variable.
- Browsers not found — run `npx playwright install`.
- Corporate proxy blocking browser download — set `HTTPS_PROXY` before
  `npx playwright install`, or ask IT for the Playwright CDN allowlist.
- All tests failing at login — verify `BASE_URL` responds in a normal browser
  and the seed users are provisioned/unlocked.
