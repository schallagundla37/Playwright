# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: smoke\smoke.e2e.spec.ts >> Smoke — full application journey >> TC-E2E-001: customer completes and submits an insurance application
- Location: tests\smoke\smoke.e2e.spec.ts:14:7

# Error details

```
Error: page.goto: net::ERR_NAME_NOT_RESOLVED at https://qa-fs-platform.example.com/login
Call log:
  - navigating to "https://qa-fs-platform.example.com/login", waiting until "load"

```

# Test source

```ts
  1  | import { Locator, Page, expect } from '@playwright/test';
  2  | import { BasePage } from './base.page';
  3  | import { SeedUser } from '../config/env';
  4  | 
  5  | export class LoginPage extends BasePage {
  6  |   readonly emailInput: Locator;
  7  |   readonly passwordInput: Locator;
  8  |   readonly signInButton: Locator;
  9  |   readonly forgotPasswordLink: Locator;
  10 |   readonly errorMessage: Locator;
  11 | 
  12 |   constructor(page: Page) {
  13 |     super(page);
  14 |     this.emailInput = page.getByLabel(/email|username/i);
  15 |     this.passwordInput = page.getByLabel('Password', { exact: true });
  16 |     this.signInButton = page.getByRole('button', { name: /sign in|log ?in/i });
  17 |     this.forgotPasswordLink = page.getByRole('link', { name: /forgot password/i });
  18 |     this.errorMessage = page.getByTestId('login-error');
  19 |   }
  20 | 
  21 |   async goto(): Promise<void> {
> 22 |     await this.page.goto('/login');
     |                     ^ Error: page.goto: net::ERR_NAME_NOT_RESOLVED at https://qa-fs-platform.example.com/login
  23 |     await expect(this.signInButton).toBeVisible();
  24 |   }
  25 | 
  26 |   async login(user: SeedUser): Promise<void> {
  27 |     await this.emailInput.fill(user.email);
  28 |     await this.passwordInput.fill(user.password);
  29 |     await this.signInButton.click();
  30 |   }
  31 | 
  32 |   async expectLoginRejected(message: string | RegExp): Promise<void> {
  33 |     await expect(this.errorMessage).toBeVisible();
  34 |     await expect(this.errorMessage).toContainText(message);
  35 |     // The user must remain on the login page — no partial session.
  36 |     await expect(this.page).toHaveURL(/login/);
  37 |   }
  38 | }
  39 | 
```