import { TestInfo } from '@playwright/test';
import { SeededDefect } from '../data/seeded-defects';

/**
 * Stamps traceability metadata onto a test so the HTML report shows, per
 * test: the test case ID from the design sheet, the Submission 1 risk it
 * covers, and the seeded defect it can expose.
 */
export function trace(
  testInfo: TestInfo,
  meta: { testCaseId: string; risk?: string; defect?: SeededDefect },
): void {
  testInfo.annotations.push({ type: 'test-case', description: meta.testCaseId });
  if (meta.risk) {
    testInfo.annotations.push({ type: 'risk', description: meta.risk });
  }
  if (meta.defect) {
    testInfo.annotations.push({
      type: 'seeded-defect',
      description: `${meta.defect.id}: ${meta.defect.summary}`,
    });
  }
}
