import * as dotenv from 'dotenv';
import * as path from 'path';

dotenv.config({ path: path.resolve(__dirname, '../../.env') });

/**
 * Central, typed access to every environment value the suite needs.
 * Test logic must never read process.env directly — always go through `env`.
 *
 * Credentials are exposed through lazy getters so that `playwright test --list`
 * and `tsc --noEmit` work without a .env, but any test that actually needs a
 * value fails immediately with a clear message instead of a vague locator
 * timeout deep inside the run.
 */
function required(name: string): string {
  const value = process.env[name];
  if (!value) {
    throw new Error(
      `Missing required environment variable "${name}". ` +
        `Copy .env.example to .env and fill in the values from the FinServe feature guide.`,
    );
  }
  return value;
}

function optional(name: string, fallback: string): string {
  return process.env[name] ?? fallback;
}

export interface SeedUser {
  readonly email: string;
  readonly password: string;
}

function seedUser(emailVar: string, passwordVar: string): SeedUser {
  return {
    get email() {
      return required(emailVar);
    },
    get password() {
      return required(passwordVar);
    },
  };
}

export const env = {
  /** FinServe Retail Demo Platform; 127.0.0.1 when running inside the lab VM. */
  baseUrl: optional('BASE_URL', 'http://127.0.0.1:8082'),

  /** REST API of the same app (X-API-Key auth). */
  api: {
    baseUrl: optional('API_BASE_URL', 'http://127.0.0.1:8082/api'),
    get key() {
      return required('API_KEY');
    },
  },

  /** Seed users from the FinServe feature guide, section 9. */
  users: {
    /** investor1 — existing investor with portfolio holdings. */
    valid: seedUser('VALID_USER_EMAIL', 'VALID_USER_PASSWORD'),
    /** newuser — registered customer with no holdings (empty-state checks). */
    newCustomer: seedUser('NEW_USER_EMAIL', 'NEW_USER_PASSWORD'),
    /** insurance1 — user with pre-existing active policies. */
    insurance: seedUser('INSURANCE_USER_EMAIL', 'INSURANCE_USER_PASSWORD'),
    /** qauser — general regression user. */
    qa: seedUser('QA_USER_EMAIL', 'QA_USER_PASSWORD'),
    /** locked — account locked; negative authentication checks. */
    locked: seedUser('LOCKED_USER_EMAIL', 'LOCKED_USER_PASSWORD'),
  },

  /** Deliberately wrong password for negative login tests. */
  get invalidPassword() {
    return optional('INVALID_PASSWORD', 'WrongPass999');
  },

  /**
   * When true, specs tagged @seeded-defect are expected to FAIL (test.fail),
   * and the failure evidence (trace/screenshot) documents the seeded defect.
   * When false, the same specs assert correct behavior as plain regression.
   */
  seededDefectBuild: optional('SEEDED_DEFECT_BUILD', 'false').toLowerCase() === 'true',

  headless: optional('HEADLESS', 'true').toLowerCase() === 'true',
  browsers: optional('BROWSERS', 'chromium')
    .split(',')
    .map((b) => b.trim())
    .filter(Boolean),
  defaultTimeoutMs: Number(optional('DEFAULT_TIMEOUT_MS', '30000')),
} as const;
