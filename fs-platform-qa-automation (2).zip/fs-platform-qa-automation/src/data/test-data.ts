/**
 * Seeded catalog facts observed on the live FinServe app (captured 2026-09).
 * Structural facts (codes, ids, categories, counts) are stable across a
 * cohort; monetary figures (NAV, returns) come from the same seed and are
 * asserted only where the assignment calls for it.
 */

export interface SeededFund {
  id: number;
  code: string;
  name: string;
  category: 'Equity Fund' | 'Debt Fund' | 'Hybrid Fund' | 'Index Fund' | 'ELSS';
  risk: 'Low' | 'Moderate' | 'High' | 'Very High';
  minSip: number;
}

export const funds: readonly SeededFund[] = [
  { id: 7, code: 'FSBAL007', name: 'FinServe Balanced Allocation Fund', category: 'Hybrid Fund', risk: 'Moderate', minSip: 500 },
  { id: 1, code: 'FSBLU001', name: 'FinServe Bluechip Equity Fund', category: 'Equity Fund', risk: 'High', minSip: 500 },
  { id: 12, code: 'FSDIV012', name: 'FinServe Dividend Yield Fund', category: 'Equity Fund', risk: 'Moderate', minSip: 500 },
  { id: 11, code: 'FSFAST011', name: 'FinServe FastStart SIP Fund', category: 'Equity Fund', risk: 'High', minSip: 1500 },
  { id: 10, code: 'FSGILT010', name: 'FinServe Gilt 10 Year Fund', category: 'Debt Fund', risk: 'Moderate', minSip: 500 },
  { id: 6, code: 'FSHYB006', name: 'FinServe Hybrid Advantage Fund', category: 'Hybrid Fund', risk: 'Moderate', minSip: 500 },
  { id: 2, code: 'FSLGC002', name: 'FinServe Large Cap Growth Fund', category: 'Equity Fund', risk: 'High', minSip: 500 },
  { id: 9, code: 'FSLIQ009', name: 'FinServe Liquid Fund', category: 'Debt Fund', risk: 'Low', minSip: 500 },
  { id: 3, code: 'FSMID003', name: 'FinServe Midcap Opportunities Fund', category: 'Equity Fund', risk: 'Very High', minSip: 1000 },
  { id: 4, code: 'FSIDX004', name: 'FinServe Nifty Index Fund', category: 'Index Fund', risk: 'Moderate', minSip: 500 },
  { id: 8, code: 'FSSTD008', name: 'FinServe Short Term Debt Fund', category: 'Debt Fund', risk: 'Low', minSip: 500 },
  { id: 5, code: 'FSELSS005', name: 'FinServe Tax Saver ELSS Fund', category: 'ELSS', risk: 'High', minSip: 500 },
] as const;

/** Fund with the highest seeded 1Y return (22.30%) — sort assertions. */
export const topReturnFundCode = 'FSMID003';
/** Fund with the lowest seeded NAV (₹22.12) — sort assertions. */
export const lowestNavFundCode = 'FSLIQ009';

export interface SeededInsuranceProduct {
  id: number;
  code: string;
  name: string;
  type: 'Term Insurance' | 'Health Insurance' | 'Motor Insurance' | 'Travel Insurance';
  /** As rendered on the listing, e.g. "₹10,000,000". */
  coverageText: string;
  premiumText: string;
  termYears: number;
}

export const insuranceProducts: readonly SeededInsuranceProduct[] = [
  { id: 1, code: 'FSLIFE001', name: 'FinServe Life Protect Term Plan', type: 'Term Insurance', coverageText: '₹10,000,000', premiumText: '₹14,500', termYears: 25 },
  { id: 2, code: 'FSLIFE002', name: 'FinServe Secure Future Term Plan', type: 'Term Insurance', coverageText: '₹5,000,000', premiumText: '₹9,200', termYears: 20 },
  { id: 3, code: 'FSHLTH003', name: 'FinServe Health Secure Plan', type: 'Health Insurance', coverageText: '₹1,000,000', premiumText: '₹18,500', termYears: 1 },
  { id: 4, code: 'FSHLTH004', name: 'FinServe Family Health Plus', type: 'Health Insurance', coverageText: '₹2,000,000', premiumText: '₹29,500', termYears: 1 },
  { id: 5, code: 'FSMOTO005', name: 'FinServe Motor Shield', type: 'Motor Insurance', coverageText: '₹700,000', premiumText: '₹12,500', termYears: 1 },
  { id: 6, code: 'FSMOTO006', name: 'FinServe Two Wheeler Protect', type: 'Motor Insurance', coverageText: '₹125,000', premiumText: '₹2,100', termYears: 1 },
  { id: 7, code: 'FSTRVL007', name: 'FinServe Travel Guard', type: 'Travel Insurance', coverageText: '₹500,000', premiumText: '₹1,800', termYears: 1 },
  { id: 8, code: 'FSACCD008', name: 'FinServe Accident Cover Plus', type: 'Health Insurance', coverageText: '₹2,500,000', premiumText: '₹7,800', termYears: 1 },
] as const;

/** Primary happy-path purchase target (confirmed working on the live app). */
export const happyPathProduct = insuranceProducts[0]; // FSLIFE001

/** Expected listing membership per premium-range filter bucket. */
export const premiumRangeBuckets = {
  under_5000: ['FSMOTO006', 'FSTRVL007'],
  '5000_15000': ['FSLIFE001', 'FSLIFE002', 'FSMOTO005', 'FSACCD008'],
  above_15000: ['FSHLTH003', 'FSHLTH004'],
} as const;

/** Baseline valid input for the insurance purchase form. */
export function validPurchaseInput() {
  return {
    dateOfBirth: '1990-05-15',
    nomineeName: 'Priya Mehta',
    nomineeRelationship: 'Spouse' as const,
  };
}
