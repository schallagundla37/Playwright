/**
 * Seeded Defect Catalog mapping.
 *
 * No official answer key is distributed to learners, so the IDs below are
 * provisional, derived from behavior observed on the live app and from hints
 * the app itself renders. Every spec references defects through this single
 * map, so renaming an ID here is the only change needed if a catalog arrives.
 */
export const seededDefects = {
  SD_AUTH_01: {
    id: 'SD-AUTH-01',
    summary: 'Locked user is able to log in and reach the dashboard',
  },
  SD_PREMIUM_01: {
    id: 'SD-PREMIUM-01',
    summary:
      'Review premium on /buy-insurance differs from the product premium ' +
      '(the page itself hints: "validate whether the premium remains consistent")',
  },
  SD_REDEEM_01: {
    id: 'SD-REDEEM-01',
    summary: 'Holdings with 0.0000 units still expose an active Redeem action',
  },
  SD_ELIG_01: {
    id: 'SD-ELIG-01',
    summary: 'Insurance purchase accepts a date of birth outside product eligibility age',
  },
} as const;

export type SeededDefect = (typeof seededDefects)[keyof typeof seededDefects];
