import { test as base } from '@playwright/test';
import { env, SeedUser } from '../config/env';
import { LoginPage } from '../pages/login.page';
import { DashboardPage } from '../pages/dashboard.page';
import { MutualFundsPage } from '../pages/mutual-funds.page';
import { InsurancePage } from '../pages/insurance.page';
import { BuyInsurancePage } from '../pages/buy-insurance.page';
import { PurchaseConfirmationPage } from '../pages/purchase-confirmation.page';
import { PoliciesPage } from '../pages/policies.page';
import { PolicyDetailsPage } from '../pages/policy-details.page';
import { PortfolioPage } from '../pages/portfolio.page';

interface Fixtures {
  loginPage: LoginPage;
  dashboardPage: DashboardPage;
  mutualFundsPage: MutualFundsPage;
  insurancePage: InsurancePage;
  buyInsurancePage: BuyInsurancePage;
  purchaseConfirmationPage: PurchaseConfirmationPage;
  policiesPage: PoliciesPage;
  policyDetailsPage: PolicyDetailsPage;
  portfolioPage: PortfolioPage;

  /** Logs in as the given seed user and lands on the dashboard. */
  loginAs: (user: SeedUser) => Promise<DashboardPage>;

  /** Logs in as the primary valid seed customer (investor1). */
  loggedInDashboard: DashboardPage;
}

export const test = base.extend<Fixtures>({
  loginPage: async ({ page }, use) => use(new LoginPage(page)),
  dashboardPage: async ({ page }, use) => use(new DashboardPage(page)),
  mutualFundsPage: async ({ page }, use) => use(new MutualFundsPage(page)),
  insurancePage: async ({ page }, use) => use(new InsurancePage(page)),
  buyInsurancePage: async ({ page }, use) => use(new BuyInsurancePage(page)),
  purchaseConfirmationPage: async ({ page }, use) => use(new PurchaseConfirmationPage(page)),
  policiesPage: async ({ page }, use) => use(new PoliciesPage(page)),
  policyDetailsPage: async ({ page }, use) => use(new PolicyDetailsPage(page)),
  portfolioPage: async ({ page }, use) => use(new PortfolioPage(page)),

  loginAs: async ({ loginPage, dashboardPage }, use) => {
    await use(async (user: SeedUser) => {
      await loginPage.goto();
      await loginPage.login(user);
      await dashboardPage.expectLoaded();
      return dashboardPage;
    });
  },

  loggedInDashboard: async ({ loginAs }, use) => {
    await use(await loginAs(env.users.valid));
  },
});

export { expect } from '@playwright/test';
