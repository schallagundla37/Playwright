import { Locator, Page, expect } from '@playwright/test';
import { BasePage } from './base.page';

export type NomineeRelationship = 'Spouse' | 'Parent' | 'Child' | 'Sibling' | 'Other';

export interface InsurancePurchaseInput {
  insuredName?: string;
  /** ISO format yyyy-mm-dd (native date input). */
  dateOfBirth?: string;
  mobile?: string;
  email?: string;
  nomineeName?: string;
  nomineeRelationship?: NomineeRelationship;
  /** Tick the accuracy declaration. Defaults to true in purchase(). */
  acceptDeclaration?: boolean;
}

/**
 * Insurance purchase form (GET/POST /buy-insurance/{productId}).
 *
 * Real DOM hooks (captured 2026-09): wrapper `insurance-purchase-page`.
 * Summary card shows the product with `insurance-product-premium-value` and
 * `review-premium-value` — the app's own hint says premium consistency from
 * detail → review → confirmation is a required check (likely seeded defect).
 * Form `insurance-purchase-form`: `insured-name-input`, `insured-dob-input`
 * (native date), `insured-mobile-input`, `insured-email-input` (name, mobile,
 * email arrive prefilled from the profile), `nominee-name-input`,
 * `nominee-relationship-select` (Spouse/Parent/Child/Sibling/Other),
 * `insurance-declaration-checkbox`, and `confirm-policy-button`; Cancel links
 * back to /insurance/{id}.
 */
export class BuyInsurancePage extends BasePage {
  readonly container: Locator;
  readonly productName: Locator;
  readonly productPremium: Locator;
  readonly reviewPremium: Locator;
  readonly form: Locator;
  readonly insuredNameInput: Locator;
  readonly dobInput: Locator;
  readonly mobileInput: Locator;
  readonly emailInput: Locator;
  readonly nomineeNameInput: Locator;
  readonly nomineeRelationshipSelect: Locator;
  readonly declarationCheckbox: Locator;
  readonly confirmButton: Locator;
  readonly cancelLink: Locator;

  constructor(page: Page) {
    super(page);
    this.container = page.getByTestId('insurance-purchase-page');
    this.productName = this.container.getByRole('heading', { level: 2 });
    this.productPremium = page.getByTestId('insurance-product-premium-value');
    this.reviewPremium = page.getByTestId('review-premium-value');
    this.form = page.getByTestId('insurance-purchase-form');
    this.insuredNameInput = page.getByTestId('insured-name-input');
    this.dobInput = page.getByTestId('insured-dob-input');
    this.mobileInput = page.getByTestId('insured-mobile-input');
    this.emailInput = page.getByTestId('insured-email-input');
    this.nomineeNameInput = page.getByTestId('nominee-name-input');
    this.nomineeRelationshipSelect = page.getByTestId('nominee-relationship-select');
    this.declarationCheckbox = page.getByTestId('insurance-declaration-checkbox');
    this.confirmButton = page.getByTestId('confirm-policy-button');
    this.cancelLink = this.form.getByRole('link', { name: 'Cancel' });
  }

  async goto(productId: number | string): Promise<void> {
    await this.page.goto(`/buy-insurance/${productId}`);
    await this.expectLoaded();
  }

  async expectLoaded(): Promise<void> {
    await expect(this.page).toHaveURL(/\/buy-insurance\/\d+/);
    await expect(this.container).toBeVisible();
    await expect(this.confirmButton).toBeVisible();
  }

  /**
   * The check the app itself calls out: premium shown on the review summary
   * must equal the product premium.
   */
  async expectPremiumConsistent(): Promise<void> {
    const product = (await this.productPremium.innerText()).trim();
    await expect(this.reviewPremium).toHaveText(product);
  }

  /** Fill only the provided fields; leaves prefilled values alone otherwise. */
  async fillForm(input: InsurancePurchaseInput): Promise<void> {
    if (input.insuredName !== undefined) await this.insuredNameInput.fill(input.insuredName);
    if (input.dateOfBirth !== undefined) await this.dobInput.fill(input.dateOfBirth);
    if (input.mobile !== undefined) await this.mobileInput.fill(input.mobile);
    if (input.email !== undefined) await this.emailInput.fill(input.email);
    if (input.nomineeName !== undefined) await this.nomineeNameInput.fill(input.nomineeName);
    if (input.nomineeRelationship !== undefined) {
      await this.nomineeRelationshipSelect.selectOption(input.nomineeRelationship);
    }
    if (input.acceptDeclaration) await this.declarationCheckbox.check();
  }

  async submit(): Promise<void> {
    await this.confirmButton.click();
  }

  /** Fill the form and submit in one step (declaration ticked by default). */
  async purchase(input: InsurancePurchaseInput): Promise<void> {
    await this.fillForm({ acceptDeclaration: true, ...input });
    await this.submit();
  }

  async cancel(): Promise<void> {
    await this.cancelLink.click();
    await expect(this.page).toHaveURL(/\/insurance\/\d+/);
  }
}
