import { Locator, Page, expect } from '@playwright/test';

/**
 * Shared behavior for all FinServe pages.
 *
 * Every authenticated page renders the same shell: a topbar with the brand
 * link, a "Main navigation" nav (Dashboard, Mutual Funds, Portfolio,
 * Insurance, Policies, Transactions, Support, Profile) and a logout form
 * (`data-testid="logout-button"`).
 *
 * Locator strategy: user-facing role/label locators first, `data-testid`
 * (configured as the testIdAttribute in playwright.config.ts) where the DOM
 * offers no stable accessible handle. No CSS/XPath chains, no waits on time.
 */
export abstract class BasePage {
  protected constructor(protected readonly page: Page) {}

  /** Topbar main navigation, present on every page of the app shell. */
  get mainNav(): Locator {
    return this.page.getByRole('navigation', { name: 'Main navigation' });
  }

  /** Logout button in the topbar user menu (submits the logout form). */
  get logoutButton(): Locator {
    return this.page.getByTestId('logout-button');
  }

  /** Click a topbar navigation link by its visible name, e.g. "Insurance". */
  async navigateTo(linkName: string | RegExp): Promise<void> {
    await this.mainNav.getByRole('link', { name: linkName }).click();
  }

  async logout(): Promise<void> {
    await this.logoutButton.click();
    await expect(this.page).toHaveURL(/login/);
  }

  /** Flash/alert banner used by the app for success and error feedback. */
  get toast(): Locator {
    return this.page.getByRole('alert');
  }

  async expectToast(message: string | RegExp): Promise<void> {
    await expect(this.toast).toContainText(message);
  }
}
