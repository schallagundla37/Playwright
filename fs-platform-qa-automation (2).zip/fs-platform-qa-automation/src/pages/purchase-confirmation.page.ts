import { Locator, Page, expect } from '@playwright/test';
import { BasePage } from './base.page';

/**
 * Insurance purchase confirmation, shown after POST /buy-insurance/{id}.
 *
 * Real DOM hooks (captured 2026-09): section `policy-confirmation-message`
 * with the "Policy Created Successfully" heading, the purchased product name
 * in <strong>, `confirmation-policy-number` (POL-YYYYMMDD-XXXXXX),
 * `confirmation-transaction-reference` (TXN-...),
 * `confirmation-premium-amount`, and links `view-created-policy-link`
 * → /policies/{id} and `view-transactions-link` → /transactions.
 */
export class PurchaseConfirmationPage extends BasePage {
  readonly container: Locator;
  readonly heading: Locator;
  readonly policyNumber: Locator;
  readonly transactionReference: Locator;
  readonly premiumAmount: Locator;
  readonly viewPolicyLink: Locator;
  readonly viewTransactionsLink: Locator;

  constructor(page: Page) {
    super(page);
    this.container = page.getByTestId('policy-confirmation-message');
    this.heading = page.getByRole('heading', { name: /policy created successfully/i });
    this.policyNumber = page.getByTestId('confirmation-policy-number');
    this.transactionReference = page.getByTestId('confirmation-transaction-reference');
    this.premiumAmount = page.getByTestId('confirmation-premium-amount');
    this.viewPolicyLink = page.getByTestId('view-created-policy-link');
    this.viewTransactionsLink = page.getByTestId('view-transactions-link');
  }

  async expectLoaded(productName?: string | RegExp): Promise<void> {
    await expect(this.container).toBeVisible();
    await expect(this.heading).toBeVisible();
    if (productName !== undefined) {
      await expect(this.container).toContainText(productName);
    }
    // Identifiers follow seeded formats: POL-YYYYMMDD-XXXXXX / TXN-...
    await expect(this.policyNumber).toHaveText(/^POL-\d{8}-[A-Z0-9]+$/);
    await expect(this.transactionReference).toHaveText(/^TXN-\d+-[A-Z0-9]+$/);
  }

  /** Policy number text, for cross-checking on /policies and /transactions. */
  async capturePolicyNumber(): Promise<string> {
    return (await this.policyNumber.innerText()).trim();
  }

  /** Transaction reference text, for cross-checking on /transactions. */
  async captureTransactionReference(): Promise<string> {
    return (await this.transactionReference.innerText()).trim();
  }

  /** Open the created policy's detail page (/policies/{id}). */
  async viewCreatedPolicy(): Promise<void> {
    await this.viewPolicyLink.click();
    await expect(this.page).toHaveURL(/\/policies\/\d+/);
  }

  async viewTransactions(): Promise<void> {
    await this.viewTransactionsLink.click();
    await expect(this.page).toHaveURL(/\/transactions/);
  }
}
