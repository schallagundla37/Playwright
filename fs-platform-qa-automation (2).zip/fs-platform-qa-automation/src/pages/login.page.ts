import { Locator, Page, expect } from '@playwright/test';
import { BasePage } from './base.page';
import { SeedUser } from '../config/env';

/**
 * Login page (GET/POST /login).
 *
 * Real DOM hooks (captured 2026-09): standalone auth card (no app shell) with
 * wrapper `login-page`, form `login-form`, inputs `login-email` /
 * `login-password` (both required), submit button `login-submit` ("Login"),
 * and a flash alert `flash-status` (e.g. "You have been logged out.").
 * There is NO forgot-password link on this app.
 */
export class LoginPage extends BasePage {
  readonly container: Locator;
  readonly emailInput: Locator;
  readonly passwordInput: Locator;
  readonly loginButton: Locator;
  /** Flash banner, e.g. the logout confirmation. */
  readonly flashStatus: Locator;
  /**
   * Error feedback after a rejected login. The exact failure markup has not
   * been captured yet, so this covers the plausible variants; tighten it to a
   * single locator once a failed-login outerHTML is available.
   */
  readonly errorAlert: Locator;

  constructor(page: Page) {
    super(page);
    this.container = page.getByTestId('login-page');
    this.emailInput = page.getByTestId('login-email');
    this.passwordInput = page.getByTestId('login-password');
    this.loginButton = page.getByTestId('login-submit');
    this.flashStatus = page.getByTestId('flash-status');
    this.errorAlert = page
      .locator('[data-testid="login-error"], [data-testid="flash-status"], .alert-danger, .alert-error')
      .first();
  }

  async goto(): Promise<void> {
    await this.page.goto('/login');
    await this.expectLoaded();
  }

  async expectLoaded(): Promise<void> {
    await expect(this.container).toBeVisible();
    await expect(this.loginButton).toBeVisible();
  }

  async login(user: SeedUser | { email: string; password: string }): Promise<void> {
    await this.emailInput.fill(user.email);
    await this.passwordInput.fill(user.password);
    await this.loginButton.click();
  }

  /** Convenience: navigate, authenticate, and wait to leave /login. */
  async loginAs(user: SeedUser | { email: string; password: string }): Promise<void> {
    await this.goto();
    await this.login(user);
    await expect(this.page).not.toHaveURL(/\/login/);
  }

  async expectLoginRejected(message?: string | RegExp): Promise<void> {
    // The user must remain on the login page — no partial session.
    await expect(this.page).toHaveURL(/login/);
    await expect(this.errorAlert).toBeVisible();
    if (message !== undefined) {
      await expect(this.errorAlert).toContainText(message);
    }
  }
}
