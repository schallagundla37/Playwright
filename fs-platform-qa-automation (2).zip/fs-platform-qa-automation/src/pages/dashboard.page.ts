import { Locator, Page, expect } from '@playwright/test';
import { BasePage } from './base.page';

/**
 * FinServe customer dashboard (GET /dashboard).
 *
 * Real DOM hooks (captured 2026-09): wrapper `data-testid="dashboard-page"`,
 * stat cards (.stat-card with .stat-label/.stat-value, portfolio value carries
 * `data-testid="portfolio-total-value"`), a Recent Transactions table with
 * `transaction-row-{reference}` rows, and recommendation cards
 * `fund-card-{fundCode}` / `insurance-product-card-{productCode}`.
 */
export class DashboardPage extends BasePage {
  readonly container: Locator;
  readonly welcomeHeading: Locator;
  readonly portfolioTotalValue: Locator;
  readonly recentTransactionsTable: Locator;

  constructor(page: Page) {
    super(page);
    this.container = page.getByTestId('dashboard-page');
    this.welcomeHeading = page.getByRole('heading', { name: /welcome/i });
    this.portfolioTotalValue = page.getByTestId('portfolio-total-value');
    this.recentTransactionsTable = this.container.locator('.table-card table');
  }

  async goto(): Promise<void> {
    await this.page.goto('/dashboard');
    await this.expectLoaded();
  }

  async expectLoaded(): Promise<void> {
    await expect(this.page).toHaveURL(/\/dashboard/);
    await expect(this.container).toBeVisible();
    await expect(this.welcomeHeading).toBeVisible();
  }

  /**
   * Value element of a stat card, addressed by its visible label:
   * "Portfolio Value", "Invested Amount", "Gain / Loss", "Active Policies".
   */
  statValue(label: string | RegExp): Locator {
    return this.container
      .locator('.stat-card')
      .filter({ has: this.page.locator('.stat-label', { hasText: label }) })
      .locator('.stat-value');
  }

  /** Recent-transactions row for a specific transaction reference. */
  transactionRow(reference: string): Locator {
    return this.page.getByTestId(`transaction-row-${reference}`);
  }

  /** Any recent-transaction rows (for "dashboard shows activity" checks). */
  get transactionRows(): Locator {
    return this.container.locator('[data-testid^="transaction-row-"]');
  }

  /** Recommended insurance product card by product code, e.g. FSLIFE001. */
  recommendedInsuranceCard(productCode: string): Locator {
    return this.page.getByTestId(`insurance-product-card-${productCode}`);
  }

  /** Recommended mutual fund card by fund code, e.g. FSBLU001. */
  recommendedFundCard(fundCode: string): Locator {
    return this.page.getByTestId(`fund-card-${fundCode}`);
  }
}
