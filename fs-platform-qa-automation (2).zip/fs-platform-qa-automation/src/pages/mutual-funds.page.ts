import { Locator, Page, expect } from '@playwright/test';
import { BasePage } from './base.page';

/** Sort options offered by the listing's Sort select (option values). */
export type FundSortOption = 'fund_name' | 'one_year_return_desc' | 'nav_asc';

/**
 * Mutual fund listing (GET /mutual-funds).
 *
 * Real DOM hooks (captured 2026-09): wrapper `mutual-funds-page`; a GET filter
 * form with `fund-search-input`, `fund-category-filter`, `fund-risk-filter`,
 * `fund-sort-select`, `fund-filter-submit` and a `fund-filter-reset` link;
 * fund cards `fund-card-{fundCode}` each carrying the fund name (h2), category
 * badge, risk text, NAV / 1Y return (`fund-return-{fundCode}`) / Min SIP
 * metrics and a `fund-details-link-{fundCode}` → /mutual-funds/{id}.
 */
export class MutualFundsPage extends BasePage {
  readonly container: Locator;
  readonly searchInput: Locator;
  readonly categoryFilter: Locator;
  readonly riskFilter: Locator;
  readonly sortSelect: Locator;
  readonly applyButton: Locator;
  readonly resetLink: Locator;

  constructor(page: Page) {
    super(page);
    this.container = page.getByTestId('mutual-funds-page');
    this.searchInput = page.getByTestId('fund-search-input');
    this.categoryFilter = page.getByTestId('fund-category-filter');
    this.riskFilter = page.getByTestId('fund-risk-filter');
    this.sortSelect = page.getByTestId('fund-sort-select');
    this.applyButton = page.getByTestId('fund-filter-submit');
    this.resetLink = page.getByTestId('fund-filter-reset');
  }

  async goto(): Promise<void> {
    await this.page.goto('/mutual-funds');
    await this.expectLoaded();
  }

  async expectLoaded(): Promise<void> {
    await expect(this.page).toHaveURL(/\/mutual-funds/);
    await expect(this.container).toBeVisible();
    await expect(this.searchInput).toBeVisible();
  }

  /** All fund cards currently rendered by the listing. */
  get fundCards(): Locator {
    return this.page.locator('[data-testid^="fund-card-"]');
  }

  /** A specific fund card by fund code, e.g. FSBLU001. */
  fundCard(fundCode: string): Locator {
    return this.page.getByTestId(`fund-card-${fundCode}`);
  }

  /** The 1-year return figure shown on a fund card, e.g. "18.60%". */
  fundReturn(fundCode: string): Locator {
    return this.page.getByTestId(`fund-return-${fundCode}`);
  }

  /** Visible fund names, in render order (for sort-order assertions). */
  get fundNames(): Locator {
    return this.fundCards.getByRole('heading', { level: 2 });
  }

  /**
   * Apply filters via the GET form. Only the provided fields are touched;
   * the form submits and the page reloads with query parameters.
   */
  async filter(options: {
    search?: string;
    category?: string;
    riskLevel?: string;
    sort?: FundSortOption;
  }): Promise<void> {
    if (options.search !== undefined) await this.searchInput.fill(options.search);
    if (options.category !== undefined) await this.categoryFilter.selectOption(options.category);
    if (options.riskLevel !== undefined) await this.riskFilter.selectOption(options.riskLevel);
    if (options.sort !== undefined) await this.sortSelect.selectOption(options.sort);
    await this.applyButton.click();
    await this.expectLoaded();
  }

  async resetFilters(): Promise<void> {
    await this.resetLink.click();
    await this.expectLoaded();
  }

  /** Open a fund's detail page via its View Details link. */
  async openFundDetails(fundCode: string): Promise<void> {
    await this.page.getByTestId(`fund-details-link-${fundCode}`).click();
    await expect(this.page).toHaveURL(/\/mutual-funds\/\d+/);
  }
}
