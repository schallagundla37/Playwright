import { Locator, Page, expect } from '@playwright/test';
import { BasePage } from './base.page';

/** Status values offered by the policy status filter (option values). */
export type PolicyStatus =
  | 'Active'
  | 'Pending Issuance'
  | 'Expired'
  | 'Renewal Due'
  | 'Cancelled';

/**
 * Customer policy list (GET /policies).
 *
 * Real DOM hooks (captured 2026-09): wrapper `policies-page`; GET filter form
 * `policy-filter-form` with `policy-status-filter`; a table whose rows carry
 * `policy-row-{id}`, `policy-number-{id}`, `policy-status-{id}` and a
 * `policy-details-link-{id}` → /policies/{id}. Columns: Policy Number,
 * Product, Coverage, Premium, Status, End Date.
 */
export class PoliciesPage extends BasePage {
  readonly container: Locator;
  readonly filterForm: Locator;
  readonly statusFilter: Locator;
  readonly table: Locator;

  constructor(page: Page) {
    super(page);
    this.container = page.getByTestId('policies-page');
    this.filterForm = page.getByTestId('policy-filter-form');
    this.statusFilter = page.getByTestId('policy-status-filter');
    this.table = page.locator('.table-card table');
  }

  async goto(): Promise<void> {
    await this.page.goto('/policies');
    await this.expectLoaded();
  }

  async expectLoaded(): Promise<void> {
    await expect(this.page).toHaveURL(/\/policies/);
    await expect(this.container).toBeVisible();
  }

  /** All policy rows currently listed. */
  get policyRows(): Locator {
    return this.page.locator('[data-testid^="policy-row-"]');
  }

  /** A policy row by its numeric id (from the /policies/{id} URL). */
  policyRow(policyId: number | string): Locator {
    return this.page.getByTestId(`policy-row-${policyId}`);
  }

  /** A policy row by its policy number, e.g. "POL-20260904-IZ2PS5". */
  policyRowByNumber(policyNumber: string): Locator {
    return this.policyRows.filter({ hasText: policyNumber });
  }

  /** Status pill within a row located by policy number. */
  statusOf(policyNumber: string): Locator {
    return this.policyRowByNumber(policyNumber).locator('[data-testid^="policy-status-"]');
  }

  async filterByStatus(status: PolicyStatus | ''): Promise<void> {
    await this.statusFilter.selectOption(status);
    await this.filterForm.getByRole('button', { name: 'Apply' }).click();
    await this.expectLoaded();
  }

  async resetFilters(): Promise<void> {
    await this.filterForm.getByRole('link', { name: 'Reset' }).click();
    await this.expectLoaded();
  }

  /** Open a policy's detail page from its row (located by policy number). */
  async openPolicyDetails(policyNumber: string): Promise<void> {
    await this.policyRowByNumber(policyNumber)
      .getByRole('link', { name: 'View' })
      .click();
    await expect(this.page).toHaveURL(/\/policies\/\d+/);
  }
}
