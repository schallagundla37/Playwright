import { Locator, Page, expect } from '@playwright/test';
import { BasePage } from './base.page';

/**
 * Policy detail (GET /policies/{id}).
 *
 * Real DOM hooks (captured 2026-09): section `policy-details-page` with a
 * status badge, `policy-detail-number`, the product name as h1, a
 * detail-metrics <dl> (Insurance Type, Insured Name, Coverage Amount,
 * Premium Amount, Nominee, Start Date, End Date, Status), a "Back to
 * Policies" link and a `download-policy-button`.
 */
export class PolicyDetailsPage extends BasePage {
  readonly container: Locator;
  readonly policyNumber: Locator;
  readonly productName: Locator;
  readonly statusBadge: Locator;
  readonly backToPoliciesLink: Locator;
  readonly downloadPolicyButton: Locator;

  constructor(page: Page) {
    super(page);
    this.container = page.getByTestId('policy-details-page');
    this.policyNumber = page.getByTestId('policy-detail-number');
    this.productName = this.container.getByRole('heading', { level: 1 });
    this.statusBadge = this.container.locator('.badge');
    this.backToPoliciesLink = this.container.getByRole('link', { name: 'Back to Policies' });
    this.downloadPolicyButton = page.getByTestId('download-policy-button');
  }

  async goto(policyId: number | string): Promise<void> {
    await this.page.goto(`/policies/${policyId}`);
    await this.expectLoaded();
  }

  async expectLoaded(): Promise<void> {
    await expect(this.page).toHaveURL(/\/policies\/\d+/);
    await expect(this.container).toBeVisible();
    await expect(this.policyNumber).toHaveText(/^POL-\d{8}-[A-Z0-9]+$/);
  }

  /**
   * Value cell of a detail metric by its <dt> label, e.g.
   * metric('Coverage Amount'), metric('Nominee'), metric('Status').
   */
  metric(label: string | RegExp): Locator {
    return this.container
      .locator('.detail-metrics > div')
      .filter({ has: this.page.locator('dt', { hasText: label }) })
      .locator('dd');
  }

  async backToPolicies(): Promise<void> {
    await this.backToPoliciesLink.click();
    await expect(this.page).toHaveURL(/\/policies/);
  }
}
