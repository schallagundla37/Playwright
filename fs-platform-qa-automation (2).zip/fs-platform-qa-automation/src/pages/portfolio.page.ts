import { Locator, Page, expect } from '@playwright/test';
import { BasePage } from './base.page';

/**
 * Portfolio holdings (GET /portfolio).
 *
 * Real DOM hooks (captured 2026-09): wrapper `portfolio-page`; summary band
 * `portfolio-summary` with `portfolio-total`, `portfolio-invested-total`,
 * `portfolio-gain-loss`, `portfolio-return-percent` and a
 * `portfolio-invest-more-button` → /mutual-funds; holdings table
 * `portfolio-holdings-table` with rows `holding-row-{id}` carrying
 * `holding-folio-{id}`, `holding-fund-name-{id}` (name + fund code),
 * `holding-units-{id}`, `holding-current-value-{id}` and a
 * `redeem-button-{id}` → /redeem/{holdingId}.
 */
export class PortfolioPage extends BasePage {
  readonly container: Locator;
  readonly summary: Locator;
  readonly totalValue: Locator;
  readonly investedTotal: Locator;
  readonly gainLoss: Locator;
  readonly returnPercent: Locator;
  readonly investMoreButton: Locator;
  readonly holdingsTable: Locator;

  constructor(page: Page) {
    super(page);
    this.container = page.getByTestId('portfolio-page');
    this.summary = page.getByTestId('portfolio-summary');
    this.totalValue = page.getByTestId('portfolio-total');
    this.investedTotal = page.getByTestId('portfolio-invested-total');
    this.gainLoss = page.getByTestId('portfolio-gain-loss');
    this.returnPercent = page.getByTestId('portfolio-return-percent');
    this.investMoreButton = page.getByTestId('portfolio-invest-more-button');
    this.holdingsTable = page.getByTestId('portfolio-holdings-table');
  }

  async goto(): Promise<void> {
    await this.page.goto('/portfolio');
    await this.expectLoaded();
  }

  async expectLoaded(): Promise<void> {
    await expect(this.page).toHaveURL(/\/portfolio/);
    await expect(this.container).toBeVisible();
    await expect(this.summary).toBeVisible();
  }

  /** All holding rows currently listed. */
  get holdingRows(): Locator {
    return this.page.locator('[data-testid^="holding-row-"]');
  }

  /** A holding row by its numeric holding id. */
  holdingRow(holdingId: number | string): Locator {
    return this.page.getByTestId(`holding-row-${holdingId}`);
  }

  /** A holding row located by fund code (e.g. FSHYB006) or fund name. */
  holdingRowByFund(fund: string | RegExp): Locator {
    return this.holdingRows.filter({
      has: this.page.locator('[data-testid^="holding-fund-name-"]', { hasText: fund }),
    });
  }

  /** Current-value cells of every holding row (for reconciliation checks). */
  get allCurrentValues(): Locator {
    return this.page.locator('[data-testid^="holding-current-value-"]');
  }

  /** Units cell of a holding, by holding id. */
  units(holdingId: number | string): Locator {
    return this.page.getByTestId(`holding-units-${holdingId}`);
  }

  /** Current value cell of a holding, by holding id. */
  currentValue(holdingId: number | string): Locator {
    return this.page.getByTestId(`holding-current-value-${holdingId}`);
  }

  /** Open the redemption flow for a holding (→ /redeem/{holdingId}). */
  async redeem(holdingId: number | string): Promise<void> {
    await this.page.getByTestId(`redeem-button-${holdingId}`).click();
    await expect(this.page).toHaveURL(/\/redeem\/\d+/);
  }

  /** Parse a ₹-formatted amount ("₹92,910.60") into a number. */
  static parseAmount(text: string): number {
    return Number(text.replace(/[₹,\s]/g, ''));
  }
}
