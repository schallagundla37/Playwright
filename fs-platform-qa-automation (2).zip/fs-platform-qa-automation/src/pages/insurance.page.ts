import { Locator, Page, expect } from '@playwright/test';
import { BasePage } from './base.page';

/** Premium range buckets offered by the listing filter (option values). */
export type PremiumRange = 'under_5000' | '5000_15000' | 'above_15000';

/**
 * Insurance product listing (GET /insurance).
 *
 * Real DOM hooks (captured 2026-09): wrapper `insurance-page`; GET filter form
 * `insurance-filter-form` with `insurance-search-input`,
 * `insurance-type-filter`, `premium-range-filter`, `insurance-filter-submit`
 * and an `insurance-filter-reset` link; product cards `insurance-card-{code}`
 * each carrying the name (h2), type badge, coverage
 * (`insurance-coverage-{code}`), premium (`insurance-premium-{code}`), term,
 * plus `insurance-details-link-{code}` → /insurance/{id} and
 * `buy-insurance-link-{code}` → /buy-insurance/{id}.
 */
export class InsurancePage extends BasePage {
  readonly container: Locator;
  readonly filterForm: Locator;
  readonly searchInput: Locator;
  readonly typeFilter: Locator;
  readonly premiumRangeFilter: Locator;
  readonly applyButton: Locator;
  readonly resetLink: Locator;

  constructor(page: Page) {
    super(page);
    this.container = page.getByTestId('insurance-page');
    this.filterForm = page.getByTestId('insurance-filter-form');
    this.searchInput = page.getByTestId('insurance-search-input');
    this.typeFilter = page.getByTestId('insurance-type-filter');
    this.premiumRangeFilter = page.getByTestId('premium-range-filter');
    this.applyButton = page.getByTestId('insurance-filter-submit');
    this.resetLink = page.getByTestId('insurance-filter-reset');
  }

  async goto(): Promise<void> {
    await this.page.goto('/insurance');
    await this.expectLoaded();
  }

  async expectLoaded(): Promise<void> {
    await expect(this.page).toHaveURL(/\/insurance/);
    await expect(this.container).toBeVisible();
    await expect(this.searchInput).toBeVisible();
  }

  /** All product cards currently rendered by the listing. */
  get productCards(): Locator {
    return this.page.locator('[data-testid^="insurance-card-"]');
  }

  /** A specific product card by product code, e.g. FSLIFE001. */
  productCard(productCode: string): Locator {
    return this.page.getByTestId(`insurance-card-${productCode}`);
  }

  /** Coverage amount shown on a product card, e.g. "₹10,000,000". */
  coverage(productCode: string): Locator {
    return this.page.getByTestId(`insurance-coverage-${productCode}`);
  }

  /** Premium amount shown on a product card, e.g. "₹14,500". */
  premium(productCode: string): Locator {
    return this.page.getByTestId(`insurance-premium-${productCode}`);
  }

  /** Visible product names, in render order. */
  get productNames(): Locator {
    return this.productCards.getByRole('heading', { level: 2 });
  }

  /**
   * Apply filters via the GET form. Only the provided fields are touched;
   * the form submits and the page reloads with query parameters.
   */
  async filter(options: {
    search?: string;
    insuranceType?: string;
    premiumRange?: PremiumRange;
  }): Promise<void> {
    if (options.search !== undefined) await this.searchInput.fill(options.search);
    if (options.insuranceType !== undefined) {
      await this.typeFilter.selectOption(options.insuranceType);
    }
    if (options.premiumRange !== undefined) {
      await this.premiumRangeFilter.selectOption(options.premiumRange);
    }
    await this.applyButton.click();
    await this.expectLoaded();
  }

  async resetFilters(): Promise<void> {
    await this.resetLink.click();
    await this.expectLoaded();
  }

  /** Open a product's detail page via its View Details link. */
  async openProductDetails(productCode: string): Promise<void> {
    await this.page.getByTestId(`insurance-details-link-${productCode}`).click();
    await expect(this.page).toHaveURL(/\/insurance\/\d+/);
  }

  /** Jump straight into the purchase flow via the card's Buy link. */
  async buyProduct(productCode: string): Promise<void> {
    await this.page.getByTestId(`buy-insurance-link-${productCode}`).click();
    await expect(this.page).toHaveURL(/\/buy-insurance\/\d+/);
  }
}
