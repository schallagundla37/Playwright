import { defineConfig, devices } from '@playwright/test';
import { env } from './src/config/env';

/**
 * Evidence strategy (Assignment 2, section 6):
 *  - trace:      retained for every failed test (open with `npx playwright show-trace`)
 *  - screenshot: captured on failure
 *  - video:      retained on failure
 *  - HTML report: always generated under playwright-report/
 */
export default defineConfig({
  testDir: './tests',
  outputDir: './test-results',
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 1 : 0,
  workers: process.env.CI ? 2 : undefined,
  timeout: 60_000,
  expect: { timeout: env.defaultTimeoutMs / 3 },

  reporter: [
    ['list'],
    ['html', { open: 'never' }],
    ['junit', { outputFile: 'test-results/junit-results.xml' }],
  ],

  use: {
    baseURL: env.baseUrl,
    headless: env.headless,
    trace: 'retain-on-failure',
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
    actionTimeout: env.defaultTimeoutMs,
    navigationTimeout: env.defaultTimeoutMs,
    testIdAttribute: 'data-testid',
  },

  projects: [
    { name: 'chromium', use: { ...devices['Desktop Chrome'] } },
    { name: 'firefox', use: { ...devices['Desktop Firefox'] } },
    { name: 'webkit', use: { ...devices['Desktop Safari'] } },
  ].filter((p) => env.browsers.includes(p.name)),
});
