import { test, expect } from '../../src/fixtures/test-fixtures';
import { env } from '../../src/config/env';
import { seededDefects } from '../../src/data/seeded-defects';
import { trace } from '../../src/utils/traceability';

/**
 * Module: Authentication (FinServe /login, /logout, session behavior)
 * Coverage: valid login, invalid credentials, locked account, logout and
 *           session invalidation, unauthenticated redirect.
 * Note: this app has no forgot-password / OTP flow — the login page offers
 * no such link, so no reset scenarios exist.
 */
test.describe('Authentication', { tag: ['@auth', '@regression'] }, () => {
  test(
    'TC-AUTH-001: valid customer can log in and reach the dashboard',
    { tag: '@smoke' },
    async ({ loginPage, dashboardPage }) => {
      trace(test.info(), { testCaseId: 'TC-AUTH-001', risk: 'AUTH-R1 login blocked' });

      await loginPage.goto();
      await loginPage.login(env.users.valid);
      await dashboardPage.expectLoaded();
    },
  );

  test('TC-AUTH-002: invalid password is rejected with an error', async ({ loginPage }) => {
    trace(test.info(), { testCaseId: 'TC-AUTH-002', risk: 'AUTH-R2 invalid-login handling' });

    await loginPage.goto();
    await loginPage.login({ email: env.users.valid.email, password: env.invalidPassword });
    await loginPage.expectLoginRejected();
  });

  test('TC-AUTH-003: unregistered email is rejected without revealing account existence', async ({
    loginPage,
  }) => {
    trace(test.info(), { testCaseId: 'TC-AUTH-003', risk: 'AUTH-R2 invalid-login handling' });

    await loginPage.goto();
    await loginPage.login({ email: 'no.such.user@finserve.test', password: env.invalidPassword });
    await loginPage.expectLoginRejected();
    // The message must not differ from the wrong-password case in a way that
    // confirms the account exists.
    await expect(loginPage.errorAlert).not.toContainText(/not (found|registered)|no account/i);
  });

  test(
    'TC-AUTH-004: locked user cannot log in',
    { tag: '@seeded-defect' },
    async ({ loginPage, page }) => {
      trace(test.info(), {
        testCaseId: 'TC-AUTH-004',
        risk: 'AUTH-R3 lockout handling',
        defect: seededDefects.SD_AUTH_01,
      });
      // On the seeded build this test is EXPECTED to fail — the failure (with
      // trace + screenshot) is the detection evidence for SD-AUTH-01.
      test.fail(env.seededDefectBuild, seededDefects.SD_AUTH_01.id);

      await loginPage.goto();
      await loginPage.login(env.users.locked);
      await expect(page).toHaveURL(/login/);
      await expect(page).not.toHaveURL(/dashboard/);
    },
  );

  test('TC-AUTH-005: logout invalidates the session', async ({ loggedInDashboard, page }) => {
    trace(test.info(), { testCaseId: 'TC-AUTH-005', risk: 'AUTH-R4 session handling' });

    await loggedInDashboard.logout();
    // Deep-linking back into the app must not restore the session.
    await page.goto('/dashboard');
    await expect(page).toHaveURL(/login/);
  });

  test('TC-AUTH-006: unauthenticated user is redirected to login', async ({ page, loginPage }) => {
    trace(test.info(), { testCaseId: 'TC-AUTH-006', risk: 'AUTH-R4 session handling' });

    for (const route of ['/dashboard', '/portfolio', '/policies', '/transactions']) {
      await page.goto(route);
      await expect(page).toHaveURL(/login/);
    }
    await loginPage.expectLoaded();
  });
});
