import { test, expect } from '../../src/fixtures/test-fixtures';
import { trace } from '../../src/utils/traceability';

/**
 * Module: Dashboard (GET /dashboard)
 * Coverage: summary stats, recent transactions, recommendations, navigation.
 */
test.describe('Dashboard', { tag: ['@dashboard', '@regression'] }, () => {
  test(
    'TC-DASH-001: dashboard shows the four summary stats with values',
    { tag: '@smoke' },
    async ({ loggedInDashboard }) => {
      trace(test.info(), { testCaseId: 'TC-DASH-001', risk: 'DASH-R1 summary accuracy' });

      await expect(loggedInDashboard.portfolioTotalValue).toHaveText(/₹[\d,.]+/);
      for (const label of ['Invested Amount', 'Gain / Loss', 'Active Policies']) {
        await expect(loggedInDashboard.statValue(label)).toHaveText(/[\d,.₹]+/);
      }
    },
  );

  test('TC-DASH-002: recent transactions list shows references and statuses', async ({
    loggedInDashboard,
  }) => {
    trace(test.info(), { testCaseId: 'TC-DASH-002', risk: 'DASH-R2 activity visibility' });

    const rows = loggedInDashboard.transactionRows;
    await expect(rows.first()).toBeVisible();
    await expect(rows.first()).toContainText(/^TXN-/);
    await expect(rows.first().locator('.badge')).toHaveText(
      /SUCCESS|PENDING|FAILED|CANCELLED/,
    );
  });

  test('TC-DASH-003: top navigation reaches every module', async ({
    loggedInDashboard,
    page,
  }) => {
    trace(test.info(), { testCaseId: 'TC-DASH-003', risk: 'DASH-R3 navigation' });

    const targets: Array<[string, RegExp]> = [
      ['Mutual Funds', /\/mutual-funds/],
      ['Portfolio', /\/portfolio/],
      ['Insurance', /\/insurance/],
      ['Policies', /\/policies/],
      ['Transactions', /\/transactions/],
      ['Dashboard', /\/dashboard/],
    ];
    for (const [link, url] of targets) {
      await loggedInDashboard.navigateTo(link);
      await expect(page).toHaveURL(url);
    }
  });

  test('TC-DASH-004: recommendation cards link to product details', async ({
    loggedInDashboard,
    page,
  }) => {
    trace(test.info(), { testCaseId: 'TC-DASH-004', risk: 'DASH-R4 recommendations' });
    void loggedInDashboard;

    const insuranceCards = page.locator('[data-testid^="insurance-product-card-"]');
    await expect(insuranceCards.first()).toBeVisible();
    await insuranceCards.first().getByRole('link', { name: 'View details' }).click();
    await expect(page).toHaveURL(/\/insurance\/\d+/);
  });
});
