import { test, expect } from '../../src/fixtures/test-fixtures';
import { happyPathProduct, validPurchaseInput } from '../../src/data/test-data';
import { trace } from '../../src/utils/traceability';

/**
 * End-to-end smoke: the full insurance purchase journey on the live app.
 *
 * login → dashboard → insurance listing → buy → confirmation → policy detail
 * → policy list → dashboard stat updated.
 */
test.describe('Smoke', { tag: ['@smoke'] }, () => {
  test('TC-E2E-001: customer buys an insurance policy end to end', async ({
    loggedInDashboard,
    insurancePage,
    buyInsurancePage,
    purchaseConfirmationPage,
    policyDetailsPage,
    policiesPage,
    dashboardPage,
    page,
  }) => {
    trace(test.info(), { testCaseId: 'TC-E2E-001', risk: 'E2E-R1 core purchase journey' });

    // Dashboard baseline: active policy count before the purchase.
    const before = Number(
      (await loggedInDashboard.statValue('Active Policies').innerText()).trim(),
    );

    // Browse to the product and open the purchase form.
    await loggedInDashboard.navigateTo('Insurance');
    await insurancePage.expectLoaded();
    await insurancePage.buyProduct(happyPathProduct.code);
    await buyInsurancePage.expectLoaded();
    await expect(buyInsurancePage.productName).toHaveText(happyPathProduct.name);
    await buyInsurancePage.expectPremiumConsistent();

    // Purchase.
    const input = validPurchaseInput();
    await buyInsurancePage.purchase(input);

    // Confirmation: product, premium, and well-formed identifiers.
    await purchaseConfirmationPage.expectLoaded(happyPathProduct.name);
    await expect(purchaseConfirmationPage.premiumAmount).toHaveText(
      happyPathProduct.premiumText,
    );
    const policyNumber = await purchaseConfirmationPage.capturePolicyNumber();

    // Policy detail: record matches what was purchased.
    await purchaseConfirmationPage.viewCreatedPolicy();
    await policyDetailsPage.expectLoaded();
    await expect(policyDetailsPage.policyNumber).toHaveText(policyNumber);
    await expect(policyDetailsPage.productName).toHaveText(happyPathProduct.name);
    await expect(policyDetailsPage.metric('Coverage Amount')).toHaveText(
      happyPathProduct.coverageText,
    );
    await expect(policyDetailsPage.metric('Nominee')).toContainText(input.nomineeName);
    await expect(policyDetailsPage.metric('Status')).toHaveText('Active');

    // Policy list: the new policy is present and Active.
    await policyDetailsPage.backToPolicies();
    await expect(policiesPage.policyRowByNumber(policyNumber)).toBeVisible();
    await expect(policiesPage.statusOf(policyNumber)).toHaveText('Active');

    // Dashboard: active policy count increased by one.
    await page.goto('/dashboard');
    await dashboardPage.expectLoaded();
    await expect(dashboardPage.statValue('Active Policies')).toHaveText(String(before + 1));
  });
});
