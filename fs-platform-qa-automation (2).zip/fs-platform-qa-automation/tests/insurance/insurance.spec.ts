import { test, expect } from '../../src/fixtures/test-fixtures';
import { insuranceProducts, premiumRangeBuckets } from '../../src/data/test-data';
import { trace } from '../../src/utils/traceability';

/**
 * Module: Insurance product listing (GET /insurance)
 * Coverage: seeded listing, search, type filter, premium-range filter, card
 *           data accuracy, navigation into detail and purchase routes.
 */
test.describe('Insurance Products', { tag: ['@insurance', '@regression'] }, () => {
  test.beforeEach(async ({ loggedInDashboard, insurancePage }) => {
    void loggedInDashboard;
    await insurancePage.goto();
  });

  test(
    'TC-INS-001: listing shows all seeded insurance products',
    { tag: '@smoke' },
    async ({ insurancePage }) => {
      trace(test.info(), { testCaseId: 'TC-INS-001', risk: 'INS-R1 catalog visibility' });

      await expect(insurancePage.productCards).toHaveCount(insuranceProducts.length);
      for (const product of insuranceProducts) {
        await expect(insurancePage.productCard(product.code)).toBeVisible();
      }
    },
  );

  test('TC-INS-002: type filter returns exactly the seeded members', async ({
    insurancePage,
  }) => {
    trace(test.info(), { testCaseId: 'TC-INS-002', risk: 'INS-R2 filters' });

    for (const type of [
      'Term Insurance',
      'Health Insurance',
      'Motor Insurance',
      'Travel Insurance',
    ] as const) {
      const expected = insuranceProducts.filter((p) => p.type === type);
      await insurancePage.filter({ insuranceType: type });
      await expect(insurancePage.productCards).toHaveCount(expected.length);
      for (const product of expected) {
        await expect(insurancePage.productCard(product.code)).toBeVisible();
      }
      await insurancePage.resetFilters();
    }
  });

  test('TC-INS-003: premium range filter buckets products correctly', async ({
    insurancePage,
  }) => {
    trace(test.info(), { testCaseId: 'TC-INS-003', risk: 'INS-R2 filters' });

    for (const [range, codes] of Object.entries(premiumRangeBuckets)) {
      await insurancePage.filter({ premiumRange: range as keyof typeof premiumRangeBuckets });
      await expect(insurancePage.productCards).toHaveCount(codes.length);
      for (const code of codes) {
        await expect(insurancePage.productCard(code)).toBeVisible();
      }
      await insurancePage.resetFilters();
    }
  });

  test('TC-INS-004: search narrows the listing to matching products', async ({
    insurancePage,
  }) => {
    trace(test.info(), { testCaseId: 'TC-INS-004', risk: 'INS-R3 search' });

    await insurancePage.filter({ search: 'Travel' });
    await expect(insurancePage.productCards).toHaveCount(1);
    await expect(insurancePage.productCard('FSTRVL007')).toBeVisible();
  });

  test('TC-INS-005: product cards show the seeded coverage and premium', async ({
    insurancePage,
  }) => {
    trace(test.info(), { testCaseId: 'TC-INS-005', risk: 'INS-R4 data accuracy' });

    for (const product of insuranceProducts) {
      await expect(insurancePage.coverage(product.code)).toHaveText(product.coverageText);
      await expect(insurancePage.premium(product.code)).toHaveText(product.premiumText);
    }
  });

  test('TC-INS-006: view details opens the product detail route', async ({
    insurancePage,
    page,
  }) => {
    trace(test.info(), { testCaseId: 'TC-INS-006', risk: 'INS-R5 detail navigation' });

    await insurancePage.openProductDetails('FSLIFE001');
    await expect(page).toHaveURL(/\/insurance\/1$/);
  });

  test('TC-INS-007: Buy opens the purchase route for the same product', async ({
    insurancePage,
    buyInsurancePage,
  }) => {
    trace(test.info(), { testCaseId: 'TC-INS-007', risk: 'INS-R5 purchase navigation' });

    await insurancePage.buyProduct('FSLIFE001');
    await buyInsurancePage.expectLoaded();
    await expect(buyInsurancePage.productName).toHaveText('FinServe Life Protect Term Plan');
  });
});
