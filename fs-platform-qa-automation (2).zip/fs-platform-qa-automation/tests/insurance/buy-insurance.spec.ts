import { test, expect } from '../../src/fixtures/test-fixtures';
import { env } from '../../src/config/env';
import {
  happyPathProduct,
  insuranceProducts,
  validPurchaseInput,
} from '../../src/data/test-data';
import { seededDefects } from '../../src/data/seeded-defects';
import { trace } from '../../src/utils/traceability';

/**
 * Module: Insurance purchase (GET/POST /buy-insurance/{id})
 * Coverage: premium consistency (app-hinted check), successful purchase with
 *           confirmation, declaration/nominee validation, eligibility DOB,
 *           cancel path.
 */
test.describe('Insurance Purchase', { tag: ['@purchase', '@regression'] }, () => {
  test.beforeEach(async ({ loggedInDashboard }) => {
    void loggedInDashboard;
  });

  test(
    'TC-BUY-001: review premium matches the product premium on every product',
    { tag: '@seeded-defect' },
    async ({ buyInsurancePage }) => {
      trace(test.info(), {
        testCaseId: 'TC-BUY-001',
        risk: 'BUY-R1 premium integrity',
        defect: seededDefects.SD_PREMIUM_01,
      });
      test.fail(env.seededDefectBuild, seededDefects.SD_PREMIUM_01.id);

      for (const product of insuranceProducts) {
        await buyInsurancePage.goto(product.id);
        await expect(buyInsurancePage.productPremium).toHaveText(product.premiumText);
        await buyInsurancePage.expectPremiumConsistent();
      }
    },
  );

  test(
    'TC-BUY-002: completed purchase creates a policy and a transaction',
    { tag: '@smoke' },
    async ({ insurancePage, buyInsurancePage, purchaseConfirmationPage }) => {
      trace(test.info(), { testCaseId: 'TC-BUY-002', risk: 'BUY-R2 purchase flow' });

      await insurancePage.goto();
      await insurancePage.buyProduct(happyPathProduct.code);
      await buyInsurancePage.purchase(validPurchaseInput());

      await purchaseConfirmationPage.expectLoaded(happyPathProduct.name);
      await expect(purchaseConfirmationPage.premiumAmount).toHaveText(
        happyPathProduct.premiumText,
      );
    },
  );

  test('TC-BUY-003: purchase is rejected without the accuracy declaration', async ({
    buyInsurancePage,
    purchaseConfirmationPage,
    page,
  }) => {
    trace(test.info(), { testCaseId: 'TC-BUY-003', risk: 'BUY-R3 mandatory declaration' });

    await buyInsurancePage.goto(happyPathProduct.id);
    await buyInsurancePage.fillForm({ ...validPurchaseInput(), acceptDeclaration: false });
    await buyInsurancePage.submit();

    // No policy may be created: the user stays on the purchase form.
    await expect(page).toHaveURL(/\/buy-insurance\/\d+/);
    await expect(purchaseConfirmationPage.container).not.toBeVisible();
  });

  test('TC-BUY-004: purchase is rejected without nominee details', async ({
    buyInsurancePage,
    purchaseConfirmationPage,
    page,
  }) => {
    trace(test.info(), { testCaseId: 'TC-BUY-004', risk: 'BUY-R4 mandatory nominee' });

    await buyInsurancePage.goto(happyPathProduct.id);
    await buyInsurancePage.fillForm({
      dateOfBirth: validPurchaseInput().dateOfBirth,
      acceptDeclaration: true,
    });
    await buyInsurancePage.submit();

    await expect(page).toHaveURL(/\/buy-insurance\/\d+/);
    await expect(purchaseConfirmationPage.container).not.toBeVisible();
  });

  test(
    'TC-BUY-005: date of birth outside eligibility age is rejected',
    { tag: '@seeded-defect' },
    async ({ buyInsurancePage, purchaseConfirmationPage, page }) => {
      trace(test.info(), {
        testCaseId: 'TC-BUY-005',
        risk: 'BUY-R5 eligibility validation',
        defect: seededDefects.SD_ELIG_01,
      });
      test.fail(env.seededDefectBuild, seededDefects.SD_ELIG_01.id);

      await buyInsurancePage.goto(happyPathProduct.id);
      // A 5-year-old applicant is below any term-insurance minimum age.
      await buyInsurancePage.purchase({ ...validPurchaseInput(), dateOfBirth: '2021-01-01' });

      await expect(page).toHaveURL(/\/buy-insurance\/\d+/);
      await expect(purchaseConfirmationPage.container).not.toBeVisible();
    },
  );

  test('TC-BUY-006: cancel returns to the product detail without purchasing', async ({
    buyInsurancePage,
    page,
  }) => {
    trace(test.info(), { testCaseId: 'TC-BUY-006', risk: 'BUY-R6 cancel path' });

    await buyInsurancePage.goto(happyPathProduct.id);
    await buyInsurancePage.cancel();
    await expect(page).toHaveURL(new RegExp(`/insurance/${happyPathProduct.id}$`));
  });
});
