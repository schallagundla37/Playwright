import { test, expect } from '../../src/fixtures/test-fixtures';
import { env } from '../../src/config/env';
import { trace } from '../../src/utils/traceability';

/**
 * Module: Policies (GET /policies, /policies/{id})
 * Coverage: user-scoped policy list, status filter, policy detail metrics.
 * Uses the `insurance1` seed user, which holds pre-existing active policies.
 */
test.describe('Policies', { tag: ['@policies', '@regression'] }, () => {
  test.beforeEach(async ({ loginAs, policiesPage }) => {
    await loginAs(env.users.insurance);
    await policiesPage.goto();
  });

  test(
    'TC-POL-001: policy list shows the customer policies',
    { tag: '@smoke' },
    async ({ policiesPage }) => {
      trace(test.info(), { testCaseId: 'TC-POL-001', risk: 'POL-R1 policy visibility' });

      await expect(policiesPage.policyRows.first()).toBeVisible();
      // Every row carries a well-formed policy number.
      const numbers = policiesPage.policyRows.locator('[data-testid^="policy-number-"]');
      for (const text of await numbers.allInnerTexts()) {
        expect(text.trim()).toMatch(/^POL-\d{8}-[A-Z0-9]+$/);
      }
    },
  );

  test('TC-POL-002: status filter shows only policies in that status', async ({
    policiesPage,
  }) => {
    trace(test.info(), { testCaseId: 'TC-POL-002', risk: 'POL-R2 status filter' });

    await policiesPage.filterByStatus('Active');
    const pills = policiesPage.policyRows.locator('[data-testid^="policy-status-"]');
    const statuses = await pills.allInnerTexts();
    expect(statuses.length).toBeGreaterThan(0);
    for (const status of statuses) {
      expect(status.trim()).toBe('Active');
    }
  });

  test('TC-POL-003: policy detail shows the full policy record', async ({
    policiesPage,
    policyDetailsPage,
    page,
  }) => {
    trace(test.info(), { testCaseId: 'TC-POL-003', risk: 'POL-R3 detail accuracy' });

    const firstNumber = (
      await policiesPage.policyRows
        .first()
        .locator('[data-testid^="policy-number-"]')
        .innerText()
    ).trim();
    await policiesPage.openPolicyDetails(firstNumber);

    await policyDetailsPage.expectLoaded();
    await expect(policyDetailsPage.policyNumber).toHaveText(firstNumber);
    for (const label of [
      'Insurance Type',
      'Insured Name',
      'Coverage Amount',
      'Premium Amount',
      'Nominee',
      'Start Date',
      'End Date',
      'Status',
    ]) {
      await expect(policyDetailsPage.metric(label)).not.toBeEmpty();
    }

    await policyDetailsPage.backToPolicies();
    await expect(page).toHaveURL(/\/policies$/);
  });
});
