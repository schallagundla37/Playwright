import { test, expect } from '../../src/fixtures/test-fixtures';
import { funds, topReturnFundCode, lowestNavFundCode } from '../../src/data/test-data';
import { trace } from '../../src/utils/traceability';

/**
 * Module: Mutual Funds listing (GET /mutual-funds)
 * Coverage: seeded listing, search, category/risk filters, sorting, reset.
 */
test.describe('Mutual Funds', { tag: ['@mutual-funds', '@regression'] }, () => {
  test.beforeEach(async ({ loggedInDashboard, mutualFundsPage }) => {
    void loggedInDashboard;
    await mutualFundsPage.goto();
  });

  test(
    'TC-FUND-001: listing shows all seeded funds',
    { tag: '@smoke' },
    async ({ mutualFundsPage }) => {
      trace(test.info(), { testCaseId: 'TC-FUND-001', risk: 'FUND-R1 catalog visibility' });

      await expect(mutualFundsPage.fundCards).toHaveCount(funds.length);
      for (const fund of funds) {
        await expect(mutualFundsPage.fundCard(fund.code)).toBeVisible();
      }
    },
  );

  test('TC-FUND-002: search narrows the listing to matching funds', async ({
    mutualFundsPage,
  }) => {
    trace(test.info(), { testCaseId: 'TC-FUND-002', risk: 'FUND-R2 search' });

    await mutualFundsPage.filter({ search: 'Bluechip' });
    await expect(mutualFundsPage.fundCards).toHaveCount(1);
    await expect(mutualFundsPage.fundCard('FSBLU001')).toBeVisible();
  });

  test('TC-FUND-003: category filter returns exactly the seeded members', async ({
    mutualFundsPage,
  }) => {
    trace(test.info(), { testCaseId: 'TC-FUND-003', risk: 'FUND-R3 filters' });

    for (const category of ['ELSS', 'Index Fund', 'Debt Fund'] as const) {
      const expected = funds.filter((f) => f.category === category);
      await mutualFundsPage.filter({ category });
      await expect(mutualFundsPage.fundCards).toHaveCount(expected.length);
      for (const fund of expected) {
        await expect(mutualFundsPage.fundCard(fund.code)).toBeVisible();
      }
      await mutualFundsPage.resetFilters();
    }
  });

  test('TC-FUND-004: risk filter returns exactly the seeded members', async ({
    mutualFundsPage,
  }) => {
    trace(test.info(), { testCaseId: 'TC-FUND-004', risk: 'FUND-R3 filters' });

    const lowRisk = funds.filter((f) => f.risk === 'Low');
    await mutualFundsPage.filter({ riskLevel: 'Low' });
    await expect(mutualFundsPage.fundCards).toHaveCount(lowRisk.length);
    for (const fund of lowRisk) {
      await expect(mutualFundsPage.fundCard(fund.code)).toBeVisible();
    }
  });

  test('TC-FUND-005: sorting by 1-year return puts the top performer first', async ({
    mutualFundsPage,
  }) => {
    trace(test.info(), { testCaseId: 'TC-FUND-005', risk: 'FUND-R4 sorting' });

    await mutualFundsPage.filter({ sort: 'one_year_return_desc' });
    const topFund = funds.find((f) => f.code === topReturnFundCode)!;
    await expect(mutualFundsPage.fundNames.first()).toHaveText(topFund.name);
  });

  test('TC-FUND-006: sorting by NAV ascending puts the cheapest NAV first', async ({
    mutualFundsPage,
  }) => {
    trace(test.info(), { testCaseId: 'TC-FUND-006', risk: 'FUND-R4 sorting' });

    await mutualFundsPage.filter({ sort: 'nav_asc' });
    const lowestNav = funds.find((f) => f.code === lowestNavFundCode)!;
    await expect(mutualFundsPage.fundNames.first()).toHaveText(lowestNav.name);
  });

  test('TC-FUND-007: reset restores the unfiltered listing', async ({ mutualFundsPage }) => {
    trace(test.info(), { testCaseId: 'TC-FUND-007', risk: 'FUND-R3 filters' });

    await mutualFundsPage.filter({ search: 'Bluechip' });
    await expect(mutualFundsPage.fundCards).toHaveCount(1);
    await mutualFundsPage.resetFilters();
    await expect(mutualFundsPage.fundCards).toHaveCount(funds.length);
  });

  test('TC-FUND-008: view details opens the fund detail route', async ({ mutualFundsPage, page }) => {
    trace(test.info(), { testCaseId: 'TC-FUND-008', risk: 'FUND-R5 detail navigation' });

    await mutualFundsPage.openFundDetails('FSBLU001');
    await expect(page).toHaveURL(/\/mutual-funds\/1$/);
  });
});
