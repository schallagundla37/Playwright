import { test, expect } from '../../src/fixtures/test-fixtures';
import { env } from '../../src/config/env';
import { PortfolioPage } from '../../src/pages/portfolio.page';
import { seededDefects } from '../../src/data/seeded-defects';
import { trace } from '../../src/utils/traceability';

/**
 * Module: Portfolio (GET /portfolio)
 * Coverage: summary metrics, summary-vs-holdings reconciliation, holdings
 *           integrity, redemption entry points.
 * Uses the primary investor seed user (has holdings).
 */
test.describe('Portfolio', { tag: ['@portfolio', '@regression'] }, () => {
  test.beforeEach(async ({ loggedInDashboard, portfolioPage }) => {
    void loggedInDashboard;
    await portfolioPage.goto();
  });

  test(
    'TC-PORT-001: summary band shows the four portfolio metrics',
    { tag: '@smoke' },
    async ({ portfolioPage }) => {
      trace(test.info(), { testCaseId: 'TC-PORT-001', risk: 'PORT-R1 summary visibility' });

      await expect(portfolioPage.totalValue).toHaveText(/₹[\d,.]+/);
      await expect(portfolioPage.investedTotal).toHaveText(/₹[\d,.]+/);
      await expect(portfolioPage.gainLoss).toHaveText(/₹[\d,.-]+/);
      await expect(portfolioPage.returnPercent).toHaveText(/[\d.-]+%/);
    },
  );

  test('TC-PORT-002: summary totals reconcile with the holdings table', async ({
    portfolioPage,
  }) => {
    trace(test.info(), { testCaseId: 'TC-PORT-002', risk: 'PORT-R2 calculation accuracy' });

    const currentValues = await portfolioPage.allCurrentValues.allInnerTexts();
    const sumOfRows = currentValues
      .map(PortfolioPage.parseAmount)
      .reduce((a, b) => a + b, 0);

    const summaryTotal = PortfolioPage.parseAmount(await portfolioPage.totalValue.innerText());
    expect(Math.abs(summaryTotal - sumOfRows)).toBeLessThan(0.01);
  });

  test('TC-PORT-003: gain/loss equals current value minus invested amount', async ({
    portfolioPage,
  }) => {
    trace(test.info(), { testCaseId: 'TC-PORT-003', risk: 'PORT-R2 calculation accuracy' });

    const current = PortfolioPage.parseAmount(await portfolioPage.totalValue.innerText());
    const invested = PortfolioPage.parseAmount(await portfolioPage.investedTotal.innerText());
    const gainLoss = PortfolioPage.parseAmount(await portfolioPage.gainLoss.innerText());
    expect(Math.abs(gainLoss - (current - invested))).toBeLessThan(0.01);
  });

  test('TC-PORT-004: every holding row is complete and actionable', async ({
    portfolioPage,
  }) => {
    trace(test.info(), { testCaseId: 'TC-PORT-004', risk: 'PORT-R3 holdings integrity' });

    const rowCount = await portfolioPage.holdingRows.count();
    expect(rowCount).toBeGreaterThan(0);
    for (let i = 0; i < rowCount; i++) {
      const row = portfolioPage.holdingRows.nth(i);
      await expect(row.locator('[data-testid^="holding-folio-"]')).toHaveText(/^FOL-/);
      await expect(row.locator('[data-testid^="holding-fund-name-"]')).toContainText(/^FinServe/);
      await expect(row.locator('[data-testid^="holding-units-"]')).toHaveText(/^[\d,]+\.\d{4}$/);
    }
  });

  test('TC-PORT-005: Invest More leads to the mutual funds listing', async ({
    portfolioPage,
    mutualFundsPage,
  }) => {
    trace(test.info(), { testCaseId: 'TC-PORT-005', risk: 'PORT-R4 navigation' });

    await portfolioPage.investMoreButton.click();
    await mutualFundsPage.expectLoaded();
  });

  test(
    'TC-PORT-006: holdings with zero units do not offer redemption',
    { tag: '@seeded-defect' },
    async ({ portfolioPage }) => {
      trace(test.info(), {
        testCaseId: 'TC-PORT-006',
        risk: 'PORT-R5 redemption guards',
        defect: seededDefects.SD_REDEEM_01,
      });
      test.fail(env.seededDefectBuild, seededDefects.SD_REDEEM_01.id);

      const rowCount = await portfolioPage.holdingRows.count();
      const zeroUnitRows = [];
      for (let i = 0; i < rowCount; i++) {
        const row = portfolioPage.holdingRows.nth(i);
        const units = await row.locator('[data-testid^="holding-units-"]').innerText();
        if (PortfolioPage.parseAmount(units) === 0) zeroUnitRows.push(row);
      }
      test.skip(zeroUnitRows.length === 0, 'No zero-unit holdings for this user right now.');

      for (const row of zeroUnitRows) {
        // A fully-redeemed holding must not offer an active Redeem entry point.
        await expect(row.locator('[data-testid^="redeem-button-"]')).not.toBeVisible();
      }
    },
  );
});
