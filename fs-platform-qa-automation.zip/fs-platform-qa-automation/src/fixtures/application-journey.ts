import { DashboardPage } from '../pages/dashboard.page';
import { ClientDetailsPage } from '../pages/client-details.page';
import { AddressContactPage } from '../pages/address-contact.page';
import { ProductConfigPage } from '../pages/product-config.page';
import { RidersBeneficiariesPage } from '../pages/riders-beneficiaries.page';
import { DocumentsPage } from '../pages/documents.page';
import { ReviewSubmitPage } from '../pages/review-submit.page';
import {
  validAddress,
  validBeneficiaries,
  validClient,
  validProduct,
} from '../data/application-data';

/**
 * Drives the application wizard with valid baseline data up to the step a
 * test wants to exercise. Module specs use this to reach their screen
 * without re-scripting every earlier step, keeping each spec focused on the
 * behavior it owns.
 */
export class ApplicationJourney {
  constructor(
    readonly dashboard: DashboardPage,
    readonly clientDetails: ClientDetailsPage,
    readonly addressContact: AddressContactPage,
    readonly productConfig: ProductConfigPage,
    readonly ridersBeneficiaries: RidersBeneficiariesPage,
    readonly documents: DocumentsPage,
    readonly reviewSubmit: ReviewSubmitPage,
  ) {}

  /** Dashboard -> new application -> Client Details visible. */
  async toClientDetails(): Promise<void> {
    await this.dashboard.startNewApplication();
    await this.clientDetails.expectLoaded();
  }

  async toAddressContact(): Promise<void> {
    await this.toClientDetails();
    await this.clientDetails.fill(validClient());
    await this.clientDetails.saveAndContinue();
    await this.addressContact.expectLoaded();
  }

  async toProductConfig(): Promise<void> {
    await this.toAddressContact();
    await this.addressContact.fill(validAddress());
    await this.addressContact.saveAndContinue();
    await this.productConfig.expectLoaded();
  }

  async toRidersBeneficiaries(): Promise<void> {
    await this.toProductConfig();
    await this.productConfig.configure(validProduct());
    await this.productConfig.saveAndContinue();
    await this.ridersBeneficiaries.expectLoaded();
  }

  async toDocuments(): Promise<void> {
    await this.toRidersBeneficiaries();
    await this.ridersBeneficiaries.addBeneficiaries(validBeneficiaries());
    await this.ridersBeneficiaries.saveAndContinue();
    await this.documents.expectLoaded();
  }

  async toReview(sampleDocumentPath: string): Promise<void> {
    await this.toDocuments();
    await this.documents.uploadIdProof(sampleDocumentPath);
    await this.documents.uploadAddressProof(sampleDocumentPath);
    await this.documents.saveAndContinue();
    await this.reviewSubmit.expectLoaded();
  }
}
