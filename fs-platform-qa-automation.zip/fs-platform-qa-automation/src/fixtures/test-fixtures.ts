import { test as base } from '@playwright/test';
import { env } from '../config/env';
import { LoginPage } from '../pages/login.page';
import { ForgotPasswordPage } from '../pages/forgot-password.page';
import { DashboardPage } from '../pages/dashboard.page';
import { ClientDetailsPage } from '../pages/client-details.page';
import { AddressContactPage } from '../pages/address-contact.page';
import { ProductConfigPage } from '../pages/product-config.page';
import { RidersBeneficiariesPage } from '../pages/riders-beneficiaries.page';
import { DocumentsPage } from '../pages/documents.page';
import { ReviewSubmitPage } from '../pages/review-submit.page';
import { ApplicationJourney } from './application-journey';

interface Fixtures {
  loginPage: LoginPage;
  forgotPasswordPage: ForgotPasswordPage;
  dashboardPage: DashboardPage;
  clientDetailsPage: ClientDetailsPage;
  addressContactPage: AddressContactPage;
  productConfigPage: ProductConfigPage;
  ridersBeneficiariesPage: RidersBeneficiariesPage;
  documentsPage: DocumentsPage;
  reviewSubmitPage: ReviewSubmitPage;

  /** Logs in as the valid seed customer and lands on the dashboard. */
  loggedInDashboard: DashboardPage;

  /** Composes page objects to drive the wizard to a chosen step. */
  journey: ApplicationJourney;
}

export const test = base.extend<Fixtures>({
  loginPage: async ({ page }, use) => use(new LoginPage(page)),
  forgotPasswordPage: async ({ page }, use) => use(new ForgotPasswordPage(page)),
  dashboardPage: async ({ page }, use) => use(new DashboardPage(page)),
  clientDetailsPage: async ({ page }, use) => use(new ClientDetailsPage(page)),
  addressContactPage: async ({ page }, use) => use(new AddressContactPage(page)),
  productConfigPage: async ({ page }, use) => use(new ProductConfigPage(page)),
  ridersBeneficiariesPage: async ({ page }, use) => use(new RidersBeneficiariesPage(page)),
  documentsPage: async ({ page }, use) => use(new DocumentsPage(page)),
  reviewSubmitPage: async ({ page }, use) => use(new ReviewSubmitPage(page)),

  loggedInDashboard: async ({ loginPage, dashboardPage }, use) => {
    await loginPage.goto();
    await loginPage.login(env.users.valid);
    await dashboardPage.expectLoaded();
    await use(dashboardPage);
  },

  journey: async (
    {
      loggedInDashboard,
      clientDetailsPage,
      addressContactPage,
      productConfigPage,
      ridersBeneficiariesPage,
      documentsPage,
      reviewSubmitPage,
    },
    use,
  ) => {
    await use(
      new ApplicationJourney(
        loggedInDashboard,
        clientDetailsPage,
        addressContactPage,
        productConfigPage,
        ridersBeneficiariesPage,
        documentsPage,
        reviewSubmitPage,
      ),
    );
  },
});

export { expect } from '@playwright/test';
