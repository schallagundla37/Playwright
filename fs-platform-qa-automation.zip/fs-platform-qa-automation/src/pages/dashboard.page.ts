import { Locator, Page, expect } from '@playwright/test';
import { BasePage } from './base.page';

export class DashboardPage extends BasePage {
  readonly welcomeHeading: Locator;
  readonly startApplicationButton: Locator;
  readonly applicationsTable: Locator;
  readonly logoutButton: Locator;

  constructor(page: Page) {
    super(page);
    this.welcomeHeading = page.getByRole('heading', { name: /dashboard|welcome/i });
    this.startApplicationButton = page.getByRole('button', {
      name: /start (new )?application/i,
    });
    this.applicationsTable = page.getByTestId('applications-table');
    this.logoutButton = page.getByRole('button', { name: /log ?out|sign out/i });
  }

  async expectLoaded(): Promise<void> {
    await expect(this.welcomeHeading).toBeVisible();
    await expect(this.page).toHaveURL(/dashboard/);
  }

  async startNewApplication(): Promise<void> {
    await this.startApplicationButton.click();
  }

  /** Row for a specific application, matched by its reference number. */
  applicationRow(referenceNumber: string): Locator {
    return this.applicationsTable.getByRole('row', { name: new RegExp(referenceNumber) });
  }

  async expectApplicationStatus(referenceNumber: string, status: string | RegExp): Promise<void> {
    await expect(this.applicationRow(referenceNumber).getByTestId('application-status')).toHaveText(
      status,
    );
  }

  async logout(): Promise<void> {
    await this.logoutButton.click();
    await expect(this.page).toHaveURL(/login/);
  }
}
