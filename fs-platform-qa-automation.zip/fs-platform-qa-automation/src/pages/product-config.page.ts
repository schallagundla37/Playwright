import { Locator, Page, expect } from '@playwright/test';
import { BasePage } from './base.page';
import { ProductSelection } from '../data/application-data';

export class ProductConfigPage extends BasePage {
  readonly heading: Locator;
  readonly productSelect: Locator;
  readonly sumAssuredInput: Locator;
  readonly premiumFrequencySelect: Locator;
  readonly calculatedPremium: Locator;

  constructor(page: Page) {
    super(page);
    this.heading = page.getByRole('heading', { name: /product configuration/i });
    this.productSelect = page.getByLabel(/product/i);
    this.sumAssuredInput = page.getByLabel(/sum assured/i);
    this.premiumFrequencySelect = page.getByLabel(/premium frequency/i);
    this.calculatedPremium = page.getByTestId('calculated-premium');
  }

  async expectLoaded(): Promise<void> {
    await expect(this.heading).toBeVisible();
  }

  async configure(product: ProductSelection): Promise<void> {
    await this.productSelect.selectOption({ label: product.productName });
    await this.setSumAssured(product.sumAssured);
    await this.premiumFrequencySelect.selectOption(product.premiumFrequency);
  }

  async setSumAssured(amount: number): Promise<void> {
    await this.sumAssuredInput.fill(String(amount));
    await this.sumAssuredInput.blur();
  }

  /**
   * Reads the premium currently displayed, stripped to a number so tests can
   * compare values across recalculation triggers.
   */
  async premiumValue(): Promise<number> {
    await expect(this.calculatedPremium).toBeVisible();
    const raw = (await this.calculatedPremium.innerText()).replace(/[^0-9.]/g, '');
    expect(raw, `premium text should contain a number, got "${raw}"`).not.toBe('');
    return Number(raw);
  }

  /** True when the given product appears as a selectable (enabled) option. */
  async isProductSelectable(productName: string): Promise<boolean> {
    const option = this.productSelect.locator('option', { hasText: productName });
    if ((await option.count()) === 0) return false;
    return !(await option.first().isDisabled());
  }
}
