import { Locator, Page, expect } from '@playwright/test';
import { BasePage } from './base.page';
import { Beneficiary } from '../data/application-data';

/**
 * Riders and Beneficiaries are two sub-sections of one wizard step in the
 * expected navigation flow; both are modeled here. Split into separate page
 * objects if the live app renders them as separate routes.
 */
export class RidersBeneficiariesPage extends BasePage {
  readonly heading: Locator;
  readonly addBeneficiaryButton: Locator;
  readonly allocationTotal: Locator;

  constructor(page: Page) {
    super(page);
    this.heading = page.getByRole('heading', { name: /riders|beneficiar/i });
    this.addBeneficiaryButton = page.getByRole('button', { name: /add beneficiary/i });
    this.allocationTotal = page.getByTestId('allocation-total');
  }

  async expectLoaded(): Promise<void> {
    await expect(this.heading).toBeVisible();
  }

  riderCheckbox(riderName: string): Locator {
    return this.page.getByRole('checkbox', { name: new RegExp(riderName, 'i') });
  }

  async selectRider(riderName: string): Promise<void> {
    await this.riderCheckbox(riderName).check();
  }

  /** The nth beneficiary entry card/row (0-based). */
  private beneficiaryRow(index: number): Locator {
    return this.page.getByTestId('beneficiary-row').nth(index);
  }

  async addBeneficiary(index: number, beneficiary: Beneficiary): Promise<void> {
    if ((await this.page.getByTestId('beneficiary-row').count()) <= index) {
      await this.addBeneficiaryButton.click();
    }
    const row = this.beneficiaryRow(index);
    await row.getByLabel(/name/i).fill(beneficiary.name);
    await row.getByLabel(/relationship/i).selectOption(beneficiary.relationship);
    await row.getByLabel(/allocation/i).fill(String(beneficiary.allocationPercent));
    await row.getByLabel(/allocation/i).blur();
  }

  async addBeneficiaries(beneficiaries: Beneficiary[]): Promise<void> {
    for (const [index, beneficiary] of beneficiaries.entries()) {
      await this.addBeneficiary(index, beneficiary);
    }
  }

  async expectAllocationTotal(expectedPercent: number): Promise<void> {
    await expect(this.allocationTotal).toContainText(`${expectedPercent}%`);
  }
}
