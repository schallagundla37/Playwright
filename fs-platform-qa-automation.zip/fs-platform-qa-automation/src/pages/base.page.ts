import { Locator, Page, expect } from '@playwright/test';

/**
 * Shared behavior for all pages of the application wizard.
 *
 * Locator strategy: user-facing role/label locators first, `data-testid`
 * (configured as the testIdAttribute in playwright.config.ts) where the DOM
 * offers no stable accessible handle. No CSS/XPath chains, no waits on time.
 */
export abstract class BasePage {
  protected constructor(protected readonly page: Page) {}

  /** Global toast/banner used by the app for success and error feedback. */
  get toast(): Locator {
    return this.page.getByRole('alert');
  }

  /** Inline validation message attached to a specific field. */
  fieldError(fieldName: string): Locator {
    return this.page.getByTestId(`error-${fieldName}`);
  }

  async expectToast(message: string | RegExp): Promise<void> {
    await expect(this.toast).toContainText(message);
  }

  /** Wizard-level "Save & Continue" used by every application step. */
  async saveAndContinue(): Promise<void> {
    await this.page.getByRole('button', { name: /save\s*(&|and)\s*continue/i }).click();
  }

  async saveDraft(): Promise<void> {
    await this.page.getByRole('button', { name: /save draft/i }).click();
  }
}
