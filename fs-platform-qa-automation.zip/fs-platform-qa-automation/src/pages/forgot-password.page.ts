import { Locator, Page, expect } from '@playwright/test';
import { BasePage } from './base.page';

/**
 * Password reset flow: request OTP -> enter OTP -> set new password.
 */
export class ForgotPasswordPage extends BasePage {
  readonly emailInput: Locator;
  readonly sendOtpButton: Locator;
  readonly otpInput: Locator;
  readonly verifyOtpButton: Locator;
  readonly newPasswordInput: Locator;
  readonly confirmPasswordInput: Locator;
  readonly resetButton: Locator;

  constructor(page: Page) {
    super(page);
    this.emailInput = page.getByLabel(/email|username/i);
    this.sendOtpButton = page.getByRole('button', { name: /send otp/i });
    this.otpInput = page.getByLabel(/otp|one.time (code|password)/i);
    this.verifyOtpButton = page.getByRole('button', { name: /verify/i });
    this.newPasswordInput = page.getByLabel('New Password', { exact: true });
    this.confirmPasswordInput = page.getByLabel(/confirm( new)? password/i);
    this.resetButton = page.getByRole('button', { name: /reset password/i });
  }

  async goto(): Promise<void> {
    await this.page.goto('/forgot-password');
    await expect(this.sendOtpButton).toBeVisible();
  }

  async requestOtp(email: string): Promise<void> {
    await this.emailInput.fill(email);
    await this.sendOtpButton.click();
  }

  async submitOtp(code: string): Promise<void> {
    await this.otpInput.fill(code);
    await this.verifyOtpButton.click();
  }

  async setNewPassword(password: string): Promise<void> {
    await this.newPasswordInput.fill(password);
    await this.confirmPasswordInput.fill(password);
    await this.resetButton.click();
  }
}
