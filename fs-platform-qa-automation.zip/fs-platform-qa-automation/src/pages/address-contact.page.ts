import { Locator, Page, expect } from '@playwright/test';
import { BasePage } from './base.page';
import { AddressContact } from '../data/application-data';

export class AddressContactPage extends BasePage {
  readonly heading: Locator;
  readonly residentialLine1: Locator;
  readonly residentialCity: Locator;
  readonly residentialState: Locator;
  readonly residentialZip: Locator;
  readonly sameAsResidentialCheckbox: Locator;
  readonly mailingLine1: Locator;
  readonly mailingCity: Locator;
  readonly mailingState: Locator;
  readonly mailingZip: Locator;
  readonly emailInput: Locator;
  readonly phoneInput: Locator;

  constructor(page: Page) {
    super(page);
    this.heading = page.getByRole('heading', { name: /address (&|and) contact/i });

    const residential = page.getByTestId('residential-address');
    this.residentialLine1 = residential.getByLabel(/address line 1/i);
    this.residentialCity = residential.getByLabel(/city/i);
    this.residentialState = residential.getByLabel(/state/i);
    this.residentialZip = residential.getByLabel(/zip/i);

    this.sameAsResidentialCheckbox = page.getByRole('checkbox', {
      name: /same as residential/i,
    });

    const mailing = page.getByTestId('mailing-address');
    this.mailingLine1 = mailing.getByLabel(/address line 1/i);
    this.mailingCity = mailing.getByLabel(/city/i);
    this.mailingState = mailing.getByLabel(/state/i);
    this.mailingZip = mailing.getByLabel(/zip/i);

    this.emailInput = page.getByLabel(/email/i);
    this.phoneInput = page.getByLabel(/phone/i);
  }

  async expectLoaded(): Promise<void> {
    await expect(this.heading).toBeVisible();
  }

  async fillResidential(address: AddressContact): Promise<void> {
    await this.residentialLine1.fill(address.residentialLine1);
    await this.residentialCity.fill(address.residentialCity);
    await this.residentialState.selectOption(address.residentialState);
    await this.residentialZip.fill(address.residentialZip);
  }

  async fillContact(address: AddressContact): Promise<void> {
    await this.emailInput.fill(address.email);
    await this.phoneInput.fill(address.phone);
  }

  async fill(address: AddressContact): Promise<void> {
    await this.fillResidential(address);
    if (address.mailingSameAsResidential) {
      await this.sameAsResidentialCheckbox.check();
    } else {
      await this.sameAsResidentialCheckbox.uncheck();
      await this.mailingLine1.fill(address.mailingLine1 ?? '');
      await this.mailingCity.fill(address.mailingCity ?? '');
      await this.mailingState.selectOption(address.mailingState ?? '');
      await this.mailingZip.fill(address.mailingZip ?? '');
    }
    await this.fillContact(address);
  }

  /** Verifies the mailing block mirrors the residential values entered. */
  async expectMailingCopiedFromResidential(address: AddressContact): Promise<void> {
    await expect(this.mailingLine1).toHaveValue(address.residentialLine1);
    await expect(this.mailingCity).toHaveValue(address.residentialCity);
    await expect(this.mailingState).toHaveValue(address.residentialState);
    await expect(this.mailingZip).toHaveValue(address.residentialZip);
  }
}
