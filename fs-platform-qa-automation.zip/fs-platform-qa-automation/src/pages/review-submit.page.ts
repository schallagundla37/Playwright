import { Locator, Page, expect } from '@playwright/test';
import { BasePage } from './base.page';

export class ReviewSubmitPage extends BasePage {
  readonly heading: Locator;
  readonly submitButton: Locator;
  readonly declarationCheckbox: Locator;
  readonly validationSummary: Locator;
  readonly confirmationBanner: Locator;
  readonly referenceNumber: Locator;

  constructor(page: Page) {
    super(page);
    this.heading = page.getByRole('heading', { name: /review (&|and) submit/i });
    this.submitButton = page.getByRole('button', { name: /^submit( application)?$/i });
    this.declarationCheckbox = page.getByRole('checkbox', { name: /declaration|i confirm/i });
    this.validationSummary = page.getByTestId('validation-summary');
    this.confirmationBanner = page.getByTestId('submission-confirmation');
    this.referenceNumber = page.getByTestId('application-reference');
  }

  async expectLoaded(): Promise<void> {
    await expect(this.heading).toBeVisible();
  }

  /** Named review section (Client Details, Address, Product, ...). */
  section(name: string | RegExp): Locator {
    return this.page.getByTestId('review-section').filter({
      has: this.page.getByRole('heading', { name }),
    });
  }

  async expectSectionContains(name: string | RegExp, value: string | RegExp): Promise<void> {
    await expect(this.section(name)).toContainText(value);
  }

  async acceptDeclarationAndSubmit(): Promise<void> {
    await this.declarationCheckbox.check();
    await this.submitButton.click();
  }

  /** Returns the reference number shown on the confirmation screen. */
  async expectSubmitted(): Promise<string> {
    await expect(this.confirmationBanner).toBeVisible();
    const reference = (await this.referenceNumber.innerText()).trim();
    expect(reference, 'confirmation must show an application reference').not.toBe('');
    return reference;
  }
}
