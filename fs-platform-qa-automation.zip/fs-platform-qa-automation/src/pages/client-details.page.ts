import { Locator, Page, expect } from '@playwright/test';
import { BasePage } from './base.page';
import { ClientDetails } from '../data/application-data';

export class ClientDetailsPage extends BasePage {
  readonly heading: Locator;
  readonly firstNameInput: Locator;
  readonly lastNameInput: Locator;
  readonly dobInput: Locator;
  readonly genderSelect: Locator;
  readonly calculatedAge: Locator;

  constructor(page: Page) {
    super(page);
    this.heading = page.getByRole('heading', { name: /client (details|information)/i });
    this.firstNameInput = page.getByLabel(/first name/i);
    this.lastNameInput = page.getByLabel(/last name/i);
    this.dobInput = page.getByLabel(/date of birth/i);
    this.genderSelect = page.getByLabel(/gender/i);
    this.calculatedAge = page.getByTestId('calculated-age');
  }

  async expectLoaded(): Promise<void> {
    await expect(this.heading).toBeVisible();
  }

  async fill(client: ClientDetails): Promise<void> {
    await this.firstNameInput.fill(client.firstName);
    await this.lastNameInput.fill(client.lastName);
    await this.enterDob(client.dateOfBirth);
    await this.genderSelect.selectOption(client.gender);
  }

  async enterDob(dateOfBirth: string): Promise<void> {
    await this.dobInput.fill(dateOfBirth);
    // Blur so the app runs its DOB/age handlers, as a real user tabbing away would.
    await this.dobInput.blur();
  }

  async expectCalculatedAge(expectedYears: number): Promise<void> {
    await expect(this.calculatedAge).toBeVisible();
    await expect(this.calculatedAge).toContainText(String(expectedYears));
  }
}
