import { Locator, Page, expect } from '@playwright/test';
import { BasePage } from './base.page';

export class DocumentsPage extends BasePage {
  readonly heading: Locator;
  readonly idProofInput: Locator;
  readonly addressProofInput: Locator;
  readonly uploadedList: Locator;

  constructor(page: Page) {
    super(page);
    this.heading = page.getByRole('heading', { name: /documents/i });
    this.idProofInput = page.getByLabel(/id proof/i);
    this.addressProofInput = page.getByLabel(/address proof/i);
    this.uploadedList = page.getByTestId('uploaded-documents');
  }

  async expectLoaded(): Promise<void> {
    await expect(this.heading).toBeVisible();
  }

  async uploadIdProof(filePath: string): Promise<void> {
    await this.idProofInput.setInputFiles(filePath);
  }

  async uploadAddressProof(filePath: string): Promise<void> {
    await this.addressProofInput.setInputFiles(filePath);
  }

  async expectUploaded(fileName: string): Promise<void> {
    await expect(this.uploadedList).toContainText(fileName);
  }
}
