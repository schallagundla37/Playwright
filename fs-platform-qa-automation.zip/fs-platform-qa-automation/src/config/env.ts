import * as dotenv from 'dotenv';
import * as path from 'path';

dotenv.config({ path: path.resolve(__dirname, '../../.env') });

/**
 * Central, typed access to every environment value the suite needs.
 * Test logic must never read process.env directly — always go through `env`.
 *
 * Credentials are exposed through lazy getters so that `playwright test --list`
 * and `tsc --noEmit` work without a .env, but any test that actually needs a
 * value fails immediately with a clear message instead of a vague locator
 * timeout deep inside the run.
 */
function required(name: string): string {
  const value = process.env[name];
  if (!value) {
    throw new Error(
      `Missing required environment variable "${name}". ` +
        `Copy .env.example to .env and fill in the values from the Environment and Credentials sheet.`,
    );
  }
  return value;
}

function optional(name: string, fallback: string): string {
  return process.env[name] ?? fallback;
}

export interface SeedUser {
  readonly email: string;
  readonly password: string;
}

function seedUser(emailVar: string, passwordVar: string): SeedUser {
  return {
    get email() {
      return required(emailVar);
    },
    get password() {
      return required(passwordVar);
    },
  };
}

export const env = {
  /** Placeholder default keeps --list/typecheck usable before .env exists. */
  baseUrl: optional('BASE_URL', 'https://qa-fs-platform.example.com'),

  users: {
    /** Fully onboarded customer — primary happy-path account. */
    valid: seedUser('VALID_USER_EMAIL', 'VALID_USER_PASSWORD'),
    /** Registered customer with no holdings/applications — empty-state checks. */
    newCustomer: seedUser('NEW_USER_EMAIL', 'NEW_USER_PASSWORD'),
    /** Locked account — negative authentication checks. */
    locked: seedUser('LOCKED_USER_EMAIL', 'LOCKED_USER_PASSWORD'),
  },

  get resetOtpCode() {
    return optional('RESET_OTP_CODE', '123456');
  },

  /**
   * When true, seeded-defect specs assert the defect is observable (the build
   * under test intentionally contains it). When false, the same specs assert
   * the correct behavior, doubling as regression tests after the fix.
   */
  seededDefectBuild: optional('SEEDED_DEFECT_BUILD', 'false').toLowerCase() === 'true',

  headless: optional('HEADLESS', 'true').toLowerCase() === 'true',
  browsers: optional('BROWSERS', 'chromium')
    .split(',')
    .map((b) => b.trim())
    .filter(Boolean),
  defaultTimeoutMs: Number(optional('DEFAULT_TIMEOUT_MS', '30000')),
} as const;
