/**
 * Seeded Defect Catalog mapping.
 *
 * NOTE: The official catalog document was not yet shared at the time of
 * writing (see README "Known limitations"). The IDs below are provisional,
 * derived from the defect areas named in the problem statement and the
 * Assignment 2 test-design scope. When the catalog arrives, update the `id`
 * values here — every spec references defects through this single map, so
 * nothing else needs to change.
 */
export const seededDefects = {
  SD_AUTH_01: {
    id: 'SD-AUTH-01',
    summary: 'Locked user is able to log in and reach the dashboard',
  },
  SD_AUTH_02: {
    id: 'SD-AUTH-02',
    summary: 'Password reset accepts reuse of the same (old) password',
  },
  SD_CLIENT_01: {
    id: 'SD-CLIENT-01',
    summary: 'Calculated age not displayed / incorrect after entering date of birth',
  },
  SD_ADDR_01: {
    id: 'SD-ADDR-01',
    summary: '"Same as residential" does not copy residential address into mailing address',
  },
  SD_ADDR_02: {
    id: 'SD-ADDR-02',
    summary: 'Invalid ZIP code accepted without a validation error',
  },
  SD_PROD_01: {
    id: 'SD-PROD-01',
    summary: 'Premium does not recalculate when premium frequency changes',
  },
  SD_PROD_02: {
    id: 'SD-PROD-02',
    summary: 'Inactive product can be selected and configured',
  },
  SD_PROD_03: {
    id: 'SD-PROD-03',
    summary: 'Sum assured outside min/max limits accepted',
  },
  SD_BENE_01: {
    id: 'SD-BENE-01',
    summary: 'Beneficiary allocation not totalling 100% accepted',
  },
  SD_REVIEW_01: {
    id: 'SD-REVIEW-01',
    summary: 'Submit enabled while mandatory sections are incomplete',
  },
} as const;

export type SeededDefect = (typeof seededDefects)[keyof typeof seededDefects];
