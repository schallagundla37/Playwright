/**
 * Controlled test data for the insurance application journey.
 * Builders return fresh objects so a test can safely mutate its copy,
 * and invalid variants are derived from the valid baseline so the two
 * never drift apart.
 */

export interface ClientDetails {
  firstName: string;
  lastName: string;
  dateOfBirth: string; // YYYY-MM-DD
  gender: 'Male' | 'Female' | 'Other';
}

export interface AddressContact {
  residentialLine1: string;
  residentialCity: string;
  residentialState: string;
  residentialZip: string;
  mailingSameAsResidential: boolean;
  mailingLine1?: string;
  mailingCity?: string;
  mailingState?: string;
  mailingZip?: string;
  email: string;
  phone: string;
}

export interface ProductSelection {
  productName: string;
  sumAssured: number;
  premiumFrequency: 'Monthly' | 'Quarterly' | 'Half-Yearly' | 'Yearly';
}

export interface Beneficiary {
  name: string;
  relationship: string;
  allocationPercent: number;
}

export function validClient(overrides: Partial<ClientDetails> = {}): ClientDetails {
  return {
    firstName: 'Arjun',
    lastName: 'Mehta',
    dateOfBirth: '1990-05-15',
    gender: 'Male',
    ...overrides,
  };
}

export function validAddress(overrides: Partial<AddressContact> = {}): AddressContact {
  return {
    residentialLine1: '221 Lakeview Street',
    residentialCity: 'Springfield',
    residentialState: 'MA',
    residentialZip: '01103',
    mailingSameAsResidential: true,
    email: 'arjun.mehta@example.com',
    phone: '4135551234',
    ...overrides,
  };
}

export function validProduct(overrides: Partial<ProductSelection> = {}): ProductSelection {
  return {
    productName: 'Term Life Protect',
    sumAssured: 500_000,
    premiumFrequency: 'Yearly',
    ...overrides,
  };
}

export function validBeneficiaries(): Beneficiary[] {
  return [
    { name: 'Priya Mehta', relationship: 'Spouse', allocationPercent: 60 },
    { name: 'Rohan Mehta', relationship: 'Child', allocationPercent: 40 },
  ];
}

/** Product boundary values — confirm exact limits against Tech Handover. */
export const productLimits = {
  sumAssuredMin: 100_000,
  sumAssuredMax: 10_000_000,
};

/** A product flagged inactive in seed data; must not be purchasable. */
export const inactiveProductName = 'Legacy Endowment Plan';

export const invalidInputs = {
  zipTooShort: '011',
  zipNonNumeric: 'ABCDE',
  emailMissingAt: 'arjun.mehta.example.com',
  emailMissingDomain: 'arjun@',
  phoneTooShort: '4135',
  phoneAlpha: '41355ABCDE',
  nameWithDigits: 'Arjun99',
  futureDob: '2032-01-01',
  minorDob: () => {
    // A DOB exactly 17 years ago — always under the standard 18+ age rule.
    const d = new Date();
    d.setFullYear(d.getFullYear() - 17);
    return d.toISOString().slice(0, 10);
  },
};
