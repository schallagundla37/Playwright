import { test, expect } from '../../src/fixtures/test-fixtures';
import { env } from '../../src/config/env';
import { validBeneficiaries } from '../../src/data/application-data';
import { seededDefects } from '../../src/data/seeded-defects';
import { trace } from '../../src/utils/traceability';

/**
 * Module: Riders / Beneficiaries
 * Coverage: eligibility, allocation totals, required fields, review consistency.
 */
test.describe(
  'Riders & Beneficiaries',
  { tag: ['@riders-beneficiaries', '@regression'] },
  () => {
    test.beforeEach(async ({ journey }) => {
      await journey.toRidersBeneficiaries();
    });

    test('TC-BENE-001: beneficiary allocations totalling 100% are accepted', async ({
      ridersBeneficiariesPage,
      documentsPage,
    }) => {
      trace(test.info(), { testCaseId: 'TC-BENE-001', risk: 'BENE-R1 allocation totals' });

      await ridersBeneficiariesPage.addBeneficiaries(validBeneficiaries());
      await ridersBeneficiariesPage.expectAllocationTotal(100);
      await ridersBeneficiariesPage.saveAndContinue();
      await documentsPage.expectLoaded();
    });

    test(
      'TC-BENE-002: allocation total below 100% blocks progression',
      { tag: '@seeded-defect' },
      async ({ ridersBeneficiariesPage }) => {
        trace(test.info(), {
          testCaseId: 'TC-BENE-002',
          risk: 'BENE-R1 allocation totals',
          defect: seededDefects.SD_BENE_01,
        });
        test.fail(env.seededDefectBuild, seededDefects.SD_BENE_01.id);

        await ridersBeneficiariesPage.addBeneficiary(0, {
          name: 'Priya Mehta',
          relationship: 'Spouse',
          allocationPercent: 60,
        });
        await ridersBeneficiariesPage.saveAndContinue();
        await expect(ridersBeneficiariesPage.fieldError('allocation-total')).toContainText(
          /100/,
        );
        // Must remain on the step.
        await expect(ridersBeneficiariesPage.heading).toBeVisible();
      },
    );

    test('TC-BENE-003: allocation total above 100% is rejected', async ({
      ridersBeneficiariesPage,
    }) => {
      trace(test.info(), { testCaseId: 'TC-BENE-003', risk: 'BENE-R1 allocation totals' });

      await ridersBeneficiariesPage.addBeneficiary(0, {
        name: 'Priya Mehta',
        relationship: 'Spouse',
        allocationPercent: 80,
      });
      await ridersBeneficiariesPage.addBeneficiary(1, {
        name: 'Rohan Mehta',
        relationship: 'Child',
        allocationPercent: 40,
      });
      await ridersBeneficiariesPage.saveAndContinue();
      await expect(ridersBeneficiariesPage.fieldError('allocation-total')).toContainText(/100/);
    });

    test('TC-BENE-004: beneficiary with missing mandatory fields is rejected', async ({
      ridersBeneficiariesPage,
    }) => {
      trace(test.info(), { testCaseId: 'TC-BENE-004', risk: 'BENE-R2 required fields' });

      await ridersBeneficiariesPage.addBeneficiaryButton.click();
      await ridersBeneficiariesPage.saveAndContinue();
      await expect(ridersBeneficiariesPage.fieldError('beneficiary-name')).toBeVisible();
    });

    test('TC-RIDER-001: selecting a rider increases the total premium shown on review', async ({
      ridersBeneficiariesPage,
      documentsPage,
      page,
    }) => {
      trace(test.info(), { testCaseId: 'TC-RIDER-001', risk: 'RIDER-R1 rider pricing' });

      await ridersBeneficiariesPage.selectRider('Accidental Death Benefit');
      await ridersBeneficiariesPage.addBeneficiaries(validBeneficiaries());
      await ridersBeneficiariesPage.saveAndContinue();
      await documentsPage.expectLoaded();
      // Rider premium reconciliation against review totals is asserted in
      // TC-REV-001 (review consistency); here we assert the rider persisted.
      await page.goBack();
      await ridersBeneficiariesPage.expectLoaded();
      await expect(
        ridersBeneficiariesPage.riderCheckbox('Accidental Death Benefit'),
      ).toBeChecked();
    });
  },
);
