import { test, expect } from '../../src/fixtures/test-fixtures';
import { env } from '../../src/config/env';
import { invalidInputs, validAddress } from '../../src/data/application-data';
import { seededDefects } from '../../src/data/seeded-defects';
import { trace } from '../../src/utils/traceability';

/**
 * Module: Address and Contact
 * Coverage: same-as-residential behavior, state validation, ZIP validation,
 *           email and phone validation.
 */
test.describe('Address & Contact', { tag: ['@address-contact', '@regression'] }, () => {
  test.beforeEach(async ({ journey }) => {
    await journey.toAddressContact();
  });

  test(
    'TC-ADDR-001: "same as residential" copies the residential address into mailing',
    { tag: '@seeded-defect' },
    async ({ addressContactPage }) => {
      trace(test.info(), {
        testCaseId: 'TC-ADDR-001',
        risk: 'ADDR-R1 same-as-residential',
        defect: seededDefects.SD_ADDR_01,
      });
      test.fail(env.seededDefectBuild, seededDefects.SD_ADDR_01.id);

      const address = validAddress();
      await addressContactPage.fillResidential(address);
      await addressContactPage.sameAsResidentialCheckbox.check();
      await addressContactPage.expectMailingCopiedFromResidential(address);
    },
  );

  test('TC-ADDR-002: unchecking "same as residential" clears and re-enables mailing fields', async ({
    addressContactPage,
  }) => {
    trace(test.info(), { testCaseId: 'TC-ADDR-002', risk: 'ADDR-R1 same-as-residential' });

    await addressContactPage.fillResidential(validAddress());
    await addressContactPage.sameAsResidentialCheckbox.check();
    await addressContactPage.sameAsResidentialCheckbox.uncheck();
    await expect(addressContactPage.mailingLine1).toBeEditable();
    await expect(addressContactPage.mailingLine1).toHaveValue('');
  });

  test(
    'TC-ADDR-003: ZIP code shorter than required length is rejected',
    { tag: '@seeded-defect' },
    async ({ addressContactPage }) => {
      trace(test.info(), {
        testCaseId: 'TC-ADDR-003',
        risk: 'ADDR-R2 ZIP validation',
        defect: seededDefects.SD_ADDR_02,
      });
      test.fail(env.seededDefectBuild, seededDefects.SD_ADDR_02.id);

      await addressContactPage.fill(
        validAddress({ residentialZip: invalidInputs.zipTooShort }),
      );
      await addressContactPage.saveAndContinue();
      await expect(addressContactPage.fieldError('residential-zip')).toContainText(
        /invalid|5 digits|zip/i,
      );
    },
  );

  test('TC-ADDR-004: non-numeric ZIP code is rejected', async ({ addressContactPage }) => {
    trace(test.info(), { testCaseId: 'TC-ADDR-004', risk: 'ADDR-R2 ZIP validation' });

    await addressContactPage.fill(
      validAddress({ residentialZip: invalidInputs.zipNonNumeric }),
    );
    await addressContactPage.saveAndContinue();
    await expect(addressContactPage.fieldError('residential-zip')).toBeVisible();
  });

  test('TC-ADDR-005: email without @ is rejected', async ({ addressContactPage }) => {
    trace(test.info(), { testCaseId: 'TC-ADDR-005', risk: 'ADDR-R3 email validation' });

    await addressContactPage.fill(validAddress({ email: invalidInputs.emailMissingAt }));
    await addressContactPage.saveAndContinue();
    await expect(addressContactPage.fieldError('email')).toContainText(/valid email/i);
  });

  test('TC-ADDR-006: email without domain is rejected', async ({ addressContactPage }) => {
    trace(test.info(), { testCaseId: 'TC-ADDR-006', risk: 'ADDR-R3 email validation' });

    await addressContactPage.fill(validAddress({ email: invalidInputs.emailMissingDomain }));
    await addressContactPage.saveAndContinue();
    await expect(addressContactPage.fieldError('email')).toContainText(/valid email/i);
  });

  test('TC-ADDR-007: phone number that is too short is rejected', async ({
    addressContactPage,
  }) => {
    trace(test.info(), { testCaseId: 'TC-ADDR-007', risk: 'ADDR-R4 phone validation' });

    await addressContactPage.fill(validAddress({ phone: invalidInputs.phoneTooShort }));
    await addressContactPage.saveAndContinue();
    await expect(addressContactPage.fieldError('phone')).toContainText(/10 digits|invalid/i);
  });

  test('TC-ADDR-008: alphabetic characters in phone are rejected', async ({
    addressContactPage,
  }) => {
    trace(test.info(), { testCaseId: 'TC-ADDR-008', risk: 'ADDR-R4 phone validation' });

    await addressContactPage.fill(validAddress({ phone: invalidInputs.phoneAlpha }));
    await addressContactPage.saveAndContinue();
    await expect(addressContactPage.fieldError('phone')).toBeVisible();
  });

  test(
    'TC-ADDR-009: valid address and contact save and progress to Product Configuration',
    { tag: '@smoke' },
    async ({ addressContactPage, productConfigPage }) => {
      trace(test.info(), { testCaseId: 'TC-ADDR-009', risk: 'ADDR-R5 workflow progression' });

      await addressContactPage.fill(validAddress());
      await addressContactPage.saveAndContinue();
      await productConfigPage.expectLoaded();
    },
  );
});
