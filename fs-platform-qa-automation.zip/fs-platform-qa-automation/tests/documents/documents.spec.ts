import * as path from 'path';
import { test, expect } from '../../src/fixtures/test-fixtures';
import { trace } from '../../src/utils/traceability';

const SAMPLE_DOC = path.resolve(__dirname, '../../test-assets/sample-id-proof.pdf');

/**
 * Module: Documents
 * Coverage: required uploads, upload confirmation, progression gating.
 */
test.describe('Documents', { tag: ['@documents', '@regression'] }, () => {
  test.beforeEach(async ({ journey }) => {
    await journey.toDocuments();
  });

  test('TC-DOC-001: progressing without mandatory documents is blocked', async ({
    documentsPage,
  }) => {
    trace(test.info(), { testCaseId: 'TC-DOC-001', risk: 'DOC-R1 mandatory documents' });

    await documentsPage.saveAndContinue();
    await expect(documentsPage.fieldError('id-proof')).toBeVisible();
    await expect(documentsPage.heading).toBeVisible();
  });

  test('TC-DOC-002: uploaded document appears in the uploaded list', async ({
    documentsPage,
  }) => {
    trace(test.info(), { testCaseId: 'TC-DOC-002', risk: 'DOC-R2 upload handling' });

    await documentsPage.uploadIdProof(SAMPLE_DOC);
    await documentsPage.expectUploaded('sample-id-proof.pdf');
  });

  test('TC-DOC-003: with all documents uploaded the journey reaches Review & Submit', async ({
    documentsPage,
    reviewSubmitPage,
  }) => {
    trace(test.info(), { testCaseId: 'TC-DOC-003', risk: 'DOC-R3 workflow progression' });

    await documentsPage.uploadIdProof(SAMPLE_DOC);
    await documentsPage.uploadAddressProof(SAMPLE_DOC);
    await documentsPage.saveAndContinue();
    await reviewSubmitPage.expectLoaded();
  });
});
