import { test, expect } from '../../src/fixtures/test-fixtures';
import { env } from '../../src/config/env';
import {
  inactiveProductName,
  productLimits,
  validProduct,
} from '../../src/data/application-data';
import { seededDefects } from '../../src/data/seeded-defects';
import { trace } from '../../src/utils/traceability';

/**
 * Module: Product Configuration
 * Coverage: product selection, sum assured min/max boundaries, premium
 *           frequency, premium recalculation, inactive products, persistence.
 */
test.describe('Product Configuration', { tag: ['@product-config', '@regression'] }, () => {
  test.beforeEach(async ({ journey }) => {
    await journey.toProductConfig();
  });

  test('TC-PROD-001: selecting a product shows a calculated premium', async ({
    productConfigPage,
  }) => {
    trace(test.info(), { testCaseId: 'TC-PROD-001', risk: 'PROD-R1 premium calculation' });

    await productConfigPage.configure(validProduct());
    const premium = await productConfigPage.premiumValue();
    expect(premium).toBeGreaterThan(0);
  });

  test(
    'TC-PROD-002: premium recalculates when premium frequency changes',
    { tag: '@seeded-defect' },
    async ({ productConfigPage }) => {
      trace(test.info(), {
        testCaseId: 'TC-PROD-002',
        risk: 'PROD-R1 premium calculation',
        defect: seededDefects.SD_PROD_01,
      });
      test.fail(env.seededDefectBuild, seededDefects.SD_PROD_01.id);

      await productConfigPage.configure(validProduct({ premiumFrequency: 'Yearly' }));
      const yearlyPremium = await productConfigPage.premiumValue();

      await productConfigPage.premiumFrequencySelect.selectOption('Monthly');
      await expect
        .poll(() => productConfigPage.premiumValue(), {
          message: 'premium should change after switching frequency Yearly -> Monthly',
        })
        .not.toBe(yearlyPremium);

      // A monthly installment must be smaller than the full yearly premium.
      const monthlyPremium = await productConfigPage.premiumValue();
      expect(monthlyPremium).toBeLessThan(yearlyPremium);
    },
  );

  test('TC-PROD-003: premium recalculates when sum assured changes', async ({
    productConfigPage,
  }) => {
    trace(test.info(), { testCaseId: 'TC-PROD-003', risk: 'PROD-R1 premium calculation' });

    await productConfigPage.configure(validProduct({ sumAssured: 500_000 }));
    const premiumAt500k = await productConfigPage.premiumValue();

    await productConfigPage.setSumAssured(1_000_000);
    await expect
      .poll(() => productConfigPage.premiumValue(), {
        message: 'premium should increase after doubling sum assured',
      })
      .toBeGreaterThan(premiumAt500k);
  });

  test(
    'TC-PROD-004: sum assured below the minimum is rejected',
    { tag: '@seeded-defect' },
    async ({ productConfigPage }) => {
      trace(test.info(), {
        testCaseId: 'TC-PROD-004',
        risk: 'PROD-R2 sum assured limits',
        defect: seededDefects.SD_PROD_03,
      });
      test.fail(env.seededDefectBuild, seededDefects.SD_PROD_03.id);

      await productConfigPage.configure(
        validProduct({ sumAssured: productLimits.sumAssuredMin - 1 }),
      );
      await productConfigPage.saveAndContinue();
      await expect(productConfigPage.fieldError('sum-assured')).toContainText(
        /minimum|at least/i,
      );
    },
  );

  test('TC-PROD-005: sum assured above the maximum is rejected', async ({
    productConfigPage,
  }) => {
    trace(test.info(), { testCaseId: 'TC-PROD-005', risk: 'PROD-R2 sum assured limits' });

    await productConfigPage.configure(
      validProduct({ sumAssured: productLimits.sumAssuredMax + 1 }),
    );
    await productConfigPage.saveAndContinue();
    await expect(productConfigPage.fieldError('sum-assured')).toContainText(/maximum|exceed/i);
  });

  test('TC-PROD-006: sum assured exactly at the minimum and maximum is accepted', async ({
    productConfigPage,
  }) => {
    trace(test.info(), { testCaseId: 'TC-PROD-006', risk: 'PROD-R2 sum assured limits' });

    await productConfigPage.configure(validProduct({ sumAssured: productLimits.sumAssuredMin }));
    await expect(productConfigPage.fieldError('sum-assured')).toBeHidden();

    await productConfigPage.setSumAssured(productLimits.sumAssuredMax);
    await expect(productConfigPage.fieldError('sum-assured')).toBeHidden();
  });

  test(
    'TC-PROD-007: inactive product cannot be selected',
    { tag: '@seeded-defect' },
    async ({ productConfigPage }) => {
      trace(test.info(), {
        testCaseId: 'TC-PROD-007',
        risk: 'PROD-R3 inactive products',
        defect: seededDefects.SD_PROD_02,
      });
      test.fail(env.seededDefectBuild, seededDefects.SD_PROD_02.id);

      expect(
        await productConfigPage.isProductSelectable(inactiveProductName),
        `inactive product "${inactiveProductName}" must not be selectable`,
      ).toBe(false);
    },
  );

  test('TC-PROD-008: saved configuration persists after leaving and returning to the step', async ({
    productConfigPage,
    ridersBeneficiariesPage,
    page,
  }) => {
    trace(test.info(), { testCaseId: 'TC-PROD-008', risk: 'PROD-R4 persistence' });

    const product = validProduct();
    await productConfigPage.configure(product);
    await productConfigPage.saveAndContinue();
    await ridersBeneficiariesPage.expectLoaded();

    // Navigate back to the step; every saved value must be re-rendered.
    await page.goBack();
    await productConfigPage.expectLoaded();
    await expect(productConfigPage.sumAssuredInput).toHaveValue(String(product.sumAssured));
    await expect(productConfigPage.premiumFrequencySelect).toHaveValue(product.premiumFrequency);
  });
});
