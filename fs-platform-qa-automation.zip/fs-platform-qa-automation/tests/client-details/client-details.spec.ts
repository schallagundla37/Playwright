import { test, expect } from '../../src/fixtures/test-fixtures';
import { env } from '../../src/config/env';
import { invalidInputs, validClient } from '../../src/data/application-data';
import { seededDefects } from '../../src/data/seeded-defects';
import { ageFromDob } from '../../src/utils/date-utils';
import { trace } from '../../src/utils/traceability';

/**
 * Module: Client Details
 * Coverage: required fields, DOB rules, calculated age display,
 *           name validation, save and workflow progression.
 */
test.describe('Client Details', { tag: ['@client-details', '@regression'] }, () => {
  test.beforeEach(async ({ journey }) => {
    await journey.toClientDetails();
  });

  test('TC-CLI-001: all mandatory fields flag errors when left empty', async ({
    clientDetailsPage,
  }) => {
    trace(test.info(), { testCaseId: 'TC-CLI-001', risk: 'CLI-R1 mandatory validation' });

    await clientDetailsPage.saveAndContinue();
    await expect(clientDetailsPage.fieldError('first-name')).toBeVisible();
    await expect(clientDetailsPage.fieldError('last-name')).toBeVisible();
    await expect(clientDetailsPage.fieldError('date-of-birth')).toBeVisible();
    // Still on the same step — invalid data must not progress the workflow.
    await expect(clientDetailsPage.heading).toBeVisible();
  });

  test(
    'TC-CLI-002: calculated age displays correctly after entering DOB',
    { tag: '@seeded-defect' },
    async ({ clientDetailsPage }) => {
      trace(test.info(), {
        testCaseId: 'TC-CLI-002',
        risk: 'CLI-R2 age calculation',
        defect: seededDefects.SD_CLIENT_01,
      });
      test.fail(env.seededDefectBuild, seededDefects.SD_CLIENT_01.id);

      const client = validClient();
      await clientDetailsPage.enterDob(client.dateOfBirth);
      await clientDetailsPage.expectCalculatedAge(ageFromDob(client.dateOfBirth));
    },
  );

  test('TC-CLI-003: future date of birth is rejected', async ({ clientDetailsPage }) => {
    trace(test.info(), { testCaseId: 'TC-CLI-003', risk: 'CLI-R3 DOB rules' });

    await clientDetailsPage.enterDob(invalidInputs.futureDob);
    await expect(clientDetailsPage.fieldError('date-of-birth')).toContainText(
      /future|invalid date/i,
    );
  });

  test('TC-CLI-004: applicant under minimum age is rejected', async ({ clientDetailsPage }) => {
    trace(test.info(), { testCaseId: 'TC-CLI-004', risk: 'CLI-R3 DOB rules' });

    await clientDetailsPage.fill(validClient({ dateOfBirth: invalidInputs.minorDob() }));
    await clientDetailsPage.saveAndContinue();
    await expect(clientDetailsPage.fieldError('date-of-birth')).toContainText(
      /minimum age|18|not eligible/i,
    );
  });

  test('TC-CLI-005: numeric characters in name are rejected', async ({ clientDetailsPage }) => {
    trace(test.info(), { testCaseId: 'TC-CLI-005', risk: 'CLI-R4 name validation' });

    await clientDetailsPage.fill(validClient({ firstName: invalidInputs.nameWithDigits }));
    await clientDetailsPage.saveAndContinue();
    await expect(clientDetailsPage.fieldError('first-name')).toContainText(
      /letters|invalid|alphabetic/i,
    );
  });

  test(
    'TC-CLI-006: valid details save and progress to Address & Contact',
    { tag: '@smoke' },
    async ({ clientDetailsPage, addressContactPage }) => {
      trace(test.info(), { testCaseId: 'TC-CLI-006', risk: 'CLI-R5 workflow progression' });

      await clientDetailsPage.fill(validClient());
      await clientDetailsPage.saveAndContinue();
      await addressContactPage.expectLoaded();
    },
  );
});
