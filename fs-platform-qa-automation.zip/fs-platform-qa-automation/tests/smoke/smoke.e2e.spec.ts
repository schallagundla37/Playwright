import * as path from 'path';
import { test } from '../../src/fixtures/test-fixtures';
import { validClient, validProduct } from '../../src/data/application-data';
import { trace } from '../../src/utils/traceability';

const SAMPLE_DOC = path.resolve(__dirname, '../../test-assets/sample-id-proof.pdf');

/**
 * The end-to-end smoke path required by the Assignment 2 build sequence:
 * login -> start application -> complete every wizard step -> review ->
 * submit -> verify status on the dashboard.
 */
test.describe('Smoke — full application journey', { tag: ['@smoke', '@e2e'] }, () => {
  test('TC-E2E-001: customer completes and submits an insurance application', async ({
    journey,
    reviewSubmitPage,
    dashboardPage,
    page,
  }) => {
    trace(test.info(), {
      testCaseId: 'TC-E2E-001',
      risk: 'E2E-R1 core purchase journey broken',
    });

    const client = validClient();
    const product = validProduct();

    await journey.toReview(SAMPLE_DOC);

    // Review must faithfully echo what was entered on earlier steps.
    await reviewSubmitPage.expectSectionContains(/client/i, client.firstName);
    await reviewSubmitPage.expectSectionContains(/client/i, client.lastName);
    await reviewSubmitPage.expectSectionContains(/product/i, product.productName);
    await reviewSubmitPage.expectSectionContains(
      /product/i,
      new RegExp(product.sumAssured.toLocaleString('en-US').replace(/,/g, '[,.]?')),
    );

    await reviewSubmitPage.acceptDeclarationAndSubmit();
    const reference = await reviewSubmitPage.expectSubmitted();

    // The dashboard must reflect the new application and its status.
    await page.goto('/dashboard');
    await dashboardPage.expectLoaded();
    await dashboardPage.expectApplicationStatus(reference, /submitted|under review/i);
  });
});
