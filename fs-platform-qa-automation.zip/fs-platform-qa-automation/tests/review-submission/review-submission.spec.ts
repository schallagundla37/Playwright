import * as path from 'path';
import { test, expect } from '../../src/fixtures/test-fixtures';
import { env } from '../../src/config/env';
import { validAddress, validClient, validProduct } from '../../src/data/application-data';
import { seededDefects } from '../../src/data/seeded-defects';
import { trace } from '../../src/utils/traceability';

const SAMPLE_DOC = path.resolve(__dirname, '../../test-assets/sample-id-proof.pdf');

/**
 * Module: Review and Submission
 * Coverage: review consistency with entered data, submit gating,
 *           post-submission status updates.
 */
test.describe('Review & Submission', { tag: ['@review-submission', '@regression'] }, () => {
  test('TC-REV-001: review page echoes every value entered across the wizard', async ({
    journey,
    reviewSubmitPage,
  }) => {
    trace(test.info(), { testCaseId: 'TC-REV-001', risk: 'REV-R1 review consistency' });

    const client = validClient();
    const address = validAddress();
    const product = validProduct();

    await journey.toReview(SAMPLE_DOC);

    await reviewSubmitPage.expectSectionContains(/client/i, `${client.firstName} ${client.lastName}`);
    await reviewSubmitPage.expectSectionContains(/address/i, address.residentialLine1);
    await reviewSubmitPage.expectSectionContains(/address/i, address.residentialZip);
    await reviewSubmitPage.expectSectionContains(/contact|address/i, address.email);
    await reviewSubmitPage.expectSectionContains(/product/i, product.productName);
    await reviewSubmitPage.expectSectionContains(/product/i, product.premiumFrequency);
  });

  test('TC-REV-002: submit stays disabled until the declaration is accepted', async ({
    journey,
    reviewSubmitPage,
  }) => {
    trace(test.info(), { testCaseId: 'TC-REV-002', risk: 'REV-R2 submit gating' });

    await journey.toReview(SAMPLE_DOC);
    await expect(reviewSubmitPage.submitButton).toBeDisabled();
    await reviewSubmitPage.declarationCheckbox.check();
    await expect(reviewSubmitPage.submitButton).toBeEnabled();
  });

  test(
    'TC-REV-003: direct navigation to review with incomplete sections cannot submit',
    { tag: '@seeded-defect' },
    async ({ journey, page, reviewSubmitPage }) => {
      trace(test.info(), {
        testCaseId: 'TC-REV-003',
        risk: 'REV-R2 submit gating',
        defect: seededDefects.SD_REVIEW_01,
      });
      test.fail(env.seededDefectBuild, seededDefects.SD_REVIEW_01.id);

      // Complete only the first step, then deep-link to the review route.
      await journey.toAddressContact();
      await page.goto('/application/review');
      await reviewSubmitPage.expectLoaded();

      await expect(reviewSubmitPage.validationSummary).toContainText(/incomplete|required/i);
      await expect(reviewSubmitPage.submitButton).toBeDisabled();
    },
  );

  test(
    'TC-REV-004: successful submission shows a reference and updates dashboard status',
    { tag: '@smoke' },
    async ({ journey, reviewSubmitPage, dashboardPage, page }) => {
      trace(test.info(), { testCaseId: 'TC-REV-004', risk: 'REV-R3 status updates' });

      await journey.toReview(SAMPLE_DOC);
      await reviewSubmitPage.acceptDeclarationAndSubmit();
      const reference = await reviewSubmitPage.expectSubmitted();

      await page.goto('/dashboard');
      await dashboardPage.expectLoaded();
      await dashboardPage.expectApplicationStatus(reference, /submitted|under review/i);
    },
  );
});
