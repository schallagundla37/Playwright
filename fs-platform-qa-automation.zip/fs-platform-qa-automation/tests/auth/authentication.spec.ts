import { test, expect } from '../../src/fixtures/test-fixtures';
import { env } from '../../src/config/env';
import { seededDefects } from '../../src/data/seeded-defects';
import { trace } from '../../src/utils/traceability';

/**
 * Module: Authentication
 * Coverage: valid login, invalid login, locked user, password policy,
 *           OTP reset, same-password reuse, logout/session invalidation.
 * Traceable to Submission 1 risk: "Valid users unable to log in after auth
 * changes; weak lockout/session handling."
 */
test.describe('Authentication', { tag: ['@auth', '@regression'] }, () => {
  test(
    'TC-AUTH-001: valid customer can log in and reach the dashboard',
    { tag: '@smoke' },
    async ({ loginPage, dashboardPage }) => {
      trace(test.info(), { testCaseId: 'TC-AUTH-001', risk: 'AUTH-R1 login blocked' });

      await loginPage.goto();
      await loginPage.login(env.users.valid);
      await dashboardPage.expectLoaded();
    },
  );

  test('TC-AUTH-002: invalid password is rejected with a clear error', async ({ loginPage }) => {
    trace(test.info(), { testCaseId: 'TC-AUTH-002', risk: 'AUTH-R2 invalid-login handling' });

    await loginPage.goto();
    await loginPage.login({ email: env.users.valid.email, password: 'WrongPass123!' });
    await loginPage.expectLoginRejected(/invalid (credentials|email or password)/i);
  });

  test('TC-AUTH-003: unregistered email is rejected without revealing account existence', async ({
    loginPage,
  }) => {
    trace(test.info(), { testCaseId: 'TC-AUTH-003', risk: 'AUTH-R2 invalid-login handling' });

    await loginPage.goto();
    await loginPage.login({ email: 'no.such.user@example.com', password: 'Whatever123!' });
    // Same generic message as a wrong password — no user-enumeration hint.
    await loginPage.expectLoginRejected(/invalid (credentials|email or password)/i);
  });

  test(
    'TC-AUTH-004: locked user cannot log in',
    { tag: '@seeded-defect' },
    async ({ loginPage }) => {
      trace(test.info(), {
        testCaseId: 'TC-AUTH-004',
        risk: 'AUTH-R3 lockout handling',
        defect: seededDefects.SD_AUTH_01,
      });
      // On the seeded build this test is EXPECTED to fail — the failure (with
      // trace + screenshot) is the detection evidence for SD-AUTH-01.
      test.fail(env.seededDefectBuild, seededDefects.SD_AUTH_01.id);

      await loginPage.goto();
      await loginPage.login(env.users.locked);
      await loginPage.expectLoginRejected(/locked|suspended/i);
    },
  );

  test('TC-AUTH-005: password reset rejects a password that violates policy', async ({
    forgotPasswordPage,
  }) => {
    trace(test.info(), { testCaseId: 'TC-AUTH-005', risk: 'AUTH-R4 weak password policy' });

    await forgotPasswordPage.goto();
    await forgotPasswordPage.requestOtp(env.users.valid.email);
    await forgotPasswordPage.submitOtp(env.resetOtpCode);
    await forgotPasswordPage.setNewPassword('short');
    await expect(forgotPasswordPage.fieldError('new-password')).toContainText(
      /at least|must contain|policy/i,
    );
  });

  test(
    'TC-AUTH-006: password reset rejects reuse of the current password',
    { tag: '@seeded-defect' },
    async ({ forgotPasswordPage }) => {
      trace(test.info(), {
        testCaseId: 'TC-AUTH-006',
        risk: 'AUTH-R4 weak password policy',
        defect: seededDefects.SD_AUTH_02,
      });
      test.fail(env.seededDefectBuild, seededDefects.SD_AUTH_02.id);

      await forgotPasswordPage.goto();
      await forgotPasswordPage.requestOtp(env.users.valid.email);
      await forgotPasswordPage.submitOtp(env.resetOtpCode);
      await forgotPasswordPage.setNewPassword(env.users.valid.password);
      await forgotPasswordPage.expectToast(/cannot reuse|different from (the )?(old|current)/i);
    },
  );

  test('TC-AUTH-007: wrong OTP is rejected', async ({ forgotPasswordPage }) => {
    trace(test.info(), { testCaseId: 'TC-AUTH-007', risk: 'AUTH-R5 OTP verification' });

    await forgotPasswordPage.goto();
    await forgotPasswordPage.requestOtp(env.users.valid.email);
    await forgotPasswordPage.submitOtp('000000');
    await expect(forgotPasswordPage.fieldError('otp')).toContainText(/invalid|incorrect|expired/i);
  });

  test('TC-AUTH-008: logout invalidates the session', async ({ loggedInDashboard, page }) => {
    trace(test.info(), { testCaseId: 'TC-AUTH-008', risk: 'AUTH-R6 session handling' });

    await loggedInDashboard.logout();
    // Deep-linking back into the app must not restore the session.
    await page.goto('/dashboard');
    await expect(page).toHaveURL(/login/);
  });
});
